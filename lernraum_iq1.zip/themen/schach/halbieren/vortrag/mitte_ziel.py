# mitte.py -- sieben Wertungen, sortiert:
# eine Frage der binären Suche.


class Wertungen:

    def __init__(self, zahlen: list[int]):
        self.__zahlen = zahlen

    def erste_frage(self, gesucht: int) -> None:
        zahlen = self.__zahlen
        links = 0
        rechts = len(zahlen) - 1
        mitte = (links + rechts) // 2
        if zahlen[mitte] == gesucht:
            print("gefunden auf Index", mitte)
        elif zahlen[mitte] < gesucht:
            links = mitte + 1
        else:
            rechts = mitte - 1
        print(links, rechts)


wertungen = Wertungen(
    [1048, 1105, 1163, 1215,
     1290, 1342, 1418]
)
wertungen.erste_frage(1342)
