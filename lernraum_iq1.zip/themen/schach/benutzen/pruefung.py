"""Selbstcheck „Objekte benutzen“ -- prueft das Programm im Ordner schach/ (es laeuft partie.py).

Seit dem Umbau nach Schnitt A (15.11.2026) zieht die Dame per KLICK, und nur wohin passt Ja sagt. Der Check prueft
das am Verhalten (LC2): Er spielt partie.py noch einmal, mit einer eigenen Probe-Figur statt figur.py. Sie steht am
Start auf (5, 1) -- gleich, wo das Programm sie baut --, zieht wirklich und sagt zu ANDEREN Feldern Ja als eine Dame.
So faellt jede feste Zahl auf und jede Damenregel, die jemand selbst in partie.py schreibt, statt die Figur zu fragen.
Geklickt wird wie mit der Maus (klick_auf, LC6), auf der Flaeche dieses zweiten Laufs.

Jede Pruefung spielt das Programm frisch an (eigene Flaeche): Ein Klick einer Pruefung veraendert nichts, was eine
andere sieht. Die Flaeche wird gelesen wie von einem Menschen (LC6): eine Figur ueber das Bild, das man auf einem
Feld SIEHT, die Punkte der Ziele (und Rahmen) ueber ihre Lage. Die Funktionen unter Mehr ruft der Check mit eigenen
Figuren auf (LC8), auf der Flaeche des ersten Laufs.
"""
import ast
import sys
import types

import pruefen
from pruefen import erwarte, braucht, arbeit, flaeche, rechtecke, bilder, funktion, quelltext, anspielen, erzeuge, \
    klick_auf

TITEL = "Objekte benutzen · Selbstcheck"
EINGABEN = []
PROBE = (5, 1)
JA, NEIN = (2, 3), (2, 0)
HINTS = {"zeichne_felder": "None", "zeichne_figur": "None", "hebe_hervor": "None", "zeichne_punkt": "None",
         "zeige_ziele": "None", "zeichne_alles": "None", "klick": "None", "schreibe_wert": "None", "zeichne": "None"}


def _sagt_ja(von, zeile, spalte):
    """Die Gangart der Probe-Figur: keine Schachfigur zieht so, und sie haengt vom Feld der Figur ab. Gewaehlt so,
    dass von PROBE und von JA aus Ziele in Zeile 0 und 7 und in Spalte 0 und 7 liegen (sonst bliebe range(7) in
    zeige_ziele unentdeckt -- Giftprobe 15.11.2026) und die Menge nicht spiegelgleich ist (vertauschte Zeile und
    Spalte fallen auf)."""
    return (zeile, spalte) != tuple(von) and (zeile + 2 * spalte + zeile * spalte + 2 * von[0] + von[1]) % 5 == 0


def _ziele(von):
    return {(z, s) for z in range(8) for s in range(8) if _sagt_ja(von, z, s)}


def _damenziele(von):
    return {(z, s) for z in range(8) for s in range(8) if (z, s) != tuple(von)
            and (z == von[0] or s == von[1] or abs(z - von[0]) == abs(s - von[1]))}


class _ProbeFigur:
    """Dieselben Attribute und Methoden wie figur.py. Steht am Start immer auf PROBE (merkt sich, wo sie gebaut
    wurde), zieht wirklich und sagt Ja nach _sagt_ja. Merkt sich, welche Figuren gebaut wurden."""
    gebaut = []

    def __init__(self, art, farbe, zeile, spalte):
        self.art, self.farbe = art, farbe
        self.gebaut_auf = (zeile, spalte)
        self.zeile, self.spalte = PROBE
        self.gezogen = []
        _ProbeFigur.gebaut.append(self)

    def get_wert(self):
        return 9 if self.art == "Dame" else 1

    def ziehen(self, zeile, spalte):
        self.gezogen.append((zeile, spalte))
        self.zeile, self.spalte = zeile, spalte

    def passt(self, zeile, spalte):
        return _sagt_ja((self.zeile, self.spalte), zeile, spalte)


def _g():
    return getattr(arbeit(), "FELDGROESSE", None)


def _probelauf():
    """partie.py noch einmal, mit der Probe-Figur statt figur.py. Gibt (Flaeche, weisse Dame) -- die Flaeche ist
    None, wenn keine entstand, die Dame None, wenn das Programm keine baut."""
    m = types.ModuleType("figur")
    m.Figur = _ProbeFigur
    sys.modules["figur"] = m
    _ProbeFigur.gebaut.clear()
    try:
        _, ns = anspielen([])
    finally:
        sys.modules.pop("figur", None)
    damen = [f for f in _ProbeFigur.gebaut if f.art == "Dame" and f.farbe == "weiß"]
    return ns.get("flaeche"), (damen[0] if damen else None)


def _klick(c, feld, g):
    """Klickt wie die Maus mitten auf das Feld -- auf der Flaeche c eines Probelaufs (klick_auf nimmt die Flaeche
    des Fensters, das gerade als das Fenster des Programms gilt)."""
    alt = pruefen._FENSTER
    pruefen._FENSTER = c.winfo_toplevel()
    try:
        return klick_auf(feld[1] * g + g // 2, feld[0] * g + g // 2, wo="Zeile %d, Spalte %d" % feld)
    finally:
        pruefen._FENSTER = alt


def _bild(c, zeile, spalte, g):
    """Das Bild, das man auf dem Feld SIEHT („dame-w.png“) -- None, wenn dort keins liegt."""
    x, y = spalte * g + g // 2, zeile * g + g // 2
    for i in reversed(c.find_all()):
        if c.type(i) == "image":
            b = c.bbox(i)
            if b and b[0] <= x < b[2] and b[1] <= y < b[3]:
                return pruefen._bilddatei(c, c.itemcget(i, "image"))
    return None


def _alle_bilder(c):
    return [pruefen._bilddatei(c, c.itemcget(i, "image")) for i in c.find_all() if c.type(i) == "image"]


def _feld(zeile, spalte, g):
    return (spalte * g, zeile * g, (spalte + 1) * g, (zeile + 1) * g)


def _markiert(c, g):
    """Die markierten Felder auf c als Menge von (zeile, spalte) -- seit 16.11.2026 ein Punkt mitten im Feld
    (zeichne_punkt); ein Rahmen (hebe_hervor) zaehlt weiter. Dazu, ob eine Marke NICHT genau auf einem Feld liegt."""
    felder, schief = set(), False
    for i in c.find_all():
        if c.type(i) == "rectangle" and not c.itemcget(i, "fill") and c.itemcget(i, "outline"):
            x1, y1, x2, y2 = (round(v) for v in c.coords(i))
            if x1 % g or y1 % g or x2 - x1 != g or y2 - y1 != g:
                schief = True
            else:
                felder.add((y1 // g, x1 // g))
        elif c.type(i) == "oval":
            x1, y1, x2, y2 = (round(v) for v in c.coords(i))
            if (x1 + x2) // 2 % g != g // 2 or (y1 + y2) // 2 % g != g // 2:
                schief = True
            else:
                felder.add(((y1 + y2) // 2 // g, (x1 + x2) // 2 // g))
    return felder, schief


def _wo(feld):
    return "Zeile %d, Spalte %d" % tuple(feld)


def _stufe1():
    """Ist die Dame ein Objekt, das per Klick zieht? (nur fuer braucht)"""
    try:
        pruefe_20_objekt()
    except AssertionError:
        return False
    return True


def _defs():
    baum = ast.parse(quelltext("partie.py"))
    return [(k.name, k) for k in baum.body if isinstance(k, ast.FunctionDef)]


def _neu(name, *angaben):
    """Ruft die Funktion name mit eigenen Angaben auf der Flaeche des Programms. Gibt die neuen Dinge -- oder einen
    Text, wenn der Aufruf abbricht."""
    f, c = funktion(name), flaeche()
    vorher = set(c.find_all())
    try:
        f(*angaben)
    except Exception as e:  # noqa: BLE001 -- der Abbruch ist der Befund
        return "%s bricht ab: %s: %s" % (name, type(e).__name__, e)
    return [i for i in c.find_all() if i not in vorher]


def pruefe_00_laeuft():
    """Grundlage · Das Programm läuft und malt Brett und Figuren"""
    erwarte(flaeche() is not None, "Keine Zeichenfläche -- bricht das Programm vor neue_flaeche ab? Seht in der Shell nach.")
    g = _g()
    erwarte(isinstance(g, int) and g > 0, "FELDGROESSE ist keine ganze Zahl über 0 -- oben in partie.py.")
    felder = [r for r in rechtecke() if r[4]]
    erwarte(len(felder) >= 64, "Auf der Fläche liegen %d gefüllte Felder statt 64 -- bricht das Programm vorher ab? "
            "Seht in der Shell nach." % len(felder))
    zahl = len(bilder())
    erwarte(zahl >= 32, "Auf dem Brett stehen %d Figuren statt 32 -- bricht das Programm vorher ab? Seht in der "
            "Shell nach." % zahl)


def pruefe_20_objekt():
    """Aufgabe 2 · Die Dame ist ein Objekt und zieht per Klick"""
    g = _g()
    c, dame = _probelauf()
    erwarte(c is not None, "Mit einer Probe-Figur bricht das Programm ab, bevor es malt -- seht nach, ob ihr etwas "
            "benutzt, das nicht im Steckbrief steht.")
    erwarte(dame is not None, "In partie.py entsteht noch keine weiße Dame aus dem Bauplan Figur -- sie ist nur ein Bild.")
    erwarte(dame.gebaut_auf == (7, 3), "Die Dame wird auf %s gebaut -- am Start steht sie auf Zeile 7, Spalte 3."
            % _wo(dame.gebaut_auf))
    z, s = PROBE
    erwarte("dame-w.png" in _alle_bilder(c), "Nach dem Bau der Dame kommt kein Bild der weißen Dame mehr auf das "
            "Brett -- bricht das Programm vorher ab? Seht in der Shell nach: Benutzt ihr nur, was im Steckbrief steht?")
    erwarte(_bild(c, z, s, g) == "dame-w.png", "Es gibt die Dame als Objekt, aber ihr Bild steht noch an festen "
            "Zahlen: zeichne_figur liest ihr Feld nicht.")
    erwarte(_bild(c, 7, 3, g) != "dame-w.png", "Auf Zeile 7, Spalte 3 steht noch eine zweite weiße Dame -- das alte "
            "Bild mit festen Zahlen ist noch da.")
    _klick(c, JA, g)
    probe = "Der Selbstcheck spielt mit einer eigenen Figur auf %s und klickt auf %s" % (_wo(PROBE), _wo(JA))
    erwarte(dame.gezogen, "%s: Die Figur zieht nicht. Ruft klick ihr ziehen auf?" % probe)
    ziel = dame.gezogen[-1]
    erwarte(ziel != (JA[1], JA[0]), "%s: Die Figur zieht nach %s -- Zeile und Spalte sind vertauscht." % (probe, _wo(ziel)))
    erwarte(ziel == JA, "%s: Die Figur zieht nach %s." % (probe, _wo(ziel)))
    erwarte(_bild(c, z, s, g) != "dame-w.png" or _bild(c, *JA, g) == "dame-w.png",
            "Die Dame ist nach dem Klick gezogen, ihr Bild steht aber noch auf dem alten Feld. Wann liest zeichne_figur "
            "das Feld der Dame -- vor dem Ziehen oder danach?")
    erwarte(_bild(c, *JA, g) == "dame-w.png", "Die Dame ist nach dem Klick gezogen, auf ihrem neuen Feld steht aber "
            "kein Bild der weißen Dame.")
    zahl = len(_alle_bilder(c))
    erwarte(zahl == 32, "Nach dem Klick stehen %d Figuren auf dem Brett statt 32 -- welche Funktion zeichnet das "
            "ganze Brett neu?" % zahl)


def _vergleiche(ist, soll, von, wann):
    """Tragen genau die Felder einen Punkt, zu denen die Probe-Figur (auf von) Ja sagt?"""
    erwarte(ist != _damenziele(von) or ist == soll, "%s tragen die Felder einen Punkt, auf die eine Dame ziehen darf -- aber "
            "die Regel steht in partie.py. Der Selbstcheck spielt mit einer Figur, die anders zieht: Fragt die "
            "Figur, statt die Regel selbst zu schreiben." % wann)
    erwarte(ist != {(s, z) for z, s in soll} or ist == soll, "%s tragen die falschen Felder einen Punkt: Zeile und Spalte "
            "sind vertauscht, wenn ihr die Figur fragt." % wann)
    fehlt, zuviel = sorted(soll - ist), sorted(ist - soll)
    erwarte(not zuviel, "%s %s markiert, obwohl die Figur dazu Nein sagt (zum Beispiel %s)."
            % (wann, "ist ein Feld" if len(zuviel) == 1 else "sind %d Felder" % len(zuviel), _wo(zuviel[0]) if zuviel else ""))
    erwarte(not fehlt, "%s fehlt der Punkt an %s, zu %s die Figur Ja sagt (zum Beispiel %s) -- geht ihr alle 64 "
            "Felder durch?" % (wann, "einem Feld" if len(fehlt) == 1 else "%d Feldern" % len(fehlt),
                               "dem" if len(fehlt) == 1 else "denen", _wo(fehlt[0]) if fehlt else ""))


def pruefe_25_regel():
    """Aufgabe 2 ★★ · Die Dame zieht nur, wohin sie darf -- ihre Ziele tragen einen Punkt"""
    braucht(_stufe1(), "Erst zieht die Dame per Klick.")
    g = _g()
    c, dame = _probelauf()
    ist, schief = _markiert(c, g)
    erwarte(ist or schief, "Am Start trägt noch kein Feld einen Punkt -- die Ziele der Dame sollen zu sehen sein, bevor "
            "jemand klickt.")
    erwarte(not schief, "Ein Punkt liegt nicht mitten in einem Feld (oder ein Rahmen nicht genau darauf).")
    _vergleiche(ist, _ziele(PROBE), PROBE, "Am Start")
    _klick(c, NEIN, g)
    erwarte((dame.zeile, dame.spalte) == PROBE, "Der Selbstcheck spielt mit einer eigenen Figur, die zu %s Nein sagt "
            "-- nach einem Klick dorthin steht sie trotzdem dort. Wer fragt die Figur, bevor sie zieht?" % _wo(NEIN))
    ist, _ = _markiert(c, g)
    erwarte(NEIN not in ist, "Nach einem Klick auf %s ist dieses Feld markiert, obwohl die Figur dazu Nein sagt -- "
            "markiert sind jetzt nur noch ihre Ziele." % _wo(NEIN))
    _vergleiche(ist, _ziele(PROBE), PROBE, "Nach einem Klick, zu dem die Figur Nein sagt,")
    _klick(c, JA, g)
    erwarte((dame.zeile, dame.spalte) == JA and _bild(c, *JA, g) == "dame-w.png", "Der Selbstcheck spielt mit einer "
            "eigenen Figur, die zu %s Ja sagt -- nach einem Klick dorthin steht sie nicht dort." % _wo(JA))
    ist, _ = _markiert(c, g)
    erwarte(JA not in ist, "Nach dem Zug ist das Feld markiert, auf dem die Dame jetzt steht -- markiert sind nur noch "
            "ihre Ziele, nicht das angeklickte Feld.")
    _vergleiche(ist, _ziele(JA), JA, "Nach dem Zug")
    zahl = len(_alle_bilder(c))
    erwarte(zahl == 32, "Nach dem Zug stehen %d Figuren auf dem Brett statt 32." % zahl)


def pruefe_50_wert():
    """Aufgabe 5 ★★ · schreibe_wert schreibt den Wert ins Feld der Figur"""
    braucht(funktion("schreibe_wert") is not None, "Erst die Funktion schreibe_wert.")
    g, c = _g(), flaeche()
    for art, z, s, wert in (("Turm", 2, 5, "5"), ("Springer", 4, 1, "3")):
        figur = erzeuge("Figur", art, "schwarz", z, s)
        neu = _neu("schreibe_wert", figur)
        erwarte(not isinstance(neu, str), neu)
        texte = [(str(c.itemcget(i, "text")), *[round(v) for v in c.coords(i)[:2]]) for i in neu if c.type(i) == "text"]
        erwarte(texte, "schreibe_wert schreibt nichts auf die Fläche.")
        x1, y1, x2, y2 = _feld(z, s, g)
        erwarte(any(t == wert for t, _, _ in texte), "Für einen %s auf (%d, %d) schreibt schreibe_wert %s statt %s -- "
                "kommt der Wert von der Figur?" % (art, z, s, ", ".join(t for t, _, _ in texte), wert))
        erwarte(any(t == wert and x1 <= x < x2 and y1 <= y < y2 for t, x, y in texte),
                "Für einen %s auf Zeile %d, Spalte %d steht die %s nicht in seinem Feld." % (art, z, s, wert))
    # ... und die Dame trägt ihren Wert: am Start und nach jedem Klick (der Klick malt alles neu)
    braucht(_stufe1(), "Die Funktion stimmt -- für die Dame aufrufen könnt ihr sie, sobald die Dame per Klick zieht "
            "(Aufgabe 2).")
    c2, dame = _probelauf()

    def neun(feld):
        x1, y1, x2, y2 = _feld(*feld, g)
        return any(c2.type(i) == "text" and str(c2.itemcget(i, "text")) == "9" and x1 <= c2.coords(i)[0] < x2
                   and y1 <= c2.coords(i)[1] < y2 for i in c2.find_all())
    erwarte(neun(PROBE), "Die Funktion stimmt -- im Feld der Dame steht ihre 9 aber noch nicht: Ruft ihr "
            "schreibe_wert für die Dame auf?")
    _klick(c2, JA, g)
    erwarte(neun((dame.zeile, dame.spalte)), "Am Start steht die 9 im Feld der Dame, nach einem Klick ist sie weg: "
            "Der Klick zeichnet alles neu. Wo muss der Aufruf stehen, damit er jedes Mal dabei ist?")


def pruefe_60_jede_figur():
    """Aufgabe 6 ★★★ · zeichne setzt jede Figur ohne if an ihr Feld"""
    braucht(funktion("zeichne") is not None, "Erst die Funktion zeichne.")
    defs = dict(_defs())
    wenn = [k for k in ast.walk(defs["zeichne"]) if isinstance(k, (ast.If, ast.IfExp, ast.Match))]
    erwarte(not wenn, "zeichne hat noch ein if -- die Auflage ist: ohne.")
    g, c = _g(), flaeche()
    arten = (("Bauer", "bauer"), ("Springer", "springer"), ("Läufer", "laeufer"), ("Turm", "turm"),
             ("Dame", "dame"), ("König", "koenig"))
    falsch = []
    for i, (art, datei) in enumerate(arten):
        for j, (farbe, k) in enumerate((("weiß", "w"), ("schwarz", "s"))):
            z, s = 2 + j, 1 + i
            figur = erzeuge("Figur", art, farbe, z, s)
            neu = _neu("zeichne", figur)
            erwarte(not isinstance(neu, str), neu)
            if _bild(c, z, s, g) != "%s-%s.png" % (datei, k):
                falsch.append("%s (%s)" % (art, farbe))
    erwarte(not falsch, "Nicht an ihrem Feld oder mit dem falschen Bild: %s." % ", ".join(falsch))


def pruefe_90_hints():
    """Hinweis · Jedes def mit Type Hints -- auch an den Parametern (kein Stern)"""
    ohne, falsch = [], []
    for name, k in _defs():
        if k.returns is None or any(a.annotation is None for a in k.args.args):
            ohne.append(name)
        elif name in HINTS and ast.unparse(k.returns).replace(" ", "") != HINTS[name]:
            falsch.append("%s -> %s" % (name, HINTS[name]))
    erwarte(not ohne, "Ohne Type Hint (hinter der Klammer oder an einem Parameter): %s. Es läuft auch ohne; "
            "vereinbart ist es trotzdem." % ", ".join(ohne))
    erwarte(not falsch, "Dieser Type Hint passt nicht zu dem, was zurückkommt -- erwartet: %s." % ", ".join(falsch))
