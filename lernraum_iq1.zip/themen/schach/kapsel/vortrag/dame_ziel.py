# dame.py -- die Figur aus „Eigene Klassen
# schreiben“, oben in dieser Datei.

# erlaubt die eigene Klasse als Typ:
from __future__ import annotations
from zeichenflaeche import neue_flaeche, zeichne_bild, zeige

FELDGROESSE = 60
flaeche = neue_flaeche(8 * FELDGROESSE, 8 * FELDGROESSE)


def zeichne_felder() -> None:
    for zeile in range(8):
        for spalte in range(8):
            x = spalte * FELDGROESSE
            y = zeile * FELDGROESSE
            if (zeile + spalte) % 2 == 0:
                farbe = "#eeeed2"
            else:
                farbe = "#769656"
            flaeche.create_rectangle(x, y, x + FELDGROESSE, y + FELDGROESSE,
                                     fill=farbe, outline=farbe)


def zeichne_figur(name: str, zeile: int, spalte: int) -> None:
    zeichne_bild(name, spalte * FELDGROESSE, zeile * FELDGROESSE, FELDGROESSE)


class Figur:

    def __init__(self, art: str, farbe: str, zeile: int, spalte: int):
        self.art = art
        self.farbe = farbe
        self.__zeile = zeile
        self.__spalte = spalte

    def ziehen(self, zeile: int, spalte: int) -> None:
        self.__zeile = zeile
        self.__spalte = spalte

    def set_zeile(self, zeile: int) -> None:
        if zeile >= 0 and zeile <= 7:
            self.__zeile = zeile

    def get_zeile(self) -> int:
        return self.__zeile

    def get_spalte(self) -> int:
        return self.__spalte


zeichne_felder()
dame = Figur("Dame", "weiß", 7, 3)
dame.ziehen(3, 3)
dame.set_zeile(99)
zeichne_figur("dame-w", dame.get_zeile(), dame.get_spalte())
zeige()
