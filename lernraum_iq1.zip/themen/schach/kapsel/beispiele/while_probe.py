zahl = 1
durchlaeufe = 0
while zahl < 50:
    zahl = zahl * 3
    durchlaeufe = durchlaeufe + 1
print(zahl)
print(durchlaeufe)
