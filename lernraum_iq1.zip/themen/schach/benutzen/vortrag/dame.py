# dame.py -- oben, was ihr aus partie.py kennt.
from zeichenflaeche import neue_flaeche, zeichne_bild, zeige
from figur import Figur

FELDGROESSE = 60
HELL = "#eeeed2"
DUNKEL = "#769656"
flaeche = neue_flaeche(8 * FELDGROESSE, 8 * FELDGROESSE)


def zeichne_felder() -> None:
    for zeile in range(8):
        for spalte in range(8):
            x = spalte * FELDGROESSE
            y = zeile * FELDGROESSE
            if (zeile + spalte) % 2 == 0:
                farbe = HELL
            else:
                farbe = DUNKEL
            flaeche.create_rectangle(x, y, x + FELDGROESSE, y + FELDGROESSE,
                                     fill=farbe, outline=farbe)


def zeichne_figur(name: str, zeile: int, spalte: int) -> None:
    zeichne_bild(name, spalte * FELDGROESSE, zeile * FELDGROESSE, FELDGROESSE)


def hebe_hervor(zeile: int, spalte: int) -> None:
    x = spalte * FELDGROESSE
    y = zeile * FELDGROESSE
    flaeche.create_rectangle(x, y, x + FELDGROESSE, y + FELDGROESSE,
                             outline="red", width=4)


zeichne_felder()

zeige()
