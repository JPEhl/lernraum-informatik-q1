// Werkstatt "Karten" -- Mitgliedskarten des Schachportals, verdeckt: Der Tisch sagt nur, welche von zwei Karten die
// hoehere Wertung hat, und zaehlt. iq1 schach, Teil II (16.11.2026). Drei Attrappen im Film (verdeckt und frei · offen
// mit zwei Zeigern · der Tisch fuehrt eine Vorschrift aus); Lehrerwahl: Fassung A „verdeckt und frei“. Anlass ist sein
// Wunsch, „die Schüler am Anfang auch experimentieren zu lassen. Sie sollen selbst möglichst ‚effiziente‘ Sortierungen
// entwerfen“ -- offene Karten sortiert das Auge, also liegen sie verdeckt, und „effizient“ heisst: wenige Vergleiche.
// Tische (LT9: ein Tisch erscheint erst mit seinem Thema):
//   sortieren -- sortieren: je zwei beliebige Karten vergleichen, tauschen, aufdecken; 4, 8 oder 16 Karten
//   zaehlen   -- sortieren, bubblesort: erst schaetzen, dann zaehlt der Tisch den Bubblesort; Tabelle und Kurve
//   nachbarn  -- bubblesort: nur das Paar am Zeiger -- vergleichen, tauschen, weiter; nach jedem Durchgang liegt eine fest
//   halbieren -- halbieren: sortiert und verdeckt, jede aufgedeckte Karte ist eine Frage
// Kein Rueckgaengig: Ein Vergleich, der gezaehlt ist, bleibt gezaehlt. „von vorn“ legt dieselben Karten wieder hin.
// „als Python zeigen“ gibt es nur, wo der Schritt python="ja" traegt (nachbarn, halbieren): Aus Plaetzen werden Indizes.
// Einbinden: Werkstaetten.karten(element, {tisch: "sortieren"} | {tische: "sortieren|zaehlen"})
//   -> { zustand, film: {spielen, herstellen, laeuft} }
// Film (bauen.py, WERKSTATT_FILM): + vergleiche: 3 6 · + tausche · + aufdecken · + karten: 16 · + paar · + weiter ·
//   + durchgang · + schaetze: 30 · + lauf · + suche: 1418 · + decke: 8 · + python · + neu · + halt
window.Werkstaetten = window.Werkstaetten || {};
window.Werkstaetten.karten = function (wurzel, opt) {
  opt = opt || {};
  // die zwanzig Mitglieder in der Reihenfolge ihrer Anmeldung -- dieselben wie in rangliste/mitglieder.py
  const MITGLIEDER = [["Aylin", 1480], ["Bence", 1215], ["Chiara", 1630], ["Dawit", 1342], ["Emre", 1105], ["Finja", 1577], ["Goran", 1290],
    ["Hanh", 1418], ["Ilias", 1048], ["Jule", 1466], ["Kofi", 1712], ["Liv", 1322], ["Milan", 1189], ["Nuria", 1540], ["Oskar", 1401],
    ["Pari", 1273], ["Quinn", 1433], ["Rosa", 1163], ["Samir", 1502], ["Tuana", 1251]];
  // fuer den Tisch zaehlen: bis 64 Karten -- die zwanzig, danach Wertungen aus einer festen Folge (kein Zufall im Vortrag)
  const VIELE = MITGLIEDER.map(m => m[1]);
  for (let i = 20, x = 7; i < 64; i++) { x = (x * 73 + 41) % 997; VIELE.push(1000 + x); }
  // halbieren: sortiert, mit Luecken und einer Wertung, die zweimal vorkommt
  const SORTIERT = [1048, 1105, 1163, 1215, 1215, 1290, 1342, 1377, 1418, 1466, 1502, 1540, 1577, 1630, 1712];
  const SUCHEN = [1418, 1105, 1630, 1215, 1540];
  const NAMEN = { sortieren: "Sortieren", zaehlen: "Zählen", nachbarn: "Nur Nachbarn", halbieren: "Halbieren" };
  const STUFEN = [4, 8, 16, 32, 64];
  const tische = String(opt.tische || opt.tisch || "sortieren").split("|").map(t => t.trim()).filter(t => NAMEN[t]);
  if (!tische.length) tische.push("sortieren");
  const mitPython = opt.python === "ja";

  const h = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };
  const knopf = (text, cls, fn) => { const b = h("button", cls || "", text); b.type = "button"; b.onclick = fn; return b; };
  const platz = i => i + 1;

  let tisch = tische[0];
  const eigen = {};             // was das Paar am Tisch sortieren geschafft hat: Karten -> Vergleiche (fuer den Tisch zaehlen)
  let z = neu(tisch);

  function neu(t, behalte) {
    if (t === "sortieren" || t === "nachbarn") {
      const n = behalte && behalte.n || parseInt(opt.karten, 10) || 8;
      return { tisch: t, n, reihe: (behalte && behalte.start || MITGLIEDER.slice(0, n).map((m, i) => i)).slice(), start: behalte && behalte.start || MITGLIEDER.slice(0, n).map((m, i) => i),
        wahl: [], vergleiche: 0, tausche: 0, offen: false, urteil: "", protokoll: [], zeiger: 0, fest: 0, durchgang: 1, verglichen: false, python: false };
    }
    if (t === "zaehlen") return { tisch: t, n: 4, geschaetzt: {}, eigen: Object.assign({}, eigen), bubble: {}, meldung: "" };
    return { tisch: t, ziel: behalte && behalte.ziel || SUCHEN[0], offen: [], links: 0, rechts: SORTIERT.length - 1, fragen: 0, gefunden: -1, urteil: "", protokoll: [], python: false };
  }
  const kopie = o => JSON.parse(JSON.stringify(o));

  // ─── rechnen ───────────────────────────────────────────────────────────────────────
  const wert = i => MITGLIEDER[z.reihe[i]][1];
  function schreibe(text, code) { z.protokoll.unshift(z.python && code ? code : text); if (z.protokoll.length > 60) z.protokoll.pop(); }
  function vergleiche(a, b) {
    if (z.offen || a === b) return;
    z.vergleiche++; z.wahl = [a, b]; z.verglichen = true;
    const hoeher = wert(a) > wert(b) ? a : b;
    z.urteil = z.python ? "liste[" + a + "].get_wertung() > liste[" + b + "].get_wertung()  →  " + (wert(a) > wert(b) ? "True" : "False")
      : "Platz " + platz(a) + " und Platz " + platz(b) + ": Die höhere Wertung liegt auf Platz " + platz(hoeher) + ".";
    schreibe(platz(a) + " ? " + platz(b) + " – höher: Platz " + platz(hoeher), "liste[" + a + "] > liste[" + b + "]: " + (wert(a) > wert(b) ? "True" : "False"));
  }
  function tausche() {
    if (z.offen || z.wahl.length !== 2) return;
    const [a, b] = z.wahl; [z.reihe[a], z.reihe[b]] = [z.reihe[b], z.reihe[a]]; z.tausche++;
    z.urteil = z.python ? "merke = liste[" + a + "]   liste[" + a + "] = liste[" + b + "]   liste[" + b + "] = merke" : "Getauscht: Platz " + platz(a) + " und Platz " + platz(b) + ".";
    schreibe(platz(a) + " ↔ " + platz(b) + " getauscht", "liste[" + a + "] ↔ liste[" + b + "]");
    if (z.tisch === "sortieren") z.wahl = [];
  }
  const sortiert = () => z.reihe.every((k, i) => !i || MITGLIEDER[z.reihe[i - 1]][1] <= MITGLIEDER[k][1]);
  function aufdecken() {
    if (z.offen) return;
    z.offen = true; z.wahl = [];
    const gut = sortiert();
    z.urteil = gut ? "Sortiert – mit " + z.vergleiche + (z.vergleiche === 1 ? " Vergleich" : " Vergleichen") + " und " + z.tausche + (z.tausche === 1 ? " Tausch." : " Täuschen.")
      : "Noch nicht sortiert. " + z.vergleiche + " Vergleiche, " + z.tausche + " Täusche.";
    if (gut && z.tisch === "sortieren") { eigen[z.n] = z.vergleiche; try { sessionStorage.setItem("lernraum.karten.eigen", JSON.stringify(eigen)); } catch (e) {} }
  }
  // Tisch nachbarn: das Paar am Zeiger
  const paarEnde = () => z.n - 1 - z.fest;                   // der letzte Platz, an dem noch ein Paar beginnt, ist paarEnde - 1
  function paar() { if (!z.offen && z.fest < z.n - 1) vergleiche(z.zeiger, z.zeiger + 1); }
  function weiter() {
    if (z.offen || z.fest >= z.n - 1) return;
    z.wahl = []; z.verglichen = false; z.zeiger++;
    if (z.zeiger >= paarEnde()) {
      z.fest++; z.zeiger = 0;
      if (z.fest >= z.n - 1) { z.fest = z.n; z.urteil = "Kein Paar mehr übrig – " + z.vergleiche + " Vergleiche."; schreibe("fertig nach " + (z.durchgang) + " Durchgängen"); }
      else { schreibe("Durchgang " + z.durchgang + " zu Ende – Platz " + platz(z.n - z.fest) + " liegt fest"); z.durchgang++; z.urteil = "Durchgang " + z.durchgang + ": Die letzte Karte liegt fest."; }
    } else z.urteil = "";
  }
  function durchgang() {
    if (z.offen || z.fest >= z.n - 1) return;
    const d = z.durchgang;
    while (z.durchgang === d && z.fest < z.n - 1) { paar(); if (wert(z.zeiger) > wert(z.zeiger + 1)) tausche(); weiter(); }
  }
  // Tisch zaehlen: der Bubblesort mit zwei Schleifen, ohne fruehen Abbruch -- gezaehlt, nicht ausgerechnet
  function bubbleZaehlen(n) {
    const a = VIELE.slice(0, n); let v = 0;
    for (let d = 0; d < n - 1; d++) for (let i = 0; i < n - 1 - d; i++) { v++; if (a[i] > a[i + 1]) { const m = a[i]; a[i] = a[i + 1]; a[i + 1] = m; } }
    return v;
  }
  function lauf() {
    if (z.geschaetzt[z.n] == null || z.geschaetzt[z.n] === "") { z.meldung = "Erst schätzen: Wie viele Vergleiche braucht der Bubblesort bei " + z.n + " Karten?"; return; }
    z.bubble[z.n] = bubbleZaehlen(z.n); z.meldung = z.n + " Karten: " + z.bubble[z.n] + " Vergleiche.";
  }
  // Tisch halbieren
  function decke(i) {
    if (z.gefunden >= 0 || z.links > z.rechts || z.offen.includes(i) || i < 0 || i >= SORTIERT.length) return;
    z.offen.push(i); z.fragen++;
    const w = SORTIERT[i];
    if (w === z.ziel) { z.gefunden = i; z.urteil = "Platz " + platz(i) + " zeigt " + w + ": gefunden – nach " + z.fragen + (z.fragen === 1 ? " Frage." : " Fragen."); schreibe("Platz " + platz(i) + ": " + w + " – gefunden", "liste[" + i + "] == " + z.ziel); return; }
    if (w < z.ziel) { z.links = Math.max(z.links, i + 1); z.urteil = "Platz " + platz(i) + " zeigt " + w + ": zu niedrig – alles links davon fällt weg."; schreibe("Platz " + platz(i) + ": " + w + " – zu niedrig", "liste[" + i + "] < " + z.ziel + ": links = " + (i + 1)); }
    else { z.rechts = Math.min(z.rechts, i - 1); z.urteil = "Platz " + platz(i) + " zeigt " + w + ": zu hoch – alles rechts davon fällt weg."; schreibe("Platz " + platz(i) + ": " + w + " – zu hoch", "liste[" + i + "] > " + z.ziel + ": rechts = " + (i - 1)); }
    if (z.links > z.rechts) z.urteil += " Kein Platz bleibt: Die Wertung " + z.ziel + " gibt es nicht.";
  }

  // ─── zeichnen ──────────────────────────────────────────────────────────────────────
  wurzel.textContent = "";
  wurzel.classList.add("kartentisch");
  const reiter = h("div", "kt-reiter"), flaeche = h("div", "kt-flaeche");
  if (tische.length > 1) wurzel.append(reiter);
  wurzel.append(flaeche);
  function wechsle(t) { tisch = t; z = neu(t); zeichnen(); }

  function zaehler(...paare) { const d = h("div", "kt-zaehler"); for (const [name, zahl] of paare) { const k = h("div"); k.append(h("small", "", name), h("strong", "", String(zahl))); d.append(k); } return d; }
  function protokollEl() { const u = h("ul", "kt-protokoll" + (z.python ? " code" : "")); z.protokoll.forEach(t => u.append(h("li", "", t))); return u; }
  let eng = false;
  function karte(inhalt, i, cls, fn) {
    const k = knopf("", "kt-karte " + cls, fn);
    if (inhalt) k.append(h("span", "kt-name", inhalt[0]), h("span", "kt-wert", String(inhalt[1])));
    // enge Reihe (mehr als 8 Karten): unter den Karten nur die Zahl -- „Platz 10“ bis „Platz 15“ lagen übereinander (Fotos iq1 halbieren, 16.11.)
    k.append(h("span", "kt-platz", (z.python ? "[" + i + "]" : (eng && i > 0 ? "" : "Platz ") + platz(i))));
    k.setAttribute("aria-label", (inhalt ? inhalt[0] + " " + inhalt[1] + ", " : "verdeckte Karte, ") + "Platz " + platz(i));
    return k;
  }
  function pillen(aktiv, fn, werte) { const d = h("div", "kt-pillen"); d.append(h("span", "", "Karten")); (werte || STUFEN).forEach(n => d.append(knopf(String(n), "kt-pille" + (n === aktiv ? " an" : ""), () => fn(n)))); return d; }

  // Karten gleiten sichtbar an ihren neuen Ort (Durchsicht iq1, 16.11.2026: „Das Tauschen sollte visuell animiert
  // werden“ · „Das Tauschen/Anschauen etc. sollte klarer animiert werden“): Die Fläche wird bei jedem Schritt neu
  // gezeichnet; jede Karte trägt ihre Kennung (data-karte), und wer danach woanders liegt, fährt von der alten Lage
  // dorthin -- vom Platz auf den Vergleichstisch, über Kreuz beim Tausch, zurück in die Reihe.
  const ohneBewegung = !!(window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches);
  function lagen() { const m = new Map(); flaeche.querySelectorAll("[data-karte]").forEach(e => m.set(e.dataset.karte, e.getBoundingClientRect())); return m; }
  function gleiten(vorher) {
    if (ohneBewegung || !vorher.size) return;
    flaeche.querySelectorAll("[data-karte]").forEach(e => {
      const a = vorher.get(e.dataset.karte); if (!a || !e.animate) return;
      const b = e.getBoundingClientRect(), dx = a.left - b.left, dy = a.top - b.top;
      if (!b.width || (Math.abs(dx) < 1 && Math.abs(dy) < 1)) return;
      e.animate([{ transformOrigin: "0 0", transform: "translate(" + dx + "px, " + dy + "px) scale(" + (a.width / b.width) + ")", zIndex: 3 }, { transformOrigin: "0 0", transform: "none", zIndex: 3 }],
        { duration: 560, easing: "cubic-bezier(.2,.7,.3,1)" });
    });
  }
  function zeichnen() {
    const vorher = lagen();
    reiter.replaceChildren(...tische.map(t => knopf(NAMEN[t], t === tisch ? "aktiv" : "", () => wechsle(t))));
    flaeche.replaceChildren();
    flaeche.className = "kt-flaeche kt-" + z.tisch;
    if (z.tisch === "sortieren" || z.tisch === "nachbarn") zeichneReihe();
    else if (z.tisch === "zaehlen") zeichneZaehlen();
    else zeichneHalbieren();
    gleiten(vorher);
  }
  // Der Vergleichstisch (Durchsicht iq1, 16.11.2026: „Ich hätte gerne einen Tisch, auf den man zwei Karten legen kann
  // und das Programm zeigt an, welche Karte größer ist“): Die zwei gewählten Karten liegen hier, verdeckt; zwischen
  // ihnen steht das Zeichen, über der höheren „höher“. Ein Klick auf eine Karte legt sie zurück (sortieren).
  function tischEl(nachbarn) {
    const t = h("div", "kt-tisch"), [a, b] = z.wahl;
    const hoeher = z.verglichen && z.wahl.length === 2 ? (wert(a) > wert(b) ? a : b) : null;
    const ablage = (i, text) => {
      const d = h("div", "kt-ablage");
      if (i == null) { d.append(h("span", "kt-ablage-leer", text)); return d; }
      const k = knopf("", "kt-tischkarte" + (i === hoeher ? " hoeher" : ""), () => { if (nachbarn) return; z.wahl = z.wahl.filter(x => x !== i); z.urteil = ""; z.verglichen = false; zeichnen(); });
      k.dataset.karte = String(z.reihe[i]);
      k.append(h("span", "kt-platz", z.python ? "[" + i + "]" : "Platz " + platz(i)));
      if (i === hoeher) k.append(h("span", "kt-hoeher", "höher"));
      if (!nachbarn) k.title = "zurücklegen";
      k.setAttribute("aria-label", "verdeckte Karte von Platz " + platz(i) + " auf dem Vergleichstisch" + (i === hoeher ? ", die höhere" : ""));
      d.append(k); return d;
    };
    t.append(h("span", "kt-tischname", "Vergleichstisch"), ablage(a, nachbarn ? "links" : "erste Karte"),
      h("span", "kt-zeichen" + (hoeher == null ? " offen" : ""), hoeher == null ? "?" : hoeher === a ? ">" : "<"), ablage(b, nachbarn ? "rechts" : "zweite Karte"));
    return t;
  }
  function zeichneReihe() {
    const nachbarn = z.tisch === "nachbarn";
    const links = h("div", "kt-links"), seite = h("div", "kt-seite");
    links.append(h("p", "kt-auftrag", nachbarn ? "Verglichen wird nur das Paar am Zeiger. Nach jedem Durchgang liegt hinten eine Karte mehr fest."
      : "Zwei Karten anklicken: Sie kommen auf den Vergleichstisch, und er zeigt, welche die höhere Wertung hat. Sortiert heißt: die niedrigste Wertung auf Platz 1."));
    // die Wahl 4 · 8 · 16 nur, wo der Schritt keine feste Kartenzahl nennt (karten="4" im Vortrag)
    if (!nachbarn && !opt.karten) links.append(pillen(z.n, n => { z = neu("sortieren", { n }); zeichnen(); }, [4, 8, 16]));
    eng = z.n > 8;
    const reihe = h("div", "kt-reihe" + (eng ? " viele" : ""));
    z.reihe.forEach((k, i) => {
      // eine gewählte Karte liegt auf dem Vergleichstisch -- in der Reihe bleibt ihr leerer Platz (anklicken legt sie zurück)
      const gehoben = !z.offen && z.wahl.includes(i);
      const cls = (gehoben ? "leerplatz" : z.offen ? "auf" : "zu") + (nachbarn && i >= z.n - z.fest ? " fest" : "");
      const el = karte(z.offen ? MITGLIEDER[k] : null, i, cls, () => {
        if (z.offen || nachbarn) return;
        if (z.wahl.includes(i)) z.wahl = z.wahl.filter(x => x !== i);
        else { if (z.wahl.length === 2) z.wahl = []; z.wahl.push(i); if (z.wahl.length === 2) vergleiche(z.wahl[0], z.wahl[1]); else { z.urteil = ""; z.verglichen = false; } }
        zeichnen();
      });
      if (!gehoben) el.dataset.karte = String(k);
      if (nachbarn && !z.offen && z.fest < z.n - 1 && (i === z.zeiger || i === z.zeiger + 1)) { el.classList.add("zeiger"); el.append(h("span", "kt-zeiger", i === z.zeiger ? "links" : "rechts")); }
      reihe.append(el);
    });
    links.append(reihe);
    if (!z.offen && !(nachbarn && z.fest >= z.n - 1)) links.append(tischEl(nachbarn));
    links.append(h("div", "kt-urteil" + (z.python ? " code" : "") + (z.urteil ? "" : " leer"), z.urteil || (nachbarn ? "Durchgang " + z.durchgang + ": vergleichen, wenn nötig tauschen, weiter." : z.wahl.length ? "Noch eine Karte." : "Wählt zwei Karten.")));
    const kn = h("div", "kt-knoepfe");
    const fertig = z.offen || (nachbarn && z.fest >= z.n);
    if (nachbarn) {
      const b1 = knopf("vergleichen", "", () => { paar(); zeichnen(); }), b2 = knopf("tauschen", "primaer", () => { tausche(); zeichnen(); }), b3 = knopf("weiter", "", () => { weiter(); zeichnen(); }), b4 = knopf("ganzer Durchgang", "", () => { durchgang(); zeichnen(); });
      b1.disabled = z.offen || z.fest >= z.n - 1 || z.verglichen; b2.disabled = z.offen || !z.verglichen || z.wahl.length !== 2; b3.disabled = b4.disabled = z.offen || z.fest >= z.n - 1;
      kn.append(b1, b2, b3, b4);
    } else {
      const b = knopf("tauschen", "primaer", () => { tausche(); zeichnen(); }); b.disabled = z.offen || z.wahl.length !== 2;
      // zurücklegen (Durchsicht 16.11.: „Man muss Karten, die man ausgewählt hat, mühsam wieder abwählen“)
      const zl = knopf("zurücklegen", "", () => { z.wahl = []; z.urteil = ""; z.verglichen = false; zeichnen(); }); zl.disabled = z.offen || !z.wahl.length;
      kn.append(b, zl);
    }
    const auf = knopf("aufdecken – sortiert?", "", () => { aufdecken(); zeichnen(); }); auf.disabled = z.offen;
    // „von vorn“ und „neu mischen“ ohne die ruhige Farbe (Durchsicht 16.11.: „sehen ausgegraut aus, als könne man es nicht anwählen“)
    kn.append(auf, knopf("von vorn", "", () => { z = neu(z.tisch, { n: z.n, start: z.start }); zeichnen(); }));
    if (!nachbarn) kn.append(knopf("neu mischen", "", () => { const s = z.start.slice(); for (let i = s.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [s[i], s[j]] = [s[j], s[i]]; } z = neu("sortieren", { n: z.n, start: s }); zeichnen(); }));
    if (mitPython) kn.append(knopf(z.python ? "in Worten zeigen" : "als Python zeigen", "", () => { z.python = !z.python; z.urteil = ""; zeichnen(); }));
    links.append(kn);
    if (fertig && z.offen && !sortiert()) links.append(h("p", "kt-hinweis", "„von vorn“ legt dieselben Karten wieder verdeckt hin."));
    seite.append(nachbarn ? zaehler(["Vergleiche", z.vergleiche], ["Täusche", z.tausche], ["Durchgang", Math.min(z.durchgang, z.n - 1)]) : zaehler(["Vergleiche", z.vergleiche], ["Täusche", z.tausche]), h("h3", "", "Protokoll"), protokollEl());
    flaeche.append(links, seite);
  }
  function zeichneZaehlen() {
    const links = h("div", "kt-links"), rechts = h("div", "kt-kurve");
    links.append(h("p", "kt-auftrag", "Dasselbe Verfahren mit mehr Karten: Was kostet es? Erst schätzen, dann zählt der Tisch den Bubblesort."), pillen(z.n, n => { z.n = n; z.meldung = ""; zeichnen(); }));
    const t = h("table", "kt-tabelle"), kopf = h("tr"); ["Karten", "geschätzt", "euer Verfahren", "Bubblesort"].forEach(x => kopf.append(h("th", "", x))); t.append(kopf);
    STUFEN.forEach(n => {
      const tr = h("tr", n === z.n ? "an" : ""); tr.append(h("td", "", String(n)));
      for (const feld of ["geschaetzt", "eigen"]) {
        const td = h("td"), ein = h("input"); ein.type = "text"; ein.inputMode = "numeric"; ein.value = z[feld][n] == null ? "" : z[feld][n];
        ein.setAttribute("aria-label", (feld === "eigen" ? "euer Verfahren" : "geschätzt") + " bei " + n + " Karten");
        ein.onchange = () => { const v = ein.value.trim(); z[feld][n] = /^\d+$/.test(v) ? parseInt(v, 10) : ""; if (feld === "eigen") eigen[n] = z.eigen[n]; zeichnen(); };
        td.append(ein); tr.append(td);
      }
      tr.append(h("td", "kt-bubble", z.bubble[n] == null ? "" : String(z.bubble[n]))); t.append(tr);
    });
    const kn = h("div", "kt-knoepfe"); kn.append(knopf("Bubblesort bei " + z.n + " Karten zählen", "primaer", () => { lauf(); zeichnen(); }), knopf("von vorn", "ruhig", () => { z = neu("zaehlen"); zeichnen(); }));
    links.append(t, kn, h("p", "kt-urteil" + (z.meldung ? "" : " leer"), z.meldung || "Doppelt so viele Karten – wie viel mehr Vergleiche?"));
    rechts.innerHTML = kurve();
    flaeche.append(links, rechts);
  }
  function kurve() {
    const B = 420, H = 280, L = 50, U = 232, R = 404, O = 20;
    const zahlen = k => Object.keys(z[k]).filter(n => z[k][n] !== "" && z[k][n] != null).map(n => [parseInt(n, 10), z[k][n]]);
    const pb = zahlen("bubble"), pe = zahlen("eigen"), alle = pb.concat(pe);
    const nMax = Math.max(16, ...alle.map(p => p[0])), vMax = Math.max(40, ...alle.map(p => p[1]), nMax);
    const x = n => L + (R - L) * n / nMax, y = v => U - (U - O) * v / vMax;
    let s = '<svg viewBox="0 0 ' + B + ' ' + H + '" role="img" aria-label="Vergleiche über der Zahl der Karten"><line class="achse" x1="' + L + '" y1="' + U + '" x2="' + R + '" y2="' + U + '"/><line class="achse" x1="' + L + '" y1="' + U + '" x2="' + L + '" y2="' + O + '"/>';
    STUFEN.filter(n => n <= nMax).forEach(n => { s += '<text class="zahl" x="' + x(n) + '" y="' + (U + 20) + '" text-anchor="middle">' + n + '</text>'; });
    s += '<text class="zahl" x="' + (L - 6) + '" y="' + (U + 4) + '" text-anchor="end">0</text><text class="zahl" x="' + (L - 6) + '" y="' + (O + 4) + '" text-anchor="end">' + vMax + '</text><text class="zahl" x="' + ((L + R) / 2) + '" y="' + (H - 6) + '" text-anchor="middle">Karten</text>';
    s += '<line class="gerade" x1="' + x(0) + '" y1="' + y(0) + '" x2="' + x(nMax) + '" y2="' + y(nMax) + '"/><text class="leg grau" x="' + (R - 4) + '" y="' + (y(nMax) - 8) + '" text-anchor="end">ein Vergleich je Karte</text>';
    if (pb.length >= 2) { pb.sort((a, b) => a[0] - b[0]); s += '<polyline class="linie" points="' + pb.map(p => x(p[0]) + "," + y(p[1])).join(" ") + '"/>'; }
    pb.forEach(p => { s += '<circle class="punkt" cx="' + x(p[0]) + '" cy="' + y(p[1]) + '" r="5.5"/>'; });
    pe.forEach(p => { s += '<rect class="eigen" x="' + (x(p[0]) - 5) + '" y="' + (y(p[1]) - 5) + '" width="10" height="10"/>'; });
    if (pb.length) s += '<text class="leg blau" x="' + (L + 14) + '" y="' + (O + 14) + '">● Bubblesort</text>';
    if (pe.length) s += '<text class="leg amber" x="' + (L + 14) + '" y="' + (O + 32) + '">■ euer Verfahren</text>';
    return s + "</svg>";
  }
  function zeichneHalbieren() {
    const links = h("div", "kt-links"), seite = h("div", "kt-seite");
    links.append(h("p", "kt-auftrag", "Sortiert und verdeckt. Jede aufgedeckte Karte ist eine Frage."), h("p", "kt-gesucht", "Gesucht: die Wertung " + z.ziel));
    eng = true;
    const reihe = h("div", "kt-reihe viele");
    SORTIERT.forEach((w, i) => {
      const auf = z.offen.includes(i), weg = !auf && (i < z.links || i > z.rechts || z.gefunden >= 0);
      reihe.append(karte(auf ? ["", w] : null, i, (auf ? "auf" : "zu") + (weg ? " weg" : "") + (i === z.gefunden ? " treffer" : auf ? " wahl" : ""), () => { decke(i); zeichnen(); }));
    });
    links.append(reihe, h("div", "kt-urteil" + (z.python ? " code" : "") + (z.urteil ? "" : " leer"), z.urteil || "Welche Karte deckt ihr zuerst auf?"));
    const kn = h("div", "kt-knoepfe");
    kn.append(knopf("neue Suche", "", () => { z = neu("halbieren", { ziel: SUCHEN[(SUCHEN.indexOf(z.ziel) + 1) % SUCHEN.length] }); zeichnen(); }),
      knopf("eine Wertung, die es nicht gibt", "", () => { z = neu("halbieren", { ziel: 1400 }); zeichnen(); }), knopf("von vorn", "ruhig", () => { z = neu("halbieren", { ziel: z.ziel }); zeichnen(); }));
    if (mitPython) kn.append(knopf(z.python ? "in Worten zeigen" : "als Python zeigen", "ruhig", () => { z.python = !z.python; zeichnen(); }));
    links.append(kn);
    seite.append(zaehler(["Fragen", z.fragen], ["noch möglich", z.gefunden >= 0 ? 1 : Math.max(0, z.rechts - z.links + 1)]), h("h3", "", "Protokoll"), protokollEl());
    flaeche.append(links, seite);
  }

  try { Object.assign(eigen, JSON.parse(sessionStorage.getItem("lernraum.karten.eigen") || "{}")); } catch (e) {}
  if (z.tisch === "zaehlen") z.eigen = Object.assign({}, eigen);
  zeichnen();

  // ─── Film (Vortrag, wie der Code-Film) ─────────────────────────────────────────────
  function filmSchritt(x) {
    const a = x.aktion, zahl = v => parseInt(v, 10);
    if (a === "neu") z = neu(z.tisch, z.tisch === "halbieren" ? { ziel: z.ziel } : { n: z.n, start: z.start });
    else if (a === "karten") { if (z.tisch === "zaehlen") { z.n = zahl(x.wert); z.meldung = ""; } else z = neu(z.tisch, { n: zahl(x.wert) }); }
    else if (a === "vergleiche") vergleiche(zahl(x.von) - 1, zahl(x.nach) - 1);
    else if (a === "tausche") tausche();
    else if (a === "aufdecken") aufdecken();
    else if (a === "paar") paar();
    else if (a === "weiter") weiter();
    else if (a === "durchgang") durchgang();
    else if (a === "schaetze") z.geschaetzt[z.n] = zahl(x.wert);
    else if (a === "lauf") lauf();
    else if (a === "suche") z = neu("halbieren", { ziel: zahl(x.wert) });
    else if (a === "decke") decke(zahl(x.wert) - 1);
    else if (a === "python") z.python = true;
  }
  function filmHerstellen(liste) { z = neu(tisch); if (z.tisch === "zaehlen") z.eigen = {}; liste.forEach(filmSchritt); zeichnen(); }
  return { zustand: () => kopie(z), film: { spielen: x => { filmSchritt(x); zeichnen(); }, herstellen: filmHerstellen, laeuft: () => false } };
};
window.Werkstaetten.karten.einleitung = "Mitgliedskarten des Schachportals, verdeckt: Der Tisch sagt nur, welche von zwei Karten die höhere Wertung hat – und zählt jeden Vergleich.";
