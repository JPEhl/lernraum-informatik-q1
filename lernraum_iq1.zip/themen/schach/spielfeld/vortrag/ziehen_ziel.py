# ziehen.py -- das Spiel aus spielfeld.py.
# Neu: Wer zieht, fragt das Spiel.

from brett import zeichne_felder, hebe_hervor, zeichne_pfeil, FELDGROESSE
from zeichenflaeche import zeichne_bild, zeige
from figur import Figur
from spieler import Spieler
from zug import Zug


class Spiel:

    def __init__(self):
        self.__weiss = Spieler("weiß")
        self.__schwarz = Spieler("schwarz")
        self.__am_zug = self.__weiss
        self.__feld: list[list[Figur]] = []
        for zeile in range(8):
            reihe: list[Figur] = []
            for spalte in range(8):
                reihe.append(None)
            self.__feld.append(reihe)
        self.__stelle(Figur("Dame", "weiß", 7, 3), self.__weiss)
        self.__stelle(Figur("König", "weiß", 7, 4), self.__weiss)
        self.__stelle(Figur("Dame", "schwarz", 0, 3), self.__schwarz)
        self.__stelle(Figur("König", "schwarz", 0, 4), self.__schwarz)

    def __stelle(self, figur: Figur, spieler: Spieler) -> None:
        spieler.aufnehmen(figur)
        self.__feld[figur.get_zeile()][figur.get_spalte()] = figur

    def figur_auf(self, zeile: int, spalte: int) -> Figur:
        return self.__feld[zeile][spalte]

    def ziehe(self, zug: Zug) -> bool:
        figur = zug.get_figur()
        if figur.get_farbe() != self.__am_zug.get_farbe():
            return False
        if not figur.darf(zug.get_zeile(), zug.get_spalte(), self):
            return False
        if self.__am_zug == self.__weiss:
            gegner = self.__schwarz
        else:
            gegner = self.__weiss
        opfer = self.figur_auf(zug.get_zeile(), zug.get_spalte())
        if opfer != None:
            gegner.entferne(opfer)
        self.__feld[figur.get_zeile()][figur.get_spalte()] = None
        zug.ausfuehren()
        self.__feld[zug.get_zeile()][zug.get_spalte()] = figur
        self.__am_zug = gegner
        return True

    def zeichne(self, groesse: int) -> None:
        for zeile in range(8):
            for spalte in range(8):
                figur = self.__feld[zeile][spalte]
                if figur != None:
                    zeichne_bild(figur.bildname(), spalte * groesse,
                                 zeile * groesse, groesse)


spiel = Spiel()
dame = spiel.figur_auf(7, 3)
zug = Zug(dame, 3, 3)
schwarze = spiel.figur_auf(0, 3)
schlag = Zug(schwarze, 3, 3)

zeichne_felder()
zeichne_pfeil(zug)
spiel.ziehe(zug)
print(spiel.figur_auf(3, 3).get_art())
print(spiel.ziehe(Zug(dame, 3, 4)))
zeichne_pfeil(schlag)
spiel.ziehe(schlag)
print(spiel.figur_auf(3, 3).get_farbe())
print(spiel.ziehe(Zug(spiel.figur_auf(7, 4), 5, 4)))
spiel.zeichne(FELDGROESSE)
hebe_hervor(dame.get_zeile(), dame.get_spalte())
zeige()
