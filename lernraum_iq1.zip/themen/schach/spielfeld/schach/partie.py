# partie.py -- das Schachbrett.
# Vorbereitet für dieses Thema: partie.py
# fragt nur noch das Spiel (spiel.py). Am
# Start ist das Brett leer.
#
# Umgezogen ins Spiel (ihr schreibt es
# dort): figur_auf_feld -> figur_auf,
# schlage -> ziehe, partie_vorbei ->
# ist_vorbei, das Material -> materialwert.

from zeichenflaeche import neue_flaeche, zeichne_bild, bei_klick, zeige
from zug import Zug
from bedrohung import Bedrohung
from spiel import Spiel

FELDGROESSE = 60
HELL = "#eeeed2"
DUNKEL = "#769656"

flaeche = neue_flaeche(8 * FELDGROESSE, 8 * FELDGROESSE)


# ------------------------ das Brett

def zeichne_felder() -> None:
    for zeile in range(8):
        for spalte in range(8):
            x = spalte * FELDGROESSE
            y = zeile * FELDGROESSE
            if (zeile + spalte) % 2 == 0:
                farbe = HELL
            else:
                farbe = DUNKEL
            flaeche.create_rectangle(x, y, x + FELDGROESSE, y + FELDGROESSE,
                                     fill=farbe, outline=farbe)


def zeichne_figur(name: str, zeile: int, spalte: int) -> None:
    zeichne_bild(name, spalte * FELDGROESSE, zeile * FELDGROESSE, FELDGROESSE)


def hebe_hervor(zeile: int, spalte: int) -> None:
    x = spalte * FELDGROESSE
    y = zeile * FELDGROESSE
    flaeche.create_rectangle(x, y, x + FELDGROESSE, y + FELDGROESSE,
                             outline="red", width=4)


def zeichne_punkt(zeile: int, spalte: int) -> None:
    x = spalte * FELDGROESSE + FELDGROESSE // 2
    y = zeile * FELDGROESSE + FELDGROESSE // 2
    r = FELDGROESSE // 6
    if (zeile + spalte) % 2 == 0:
        farbe = "#babaa4"
    else:
        farbe = "#5c7543"
    flaeche.create_oval(x - r, y - r, x + r, y + r,
                        fill=farbe, outline=farbe)


def zeichne_pfeil(zug: Zug) -> None:
    mitte = FELDGROESSE // 2
    x1 = zug.get_start_spalte() * FELDGROESSE + mitte
    y1 = zug.get_start_zeile() * FELDGROESSE + mitte
    x2 = zug.get_spalte() * FELDGROESSE + mitte
    y2 = zug.get_zeile() * FELDGROESSE + mitte
    flaeche.create_line(x1, y1, x2, y2, fill="#1565c0", width=6,
                        arrow="last", arrowshape=(18, 22, 7))


def zeichne_bedrohung(bedrohung: Bedrohung) -> None:
    if bedrohung.ist_echt():
        mitte = FELDGROESSE // 2
        angreifer = bedrohung.get_angreifer()
        ziel = bedrohung.get_ziel()
        x1 = angreifer.get_spalte() * FELDGROESSE + mitte
        y1 = angreifer.get_zeile() * FELDGROESSE + mitte
        x2 = ziel.get_spalte() * FELDGROESSE + mitte
        y2 = ziel.get_zeile() * FELDGROESSE + mitte
        flaeche.create_line(x1, y1, x2, y2,
                            fill="red", width=4,
                            arrow="last",
                            arrowshape=(14, 17, 6))


# ------------------------ die Aufstellung

spiel = Spiel()
gewaehlt = None
letzter_zug = None


def zeige_ziele() -> None:
    for zeile in range(8):
        for spalte in range(8):
            if gewaehlt.darf(zeile, spalte, spiel):
                ziel = spiel.figur_auf(zeile, spalte)
                if ziel == None:
                    zeichne_punkt(zeile, spalte)
                else:
                    zeichne_bedrohung(Bedrohung(gewaehlt, ziel))


def zeichne_alles() -> None:
    flaeche.delete("all")
    zeichne_felder()
    spiel.zeichne(FELDGROESSE)
    if gewaehlt != None:
        hebe_hervor(gewaehlt.get_zeile(), gewaehlt.get_spalte())
        zeige_ziele()
    if letzter_zug != None:
        zeichne_pfeil(letzter_zug)
    if spiel.ist_vorbei():
        flaeche.create_text(4 * FELDGROESSE, 4 * FELDGROESSE,
                            text="Die Partie ist aus.",
                            font=("Arial", 28), fill="red")


# ------------------------ der Klick

def klick(x: int, y: int) -> None:
    global gewaehlt, letzter_zug
    if spiel.ist_vorbei():
        return
    spalte = x // FELDGROESSE
    zeile = y // FELDGROESSE
    am_zug = spiel.get_am_zug()
    figur = spiel.figur_auf(zeile, spalte)
    if figur != None and figur.get_farbe() == am_zug.get_farbe():
        gewaehlt = figur
    elif gewaehlt != None:
        zug = Zug(gewaehlt, zeile, spalte)
        if spiel.ziehe(zug):
            letzter_zug = zug
            gewaehlt = None
            print("Weiß:", spiel.materialwert("weiß"),
                  "Schwarz:", spiel.materialwert("schwarz"))
            print("Am Zug:", spiel.get_am_zug().get_farbe())
            if spiel.ist_vorbei():
                print("Ein König ist gefallen.")
    zeichne_alles()


zeichne_alles()
bei_klick(klick)
zeige()
