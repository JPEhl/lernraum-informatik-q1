// Werkstatt "Netz" -- ein Nachbau von Filius im Lernraum (Kapitel netz, E.1, ab 27.10.2026). Lehrer: „Sehr gerne würde
// ich die Funktionsweise von Filius in einer Werkstatt auf der Seite nachbilden.“ Lehrerwahl aus den Attrappen
// (werkstatt/informatik/planung/netz_werkstatt/): ① B -- oben der Netzplan, darunter fest Befehlszeile und
// Datenaustausch, die Nachricht laeuft als Umschlag sichtbar ueber das Kabel, ihre Zeile leuchtet in derselben Farbe;
// ④ B -- Datenaustausch mit Nr · Quelle · Ziel · Bemerkung wie Aufgabe 3 des Workshops (die Spalte „Schicht“ erst am
// Tisch web); dazu: „schöner als Filius … modern, … nicht durch Verspieltheit ablenkt“ -- Bewegung nur am Umschlag.
//   * erst vorhersagen, dann ping in der Befehlszeile, dann ▸ eine Nachricht (◂ zurueck, ↺ von vorn) oder ▸▸ alle.
//   * das Netz rechnet wirklich: Suche nach der MAC (ARP, gemerkt bis ↺), Netzmaske, Gateway, Switch, Router; der ping
//     geht hin UND zurueck -- fehlt das Gateway am Ziel, kommt die Anfrage an und die Antwort nicht.
//   * ein Klick auf ein Geraet oeffnet seine Einstellungskarte (Name, IP-Adresse, Netzmaske; Gateway ab Tisch router).
//   * der Datenaustausch zeigt, was der Rechner der offenen Befehlszeile gesehen hat (wie in Filius je Geraet).
// Optionen: tische='kabel' (Auswahl und Reihenfolge; ohne: alle gebauten). Einbinden: Werkstaetten.netz(element, opt)
window.Werkstaetten = window.Werkstaetten || {};
window.Werkstaetten.netz = function (wurzel, opt) {
  opt = opt || {};
  const MASKE = "255.255.255.0";
  // die Gepaecksuche auf dem Webserver 0.12 (Tisch web) -- Text, wie ihn der Server schickt (siehe gepaeckSeite)
  const GEPAECK_INDEX = `<!DOCTYPE html>
<html>
<head>
  <title>Gepäcksuche</title>
  <link rel="stylesheet" href="flughafen.css">
</head>
<body>
<h1>Gepäcksuche</h1>
<p class="unter">Flughafen · Fundstelle</p>
<img src="bilder/koffer.svg" alt="Ein roter Koffer">
<h2>Ein Koffer fehlt?</h2>
<p>Geben Sie die Nummer von Ihrem Gepäckschein ein.
Wir suchen überall, auch dort, wo Koffer eigentlich
nicht hindürfen.</p>
<p class="schein">Gepäckschein _ _ _ _ _ _</p>
</body>
</html>`;
  const FLUGHAFEN_CSS = `body { font-family: system-ui, "Segoe UI", sans-serif; margin: 14px 18px; color: #1c1b1a; font-size: 15px; }
h1 { color: #c8352b; font-size: 1.35em; margin: 0; border-bottom: 3px solid #c8352b; padding-bottom: .1em; }
.unter { color: #6f6a63; margin: .2em 0 .5em; font-size: .9em; }
img { float: right; width: 72px; margin: 0 0 .4em 1em; }
h2 { font-size: 1.05em; margin: .3em 0 .2em; }
p { line-height: 1.35; margin: 0 0 .5em; }
.schein { display: inline-block; border: 1.5px solid #e6e1d8; border-radius: 10px; padding: .15em .7em; font-family: ui-monospace, Consolas, monospace; color: #6f6a63; }`;
  // bilder/koffer.svg -- der Namensraum kommt beim Einbetten dazu (SVGNS, keine Adresse im Quelltext der Seite: K5)
  const KOFFER_SVG = '<svg viewBox="0 0 120 120" width="120" height="120"><path d="M44 30 V18 a6 6 0 0 1 6 -6 h20 a6 6 0 0 1 6 6 V30" fill="none" stroke="#2b3037" stroke-width="6" stroke-linecap="round"/><rect x="22" y="28" width="76" height="74" rx="12" fill="#c8352b"/><rect x="28" y="33" width="10" height="62" rx="5" fill="#fff" opacity=".18"/><rect x="46" y="28" width="7" height="74" fill="#8f2019"/><rect x="67" y="28" width="7" height="74" fill="#8f2019"/><circle cx="36" cy="106" r="6" fill="#2b3037"/><circle cx="84" cy="106" r="6" fill="#2b3037"/></svg>';
  // Ein Tisch: Geraete (x, y im viewBox 1000 breit), Kabel mit Anschlussnummern, Netze als Flaechen, die Vorhersage.
  // Erst gebaut ist kabel; die anderen kommen mit ihren Themen (dienst, router, web, frei).
  const ALLE = {
    kabel: {
      name: "Zwei Rechner", hoehe: 190, felder: ["name", "ip", "maske"],
      frage: "Wie viele Nachrichten gehen beim ping über das Kabel?",
      geraete: [
        { id: "r10", art: "rechner", name: "Rechner 0.10", x: 230, y: 92, ports: [{ ip: "192.168.0.10", maske: MASKE }] },
        { id: "r11", art: "rechner", name: "Rechner 0.11", x: 770, y: 92, ports: [{ ip: "192.168.0.11", maske: MASKE }] },
      ],
      kabel: [{ a: "r10", pa: 0, b: "r11", pb: 0 }],
      netze: [],
    },
    // dienst (28.10.): drei Rechner, ein Anschluss je Rechner -- in der Mitte die Luecke (Attrappe ② B), auf dem Server
    // laeuft ein Echo-Dienst; der Client ist die Befehlszeile (verbinde, sende)
    dienst: {
      name: "Drei Rechner", hoehe: 330, felder: ["name", "ip", "maske"],
      frage: "Wie viele Nachrichten gehen über das Kabel?",
      geraete: [
        { id: "r10", art: "rechner", name: "Rechner 0.10", x: 170, y: 82, ports: [{ ip: "192.168.0.10", maske: MASKE }] },
        { id: "r11", art: "rechner", name: "Rechner 0.11", x: 170, y: 252, ports: [{ ip: "192.168.0.11", maske: MASKE }] },
        { id: "sw", art: "fehlt", soll: "switch", name: "Switch", x: 500, y: 167, ports: [] },
        { id: "s12", art: "server", name: "Server 0.12", x: 830, y: 167, ports: [{ ip: "192.168.0.12", maske: MASKE }],
          dienste: [{ name: "Echo-Server", port: 55555 }] },
      ],
      kabel: [{ a: "r10", pa: 0, b: "sw", pb: 0 }, { a: "r11", pa: 0, b: "sw", pb: 1 }, { a: "s12", pa: 0, b: "sw", pb: 2 }],
      netze: [],
    },
  };
  // router (28.10.): Netz 0 und Netz 1, je zwei Rechner und ein Switch, dazwischen der Router (0.1 | 1.1), alles
  // verkabelt, die Gateways leer -- Fehler zuerst: der ping an 1.10 geht gar nicht erst los. Flach genug fuer den
  // Vortrag (mit einem dritten Netz waere die Werkstatt hoeher als der Schirm).
  const zweiNetze = () => ({
    geraete: [
      { id: "r10", art: "rechner", name: "Rechner 0.10", x: 105, y: 95, ports: [{ ip: "192.168.0.10", maske: MASKE }], gateway: "" },
      { id: "r11", art: "rechner", name: "Rechner 0.11", x: 105, y: 235, ports: [{ ip: "192.168.0.11", maske: MASKE }], gateway: "" },
      { id: "sw0", art: "switch", name: "Switch", x: 275, y: 165, ports: [] },
      { id: "rt", art: "router", name: "Router", x: 500, y: 165, ports: [{ ip: "192.168.0.1", maske: MASKE }, { ip: "192.168.1.1", maske: MASKE }] },
      { id: "sw1", art: "switch", name: "Switch", x: 725, y: 165, ports: [] },
      { id: "r110", art: "rechner", name: "Rechner 1.10", x: 895, y: 95, ports: [{ ip: "192.168.1.10", maske: MASKE }], gateway: "" },
      { id: "r111", art: "rechner", name: "Rechner 1.11", x: 895, y: 235, ports: [{ ip: "192.168.1.11", maske: MASKE }], gateway: "" },
    ],
    kabel: [{ a: "r10", pa: 0, b: "sw0", pb: 0 }, { a: "r11", pa: 0, b: "sw0", pb: 1 }, { a: "sw0", pa: 2, b: "rt", pb: 0 },
            { a: "rt", pa: 1, b: "sw1", pb: 2 }, { a: "sw1", pa: 0, b: "r110", pb: 0 }, { a: "sw1", pa: 1, b: "r111", pb: 0 }],
    netze: [{ name: "Netz 0 · 192.168.0", x: 8, y: 4, w: 372, h: 314 }, { name: "Netz 1 · 192.168.1", x: 620, y: 4, w: 372, h: 314 }],
  });
  ALLE.router = Object.assign({ name: "Zwei Netze", hoehe: 322, felder: ["name", "ip", "maske", "gateway"], frage: "Wie viele Nachrichten gehen über das Kabel?" }, zweiNetze());
  // drei (nur in der Uebung von router, uebung.md `tische: drei`): dazu Netz 2 mit 2.10 am dritten Router-Anschluss,
  // der noch keine Adresse hat -- Fehlerbild „Router-Anschluss ohne Adresse“ und Kuer
  ALLE.drei = (() => {
    const n = zweiNetze();
    n.geraete.find(g => g.id === "rt").ports.push({ ip: "", maske: MASKE });
    n.geraete.push({ id: "r210", art: "rechner", name: "Rechner 2.10", x: 500, y: 398, ports: [{ ip: "192.168.2.10", maske: MASKE }], gateway: "" });
    n.kabel.push({ a: "rt", pa: 2, b: "r210", pb: 0 });
    n.netze.push({ name: "Netz 2 · 192.168.2", x: 290, y: 326, w: 315, h: 162 });
    return Object.assign({ name: "Drei Netze", hoehe: 492, felder: ["name", "ip", "maske", "gateway"], frage: "Wie viele Nachrichten gehen über das Kabel?" }, n);
  })();
  // web (namen, 29.10.): Netz 0 mit Rechner 0.10 und dem Webserver 0.12 (die Gepaecksuche), Netz 1 mit Rechner 1.10 und
  // dem DNS-Server 1.20 -- die Namensfrage geht ueber den Router (eigenes Netz 2 wie im Workshop waere fuer den Vortrag
  // zu hoch). Gateways und DNS-Server sind eingetragen, nur der Eintrag der Gepaecksuche fehlt: Mit der Nummer kommt
  // die Seite, mit dem Namen nicht (Themenplan). Ab hier: Browser, host, Spalte Schicht, Lupe (Attrappe ① C).
  ALLE.web = (() => {
    const n = zweiNetze(), um = { r11: "web", r111: "dns" };
    n.kabel.forEach(k => { k.a = um[k.a] || k.a; k.b = um[k.b] || k.b; });
    n.geraete.forEach(g => {
      if (g.id === "r11") Object.assign(g, { id: "web", art: "server", name: "Webserver 0.12", ports: [{ ip: "192.168.0.12", maske: MASKE }], dienste: [{ name: "Webserver", port: 80 }] });
      if (g.id === "r111") Object.assign(g, { id: "dns", art: "server", name: "DNS-Server 1.20", ports: [{ ip: "192.168.1.20", maske: MASKE }], dienste: [{ name: "DNS-Server", port: 53 }],
        eintraege: [{ name: "www.flughafen-wetter.de", ip: "192.168.1.10" }] });
      if (g.art === "rechner" || g.art === "server") { g.gateway = g.ports[0].ip.startsWith("192.168.0.") ? "192.168.0.1" : "192.168.1.1"; g.dns = "192.168.1.20"; }
    });
    return Object.assign({ name: "Mit Webserver", hoehe: 322, felder: ["name", "ip", "maske", "gateway", "dns"], web: true, frage: "Wie viele Nachrichten gehen über das Kabel?" }, n);
  })();
  // fehler (nur in der Uebung von namen, Kuer): der Tisch web mit drei Fehlern, die Rechner 1.10 nacheinander trifft,
  // wenn er www.gepaeck-suche.de oeffnet -- DNS-Server falsch (1.2, es gibt ihn nicht), Eintrag mit vertauschten
  // Ziffern (0.21), Gateway am Webserver leer (die Verbindung kommt an, die Antwort nicht)
  ALLE.fehler = (() => {
    const n = ALLE.web, k = JSON.parse(JSON.stringify({ geraete: n.geraete, kabel: n.kabel, netze: n.netze }));
    k.geraete.forEach(g => {
      if (g.id === "r110") g.dns = "192.168.1.2";
      if (g.id === "web") g.gateway = "";
      if (g.id === "dns") g.eintraege.push({ name: "www.gepaeck-suche.de", ip: "192.168.0.21" });
    });
    return Object.assign({}, n, { name: "Drei Fehler" }, k);
  })();
  // formular (webseite/meldung, 09.11.): web, der Eintrag der Gepaecksuche steht schon im DNS-Server. Gesendet wird von
  // Rechner 1.10 aus Netz 1 -- die Meldung geht ueber den Router. Neu: Der Browser zeigt die Seiten der Klasse
  // (opt.datei im Vortrag als meldung.html, opt.ordner in der Uebung), ein Formular laesst sich abschicken (der Server
  // antwortet mit dem Abholschein), und der Router hat einen Datenaustausch (mitlesen): Wer liest die Meldung, wer nicht?
  ALLE.formular = (() => {
    const n = ALLE.web, k = JSON.parse(JSON.stringify({ geraete: n.geraete, kabel: n.kabel, netze: n.netze }));
    k.geraete.forEach(g => { if (g.id === "dns") g.eintraege.push({ name: "www.gepaeck-suche.de", ip: "192.168.0.12" }); });
    return Object.assign({}, n, { name: "Mit Formular", start: "r110", mitlesen: true, formular: true }, k);
  })();
  const BEKANNT = ["kabel", "dienst", "router", "drei", "web", "fehler", "formular"];
  const namen = String(opt.tische || BEKANNT.join("|")).split("|").map(x => x.trim()).filter(x => ALLE[x]);
  const tische = (namen.length ? namen : ["kabel"]).map(n => ({ kennung: n, vorlage: ALLE[n] }));
  const RUHIG = window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;
  // der SVG-Namensraum aus einem geparsten Element -- K5 duldet keine externe Adresse in der Seite (auch nicht als xmlns)
  const SVGNS = (() => { const d = document.createElement("div"); d.innerHTML = "<svg></svg>"; return d.firstChild.namespaceURI; })();
  const h = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };
  const s = (tag, attr) => { const e = document.createElementNS(SVGNS, tag); for (const k in attr || {}) e.setAttribute(k, attr[k]); return e; };

  // ---------- Adressen ----------
  const zahlen = ip => String(ip).trim().split(".");
  const gueltig = ip => { const t = zahlen(ip); return t.length === 4 && t.every(z => /^\d{1,3}$/.test(z) && +z <= 255); };
  const alsZahl = ip => zahlen(ip).reduce((a, z) => a * 256 + (+z), 0);
  const imNetz = (ip, port) => gueltig(ip) && gueltig(port.ip) && gueltig(port.maske) && ((alsZahl(ip) ^ alsZahl(port.ip)) & alsZahl(port.maske)) === 0 && (alsZahl(port.maske) >>> 0) !== 0;
  const kurz = ip => gueltig(ip) ? zahlen(ip).slice(2).join(".") : ip;
  function mac(g, p) {
    // fest aus Geraet und Anschluss gerechnet -- dieselbe Karte hat immer dieselbe MAC
    let x = 2166136261; for (const c of g.id + "/" + p) { x ^= c.charCodeAt(0); x = Math.imul(x, 16777619) >>> 0; }
    const b = []; for (let i = 0; i < 6; i++) { x = Math.imul(x ^ (x >>> 13), 2654435761) >>> 0; b.push(((x >>> 8) & 255).toString(16).toUpperCase().padStart(2, "0")); }
    return b.join(":");
  }

  // ---------- Zustand ----------
  let tisch, netz, wahl, karteOffen = null, lauf = null, belegt = false, anim = 0;
  const arp = new Map();          // "geraet|ip" -> true, gemerkt bis ↺
  const gesehen = new Map();      // geraet -> [Nachricht] (der Datenaustausch je Geraet)
  const konsole = new Map();      // geraet -> [{text, art}]
  const verlauf = new Map();      // geraet -> [Befehle] (Pfeil hoch)
  const verbunden = new Map();    // geraet -> {ip, port, dienst}: die Verbindung des Clients (dienst, 28.10.)
  const brStand = new Map();      // geraet -> {adresse, art: laedt|seite|fehler, text}: was der Browser zeigt (namen, 29.10.)
  let ansicht = "befehlszeile", lupe = null;   // unten links Befehlszeile oder Browser; die Nachricht unter der Lupe
  // Seiten der Klasse (Tisch formular, 09.11.): im Vortrag die Datei des Schritts (opt.datei, im Browser meldung.html),
  // in der Uebung der Ordner der Arbeit (opt.ordner) -- vom Lernraum-Server geholt und gemerkt: Der Film baut seinen
  // Stand ohne Warten auf, er nimmt, was gemerkt ist.
  const seiten = new Map();
  // ausserhalb des Lernraums (Probe, Vorfuehrseite): opt.seiten = {"meldung.html": "<!DOCTYPE html>…"} -- nichts wird geholt
  for (const k in opt.seiten || {}) seiten.set(k, opt.seiten[k]);
  const ALS = opt.als || "meldung.html";
  const seitenBasis = () => opt.datei && opt.basis ? opt.basis + "vortrag/" : opt.ordner || "";
  const seiteUrl = datei => opt.datei && opt.basis ? (datei === ALS ? opt.basis + "vortrag/" + opt.datei : null)
    : opt.ordner && /^[\w.-]+\.html$/.test(datei) ? opt.ordner + datei : null;
  function seiteHolen(datei) {
    const url = seiteUrl(datei);
    if (!url || !window.fetch) return Promise.resolve(seiten.get(datei));
    return fetch(url + "?t=" + Date.now(), { credentials: "same-origin" }).then(r => r.ok ? r.text() : null)
      .then(t => { if (t == null) seiten.delete(datei); else seiten.set(datei, t); return t; }, () => seiten.get(datei));
  }

  // ---------- Aufbau ----------
  wurzel.textContent = "";
  wurzel.classList.add("netz-ws");
  const reiter = h("div", "tische");
  const kopf = h("div", "kopfzeile-ws");
  const vorh = h("label", "vorhersage");
  const vIn = h("input"); vIn.type = "number"; vIn.min = 0; vIn.max = 99; vIn.placeholder = "?";
  // vorhersage="aus": im Plenum wird gemeinsam vermutet und diskutiert, das Feld stuende nur im Weg (Lehrer 28.10., kabel W2)
  if (String(opt.vorhersage || "") === "aus") vorh.style.display = "none";
  const kZur = h("button", "", "◂"); kZur.title = "eine Nachricht zurück";
  const kEin = h("button", "primaer", "▸ eine Nachricht");
  const kAlle = h("button", "", "▸▸ alle");
  const kNeu = h("button", "", "↺"); kNeu.title = "von vorn";
  // Tempo der Umschlaege: 1 langsam … 5 schnell, 3 wie bisher (gilt ab der naechsten Nachricht)
  const TEMPO = [2.2, 1.5, 1, .6, .3];
  const tempo = h("label", "tempo");
  const tIn = h("input"); tIn.type = "range"; tIn.min = 1; tIn.max = 5; tIn.step = 1; tIn.value = 3; tIn.setAttribute("aria-label", "Tempo der Nachrichten");
  tempo.append(h("span", "", "langsam"), tIn, h("span", "", "schnell"));
  const faktor = () => TEMPO[(+tIn.value || 3) - 1];
  // der Tempo-Regler steht klein unter dem Plan (in der Kopfzeile waere sie zu voll) -- ohne Vorhersage ist dort Platz:
  // dann steht er links in der Kopfzeile, und der Plan bekommt die Zeile (meldung W3, 10.11.: „Damit man unten was
  // sieht, ist der Netzplan super klein“)
  const tempoOben = String(opt.vorhersage || "") === "aus";
  kopf.append(vorh); if (tempoOben) kopf.append(tempo);   // das Feld bleibt (versteckt), Probe und Film lesen es
  kopf.append(h("span", "luecke"), kZur, kEin, kAlle, kNeu);
  const buehne = h("div", "buehne");
  const planBox = h("div", "plan");
  const planSpalte = h("div", "planspalte"); planSpalte.append(planBox); if (!tempoOben) planSpalte.append(tempo);
  const karte = h("div", "einstellung"); karte.hidden = true;
  buehne.append(planSpalte, karte);
  const unten = h("div", "unten");
  const bzBox = h("div", "befehlszeile");
  const bzReiter = h("div", "bz-reiter");
  const bz = h("div", "konsole");
  const bzAus = h("div", "ausgabe");
  const bzZeile = h("label", "eingabe");
  const bzIn = h("input"); bzIn.type = "text"; bzIn.spellcheck = false; bzIn.autocomplete = "off"; bzIn.setAttribute("aria-label", "Befehl");
  bzZeile.append(h("span", "prompt", "/>"), bzIn);
  bz.append(bzAus, bzZeile);
  // der Browser (Tisch web): Adresszeile und Seite statt der Befehlszeile, umgeschaltet oben rechts an den Reitern
  const bzModus = h("span", "bz-modus");
  const mBz = h("button", "", "Befehlszeile"), mBr = h("button", "", "Browser");
  bzModus.append(mBz, mBr);
  const br = h("div", "browser"); br.hidden = true;
  const brLeiste = h("form", "br-leiste");
  const brIn = h("input"); brIn.type = "text"; brIn.spellcheck = false; brIn.autocomplete = "off"; brIn.setAttribute("aria-label", "Adresse");
  brIn.placeholder = "www.gepaeck-suche.de";
  const brLos = h("button", "primaer", "Los"); brLos.type = "submit";
  brLeiste.append(h("span", "br-vorn", "http://"), brIn, brLos);
  // Quelltext (Attrappe ⑥ A, 29.10.): was der Server geschickt hat -- Text mit spitzen Klammern
  const brQuelle = h("button", "br-quelle"); brQuelle.type = "button"; brQuelle.setAttribute("aria-pressed", "false");
  // eng (Vortrag, meldung W2): „</>“ statt „Quelltext“, damit die Adresse lesbar bleibt
  brQuelle.title = "Quelltext"; brQuelle.append(h("span", "lang", "Quelltext"), h("span", "kurz", "</>"));
  brLeiste.append(brQuelle);
  let quelltextAn = false, brGezeigt = {};
  const brSeite = h("div", "br-seite");
  br.append(brLeiste, brSeite);
  bzBox.append(bzReiter, bz, br);
  const daBox = h("div", "datenaustausch");
  const daTitel = h("p", "kasten-titel");
  const daTab = h("table", "da");
  daBox.append(daTitel, daTab);
  unten.append(bzBox, daBox);
  const meldung = h("p", "meldung");
  wurzel.append(reiter, kopf, buehne, unten, meldung);
  tische.forEach(t => { const b = h("button", "", t.vorlage.name); b.addEventListener("click", () => { tisch = t; start(); }); t.knopf = b; reiter.append(b); });
  reiter.hidden = tische.length < 2;

  // ---------- das Netz ----------
  const geraet = id => netz.geraete.find(g => g.id === id);
  const endgeraet = g => g.art !== "switch";
  // ein Kabel zur Luecke fuehrt ins Leere (dienst, Runde 1): es gilt erst, wenn dort ein Geraet steht
  const offen = k => geraet(k.a).art === "fehlt" || geraet(k.b).art === "fehlt";
  const kabelAn = (g, p) => netz.kabel.filter(k => !offen(k) && ((k.a === g.id && (p == null || k.pa === p)) || (k.b === g.id && (p == null || k.pb === p))));
  const anderes = (k, g) => k.a === g.id ? geraet(k.b) : geraet(k.a);
  // Alles, was von Anschluss p des Geraets g ohne Router erreichbar ist: Weg dorthin je Geraet (ueber Switches)
  function segment(g, p) {
    const wege = new Map(); const schlange = [];
    kabelAn(g, p).forEach(k => { const n = anderes(k, g); if (!wege.has(n.id)) { wege.set(n.id, [g.id, n.id]); schlange.push(n); } });
    while (schlange.length) {
      const n = schlange.shift();
      if (n.art !== "switch") continue;
      kabelAn(n).forEach(k => { const m = anderes(k, n); if (m.id !== g.id && !wege.has(m.id)) { wege.set(m.id, wege.get(n.id).concat(m.id)); schlange.push(m); } });
    }
    return wege;
  }
  const portFuer = (g, ip) => g.ports.findIndex(p => imNetz(ip, p));
  // hoert niemand die Suche, faehrt sie das Kabel zur Luecke entlang und verblasst dort (dienst, Runde 1)
  const insLeere = g => { const k = netz.kabel.find(x => offen(x) && (x.a === g.id || x.b === g.id)); return k ? [g.id, k.a === g.id ? k.b : k.a] : [g.id]; };
  // Eine Nachricht von Geraet g (als ip von) an ip an zustellen -- ueber Router, so weit es geht.
  // Liefert die Nachrichten (je Strecke eine) und das Geraet, bei dem sie ankam (oder null).
  // zusatz (namen, 29.10.): {transport: {prot, von, an}, anwendung: {prot, text}} -- was die Lupe in den inneren Huellen
  // zeigt; die Schicht der Zeile ist die innerste. Jede Strecke traegt ihre eigenen MAC-Adressen (die IP bleibt).
  function zustellen(g, von, an, bem, liste, art, umschlag, zusatz) {
    for (let schritt = 0; schritt < 8; schritt++) {
      let p = portFuer(g, an), naechste = an;
      if (p < 0) {
        // nicht im eigenen Netz: nur ueber das Gateway -- ohne Gateway geht nichts los, nicht einmal die Suche (wie Filius)
        if (g.art === "router" || !(g.gateway && gueltig(g.gateway))) return null;
        // ein Gateway aus einem fremden Netz erreicht der Rechner selbst nicht -- es zaehlt wie keines (router, 28.10.:
        // vorher fand die Suche den Router ueber seinen anderen Anschluss)
        p = portFuer(g, g.gateway); if (p < 0) return null;
        naechste = g.gateway;
      }
      const port = g.ports[p]; if (!port) return null;
      const wege = segment(g, p);
      const ziel = [...wege.keys()].map(geraet).find(x => endgeraet(x) && x.ports.some(q => q.ip === naechste));
      const schluessel = g.id + "|" + naechste;
      if (!arp.has(schluessel)) {
        const alle = [...wege.keys()].map(geraet).filter(endgeraet);
        liste.push({ von: port.ip, an: naechste, art: "arp", bem: "Suche nach MAC von " + naechste, umschlag: "Suche nach MAC",
          schicht: "Netzzugang", macVon: mac(g, p), macAn: ALLE_MAC,
          weg: ziel ? wege.get(ziel.id) : (alle.length ? wege.get(alle[0].id) : insLeere(g)), sieht: [g.id].concat(alle.map(x => x.id)), verpufft: !ziel });
        if (!ziel) return null;
        const zp = ziel.ports.findIndex(q => q.ip === naechste);
        liste.push({ von: naechste, an: port.ip, art: "arp", bem: naechste + ": " + mac(ziel, zp), umschlag: "MAC-Antwort", weg: wege.get(ziel.id).slice().reverse(), sieht: [g.id, ziel.id],
          schicht: "Netzzugang", macVon: mac(ziel, zp), macAn: mac(g, p) });
        // die Suche traegt die MAC des Fragenden -- der Gefragte merkt sie sich gleich mit (wie in Filius: 10 Nachrichten)
        arp.set(schluessel, true); arp.set(ziel.id + "|" + port.ip, true);
      }
      if (!ziel) return null;
      const z = Object.assign({ schicht: SCHICHT[art || "icmp"] }, zusatz || {});
      if (z.anwendung) z.schicht = "Anwendung"; else if (z.transport) z.schicht = "Transport";
      liste.push(Object.assign(z, { von, an, art: art || "icmp", bem, umschlag: umschlag || bem.replace(/ \(.*\)/, ""), weg: wege.get(ziel.id), sieht: [g.id, ziel.id],
        macVon: mac(g, p), macAn: mac(ziel, ziel.ports.findIndex(q => q.ip === naechste)) }));
      if (ziel.ports.some(q => q.ip === an)) return ziel;
      if (ziel.art !== "router") return null;
      g = ziel;
    }
    return null;
  }
  const ALLE_MAC = "FF:FF:FF:FF:FF:FF";
  const SCHICHT = { arp: "Netzzugang", icmp: "Internet", tcp: "Transport", dns: "Anwendung", http: "Anwendung" };
  // ping: viermal hin und zurueck. Liefert die Nachrichten; jede traegt die Zeilen, die nach ihr in der Befehlszeile stehen.
  function ping(q, zielIp) {
    const liste = [], von = q.ports[0].ip;
    for (let i = 1; i <= 4; i++) {
      const anfang = liste.length;
      const da = zustellen(q, von, zielIp, "Echo request (ping)", liste);
      const zurueck = da && zustellen(da, zielIp, von, "Echo reply (pong)", liste);
      // ging nichts los (kein Weg aus dem eigenen Netz), sagt die Befehlszeile das wie Windows -- und zaehlt es nicht als gesendet
      const zeile = zurueck === q ? { text: "Antwort von " + zielIp + ": Folge " + i + ", Zeit " + (38 + (i * 7) % 11) + " ms" }
        : { text: liste.length > anfang ? "Keine Antwort von " + zielIp + "." : "Ziel nicht erreichbar.", art: "rot" };
      liste.gesendet = (liste.gesendet || 0) + (liste.length > anfang ? 1 : 0);
      if (liste.length > anfang) (liste[liste.length - 1].danach = liste[liste.length - 1].danach || []).push(zeile);
      else liste.push({ leer: true, danach: [zeile] });
      liste.ok = (liste.ok || 0) + (zurueck === q ? 1 : 0);
    }
    const stat = { text: liste.gesendet + " gesendet, " + liste.ok + " empfangen", art: liste.ok ? "" : "rot" };
    liste[liste.length - 1].danach.push(stat);
    return liste.filter(m => !m.leer || m.danach);
  }

  // ---------- Zeichnen: der Plan ----------
  let svg, lagen;
  function zeichnePlan() {
    planBox.textContent = "";
    const H = tisch.vorlage.hoehe;
    svg = s("svg", { viewBox: "0 0 1000 " + H, class: "netzplan", role: "img", "aria-label": "Netzplan" });
    lagen = { netze: s("g"), kabel: s("g"), geraete: s("g"), umschlag: s("g") };
    Object.values(lagen).forEach(l => svg.append(l));
    netz.netze.forEach(n => {
      lagen.netze.append(s("rect", { class: "netzflaeche", x: n.x, y: n.y, width: n.w, height: n.h, rx: 22 }));
      const t = s("text", { class: "netzname", x: n.x + 18, y: n.y + 30 }); t.textContent = n.name; lagen.netze.append(t);
    });
    netz.kabel.forEach(k => {
      const a = geraet(k.a), b = geraet(k.b);
      k.linie = s("line", { class: "kabel" + (offen(k) ? " offen" : ""), x1: a.x, y1: a.y, x2: b.x, y2: b.y });
      lagen.kabel.append(k.linie);
    });
    netz.geraete.forEach(g => lagen.geraete.append(geraetBild(g)));
    planBox.append(svg);
  }
  function geraetBild(g) {
    const gr = s("g", { class: "geraet " + g.art + (g.id === wahl ? " gewaehlt" : "") + (karteOffen === g.id ? " offen" : ""), transform: "translate(" + g.x + "," + g.y + ")", tabindex: 0, role: "button" });
    gr.setAttribute("aria-label", g.name);
    gr.append(s("rect", { class: "halo", x: -70, y: -58, width: 140, height: 140, rx: 20 }));
    if (g.art === "fehlt") {
      gr.setAttribute("aria-label", "Hier fehlt etwas");
      gr.append(s("rect", { class: "rahmen", x: -66, y: -30, width: 132, height: 60, rx: 14 }));
      const t = s("text", { class: "fehlt-text", x: 0, y: 7, "text-anchor": "middle" }); t.textContent = "hier fehlt etwas";
      gr.append(t);
      const waehlen = () => { karteOffen = karteOffen === g.id ? null : g.id; zeichnePlan(); zeichneKarte(); };
      gr.addEventListener("click", waehlen);
      gr.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); waehlen(); } });
      return gr;
    }
    if (g.art === "rechner") {
      gr.append(s("rect", { class: "rahmen", x: -40, y: -44, width: 80, height: 54, rx: 7 }),
        s("rect", { class: "schirm", x: -34, y: -38, width: 68, height: 42, rx: 3 }),
        s("path", { class: "fuss", d: "M-7 10 L7 10 L10 22 L-10 22 Z" }),
        s("rect", { class: "fuss", x: -22, y: 21, width: 44, height: 5, rx: 2.5 }),
        s("circle", { class: "led", cx: 0, cy: 7, r: 1.6 }));
    } else if (g.art === "server") {
      gr.append(s("rect", { class: "rahmen", x: -24, y: -46, width: 48, height: 72, rx: 6 }));
      [-34, -22, -10].forEach(y => gr.append(s("rect", { class: "schlitz", x: -15, y, width: 30, height: 5, rx: 2.5 })));
      gr.append(s("circle", { class: "led an", cx: 0, cy: 12, r: 3 }));
    } else if (g.art === "switch") {
      gr.append(s("rect", { class: "rahmen", x: -52, y: -17, width: 104, height: 34, rx: 8 }));
      for (let i = 0; i < 6; i++) gr.append(s("rect", { class: "anschluss", x: -40 + i * 14, y: -4, width: 9, height: 9, rx: 1.5 }), s("circle", { class: "led an", cx: -35.5 + i * 14, cy: -10, r: 1.6 }));
    } else if (g.art === "router") {
      gr.append(s("ellipse", { class: "rahmen", cx: 0, cy: 8, rx: 40, ry: 16 }), s("rect", { class: "rahmen", x: -40, y: -14, width: 80, height: 22 }),
        s("ellipse", { class: "deckel", cx: 0, cy: -14, rx: 40, ry: 16 }),
        s("path", { class: "pfeil", d: "M-22 -18 h30 m-6 -5 l6 5 l-6 5 M22 -10 h-30 m6 -5 l-6 5 l6 5" }));
    }
    const unter = g.art === "switch" ? 40 : g.art === "router" ? 46 : g.art === "server" ? 46 : 48;
    const t1 = s("text", { class: "name", x: 0, y: unter, "text-anchor": "middle" }); t1.textContent = g.name;
    gr.append(t1);
    if (g.art !== "switch") {
      const ips = g.art === "router" ? g.ports.map(p => p.ip || "–").join(" · ") : g.ports[0].ip;
      // am Router ist ein leerer Anschluss „–“ und nicht rot -- rot ist nur, was falsch eingetragen ist (router, 28.10.)
      const falsch = g.art === "router" ? g.ports.some(p => p.ip && !gueltig(p.ip)) : !g.ports.every(p => gueltig(p.ip));
      const t2 = s("text", { class: "ip" + (falsch ? " ungueltig" : ""), x: 0, y: unter + 22, "text-anchor": "middle" }); t2.textContent = ips || "keine IP";
      gr.append(t2);
    }
    const waehlen = () => { if (g.art === "rechner" || g.art === "server" || (g.art === "router" && tisch.vorlage.mitlesen)) { wahl = g.id; zeichneBefehlszeile(); zeichneDaten(); } karteOffen = karteOffen === g.id ? null : g.id; zeichnePlan(); zeichneKarte(); };
    gr.addEventListener("click", waehlen);
    gr.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); waehlen(); } });
    return gr;
  }
  // der Umschlag: faehrt von Geraet zu Geraet die Strecke entlang
  function umschlagBild(m) {
    const gr = s("g", { class: "umschlag " + m.art });
    const w = 184, hh = 52;
    gr.append(s("rect", { class: "papier", x: -w / 2, y: -hh / 2, width: w, height: hh, rx: 7 }),
      s("path", { class: "lasche", d: "M" + (-w / 2 + 2) + " " + (-hh / 2 + 2) + " L0 " + (-hh / 2 + 15) + " L" + (w / 2 - 2) + " " + (-hh / 2 + 2) }));
    const t1 = s("text", { class: "z1", x: 0, y: 5, "text-anchor": "middle" }); t1.textContent = "von " + kurz(m.von) + " an " + kurz(m.an);
    const t2 = s("text", { class: "z2", x: 0, y: 20, "text-anchor": "middle" }); t2.textContent = m.umschlag;
    // die Spitze vorn am Umschlag zeigt, wohin er faehrt (setze() dreht und schiebt sie)
    const spitze = s("g", { class: "spitze" });
    spitze.append(s("circle", { r: 14 }), s("path", { d: "M-6 0 H6 M1 -5 L6 0 L1 5" }));
    gr.append(t1, t2, spitze);
    gr.spitze = spitze; gr.halbB = w / 2; gr.halbH = hh / 2;
    return gr;
  }
  function kabelZwischen(a, b) { return netz.kabel.find(k => (k.a === a && k.b === b) || (k.a === b && k.b === a)); }
  function leuchte(m) {
    netz.kabel.forEach(k => k.linie && k.linie.classList.remove("an"));
    if (!m || m.leer) return;
    for (let i = 1; i < m.weg.length; i++) { const k = kabelZwischen(m.weg[i - 1], m.weg[i]); if (k && k.linie) k.linie.classList.add("an"); }
  }
  function fahre(m, dauer, fertig) {
    lagen.umschlag.textContent = "";
    leuchte(m);
    if (m.leer || m.weg.length < 2) { fertig(); return; }
    const pkt = m.weg.map(id => { const g = geraet(id); return [g.x, g.y - 4]; });
    const strecken = []; let gesamt = 0;
    for (let i = 1; i < pkt.length; i++) { const l = Math.hypot(pkt[i][0] - pkt[i - 1][0], pkt[i][1] - pkt[i - 1][1]); strecken.push(l); gesamt += l; }
    const u = umschlagBild(m); lagen.umschlag.append(u);
    if (tisch.vorlage.web) { u.classList.add("klickbar"); u.addEventListener("click", () => lupeOeffnen(m)); }
    // Ausdehnung des Umschlags in Fahrtrichtung (Mitte bis Vorderkante)
    const vorn = (dx, dy) => Math.abs(dx) * u.halbB + Math.abs(dy) * u.halbH;
    const richtung = i => { const a = pkt[i], b = pkt[i + 1] || pkt[i], l = strecken[i] || 1; return [(b[0] - a[0]) / l, (b[1] - a[1]) / l]; };
    // Halt: kurz vor dem Empfaenger, die Spitze fast am Geraet (dort bleibt der Umschlag stehen, bis die naechste Nachricht kommt)
    const letzte = strecken[strecken.length - 1] || 0, [rx, ry] = richtung(strecken.length - 1);
    const abstand = vorn(rx, ry) + 14 + 46;
    const ende = m.verpufft ? gesamt * 0.55 : Math.max(0, gesamt - Math.min(abstand, letzte * 0.7));
    const setze = f => {
      let rest = f * ende, i = 0;
      while (i < strecken.length - 1 && rest > strecken[i]) { rest -= strecken[i]; i++; }
      const a = pkt[i], b = pkt[i + 1] || pkt[i], t = strecken[i] ? Math.min(1, rest / strecken[i]) : 0;
      u.setAttribute("transform", "translate(" + (a[0] + (b[0] - a[0]) * t).toFixed(1) + "," + (a[1] + (b[1] - a[1]) * t).toFixed(1) + ")");
      const [dx, dy] = richtung(i), v = vorn(dx, dy);
      u.spitze.setAttribute("transform", "translate(" + (dx * v).toFixed(1) + "," + (dy * v).toFixed(1) + ") rotate(" + (Math.atan2(dy, dx) * 180 / Math.PI).toFixed(1) + ")");
    };
    const nr = ++anim;
    if (RUHIG || !dauer || !ende) { setze(1); if (m.verpufft) u.classList.add("weg"); fertig(); return; }
    const t0 = performance.now(), d = dauer * Math.min(1.6, Math.max(.7, ende / 420));
    const zug = jetzt => {
      if (nr !== anim) return;
      const f = Math.min(1, (jetzt - t0) / d), weich = f < .5 ? 2 * f * f : 1 - Math.pow(-2 * f + 2, 2) / 2;
      setze(weich);
      if (f < 1) requestAnimationFrame(zug); else { if (m.verpufft) u.classList.add("weg"); fertig(); }
    };
    requestAnimationFrame(zug);
  }

  // ---------- Einstellungskarte ----------
  function zeichneKarte() {
    karte.textContent = "";
    if (karteOffen === "lupe" && lupe) {
      karte.hidden = false; buehne.classList.add("mit-karte");
      const zu = h("button", "ruhig zu", "×"); zu.title = "schließen"; zu.addEventListener("click", () => { karteOffen = null; lupe = null; zeichnePlan(); zeichneKarte(); });
      karte.append(zu, h("h3", "", "Unter der Lupe"), h("p", "notiz", lupe.bem), lupeBild(lupe));
      return;
    }
    const g = karteOffen && geraet(karteOffen);
    karte.hidden = !g; buehne.classList.toggle("mit-karte", !!g);
    if (!g) return;
    const zu = h("button", "ruhig zu", "×"); zu.title = "schließen"; zu.addEventListener("click", () => { karteOffen = null; zeichnePlan(); zeichneKarte(); });
    karte.append(zu, h("h3", "", g.art === "fehlt" ? "Hier fehlt etwas" : g.name));   // die Luecke verraet ihren Namen nicht
    if (g.art === "fehlt") { lueckeKarte(g); return; }
    if (g.art === "switch") { karte.append(h("p", "notiz", "Ein Switch hat keine IP-Adresse. Er verbindet die Geräte eines Netzes.")); return; }
    const felder = tisch.vorlage.felder;
    const zeile = (titel, wert, setzen, pruef) => {
      const z = h("label", "ezeile"); const i = h("input"); i.type = "text"; i.value = wert || ""; i.spellcheck = false;
      const fehler = h("span", "fehler");
      const zeige = () => { const f = pruef ? pruef(i.value.trim()) : ""; fehler.textContent = f; i.classList.toggle("falsch", !!f); };
      i.addEventListener("change", () => { setzen(i.value.trim()); zeige(); geaendert(); });
      z.append(h("span", "", titel), i, fehler); zeige();
      return z;
    };
    const ipPruef = v => !v ? "" : !gueltig(v) ? "keine gültige IP-Adresse" : /\.(0|255)$/.test(v) ? "endet auf .0 oder .255 – für ein Gerät nicht erlaubt" : "";
    if (felder.includes("name")) karte.append(zeile("Name", g.name, v => { g.name = v || g.name; }));
    g.ports.forEach((p, i) => {
      const nach = g.ports.length > 1 ? " (Anschluss " + (i + 1) + ")" : "";
      if (felder.includes("ip")) karte.append(zeile("IP-Adresse" + nach, p.ip, v => { p.ip = v; }, ipPruef));
      if (felder.includes("maske")) karte.append(zeile("Netzmaske" + nach, p.maske, v => { p.maske = v; }, v => v && !gueltig(v) ? "keine gültige Netzmaske" : ""));
    });
    if (felder.includes("gateway") && g.art !== "router") karte.append(zeile("Gateway", g.gateway, v => { g.gateway = v; }, v => v && !gueltig(v) ? "keine gültige IP-Adresse" : ""));
    if (felder.includes("dns") && g.art !== "router") karte.append(zeile("DNS-Server", g.dns, v => { g.dns = v; }, v => v && !gueltig(v) ? "keine gültige IP-Adresse" : ""));
    (g.dienste || []).forEach(d => karte.append(h("p", "notiz dienst", "Dienst: " + d.name + " · Port " + d.port + " · läuft")));
    if (istWeb(g)) karte.append(h("p", "notiz", "Datei: index.html, die Gepäcksuche"));
    if (istDns(g)) karte.append(eintraegeKarte(g));
    karte.append(h("p", "notiz mac", "MAC: " + g.ports.map((p, i) => mac(g, i)).join(" · ")));
  }
  // Die Luecke (Attrappe ② B): ein Klick bietet die Geraete an; die falsche Wahl bekommt einen Hinweis, kein Kreuz,
  // die richtige setzt das Geraet ein -- die Kabel stecken danach von selbst
  const LUECKE_HINWEIS = {
    rechner: "Ein Rechner hat selbst nur einen Anschluss – hier kommen drei Kabel an.",
    server: "Auch ein Server hat nur einen Anschluss – hier kommen drei Kabel an.",
    switch: "Ein Switch verbindet die Geräte eines Netzes. Hier sind es drei.",
    router: "Ein Router verbindet zwei Netze. Hier ist es eines.",
  };
  // Steckbriefe (dienst W1, 28.10.: „Die Aufgabe 1 ist raten, wie sollen Schüler … darauf kommen?“): je Geraet die
  // Anschluesse und was es tut -- entschieden wird aus drei Kabeln und einem Netz, nicht geraten
  const STECKBRIEF = {
    rechner: "ein Anschluss · fragt an, zeigt Antworten",
    server: "ein Anschluss · bietet Dienste an",
    switch: "viele Anschlüsse · verbindet die Geräte eines Netzes",
    router: "zwei Anschlüsse · verbindet zwei Netze",
  };
  function lueckeKarte(g) {
    karte.append(h("p", "notiz", "Was gehört hierher?"));
    const liste = h("div", "wahl-liste"), hinweis = h("p", "notiz hinweis");
    [["rechner", "Rechner"], ["server", "Server"], ["switch", "Switch"], ["router", "Router"]].forEach(([art, name]) => {
      const b = h("button", "ruhig"); b.dataset.art = art;
      b.append(h("b", "", name), h("small", "", STECKBRIEF[art]));
      b.addEventListener("click", () => { if (art === g.soll) einsetzen(g); else { hinweis.textContent = LUECKE_HINWEIS[art]; liste.querySelectorAll("button").forEach(x => x.classList.toggle("falsch", x === b)); } });
      liste.append(b);
    });
    karte.append(liste, hinweis);
  }
  function einsetzen(g) {
    g.art = g.soll; delete g.soll; karteOffen = null;
    meldung.className = "meldung wahr"; meldung.textContent = "✓ " + LUECKE_HINWEIS[g.art];
    geaendert(); zeichneBefehlszeile(); zeichneDaten();
  }
  function geaendert() {
    // neue Einstellungen: was gemerkt war, gilt nicht mehr. Ein fertiger Lauf bleibt im Datenaustausch und in der
    // Befehlszeile stehen (bis 28.10. fiel er weg -- er wird sonst erst beim naechsten Befehl uebernommen)
    if (lauf && lauf.pos >= lauf.nachrichten.length) abschliessen();
    arp.clear(); verbunden.clear(); abbrechen(); zeichnePlan(); zeichneKarte();
  }

  // ---------- Befehlszeile ----------
  const zeilenVon = id => { if (!konsole.has(id)) konsole.set(id, [{ text: geraet(id).name, art: "grau" }]); return konsole.get(id); };
  function zeichneBefehlszeile() {
    bzReiter.textContent = "";
    // Tisch formular (mitlesen): auch der Router hat einen Reiter -- ohne Befehlszeile, nur sein Datenaustausch
    const mit = netz.geraete.filter(g => g.art === "rechner" || g.art === "server" || (g.art === "router" && tisch.vorlage.mitlesen));
    mit.forEach(g => {
      // ab vier Geraeten nur die Kurzadresse („0.10“), sonst laufen die Reiter in den Datenaustausch (router, 28.10.)
      // am Tisch web auch bei Servern („Webserver 0.12“ schob den Umschalter Befehlszeile | Browser hinaus, 29.10.)
      const b = h("button", "bz-tab" + (g.id === wahl ? " an" : ""), mit.length > 3 && g.art !== "router" ? kurz(g.ports[0].ip) || g.name : g.name); b.title = g.name;
      b.addEventListener("click", () => { wahl = g.id; zeichneBefehlszeile(); zeichneDaten(); zeichnePlan(); });
      bzReiter.append(b);
    });
    bzAus.textContent = "";
    const zeilen = zeilenVon(wahl).slice();
    if (lauf && lauf.quelle === wahl) lauf.nachrichten.slice(0, lauf.pos).forEach(m => (m.danach || []).forEach(z => zeilen.push(z)));
    zeilen.slice(-60).forEach(z => bzAus.append(h("div", z.art || "", z.text)));
    const amRouter = geraet(wahl).art === "router";
    if (amRouter) bzAus.append(h("div", "grau", "Der Router hat hier keine Befehlszeile. Der Datenaustausch zeigt, was durch ihn hindurchgeht."));
    bzZeile.hidden = amRouter;
    bzAus.scrollTop = bzAus.scrollHeight;
    // Tisch web: rechts an den Reitern Befehlszeile | Browser -- den Browser hat nur ein Rechner
    const kannBr = !!tisch.vorlage.web && geraet(wahl).art === "rechner";
    if (!kannBr) ansicht = "befehlszeile";
    if (tisch.vorlage.web) {
      bzReiter.append(h("span", "luecke"), bzModus); bzModus.hidden = !kannBr;
      mBz.classList.toggle("an", ansicht === "befehlszeile"); mBr.classList.toggle("an", ansicht === "browser");
    }
    bz.hidden = ansicht === "browser"; br.hidden = ansicht !== "browser";
    if (ansicht === "browser") zeichneBrowser();
  }
  function befehl(text) {
    text = String(text || "").trim();
    if (!text) return;
    if (lauf) abschliessen();
    const q = geraet(wahl), zeilen = zeilenVon(wahl);
    const v = verlauf.get(wahl) || []; v.push(text); verlauf.set(wahl, v);
    zeilen.push({ text: "/> " + text, art: "ein" });
    const [cmd, arg] = text.split(/\s+/);
    if (cmd === "ping") {
      if (!arg) zeilen.push({ text: "So geht es: ping 192.168.0.11", art: "rot" });
      else if (!gueltig(arg)) zeilen.push({ text: arg + " ist keine gültige IP-Adresse.", art: "rot" });
      else if (!gueltig(q.ports[0].ip)) zeilen.push({ text: "Dieser Rechner hat keine gültige IP-Adresse.", art: "rot" });
      else if (q.ports.some(p => p.ip === arg)) {
        zeilen.push({ text: "PING " + arg });
        for (let i = 1; i <= 4; i++) zeilen.push({ text: "Antwort von " + arg + ": Folge " + i + ", Zeit 0 ms" });
        zeilen.push({ text: "4 gesendet, 4 empfangen" });
        // sich selbst fragen geht nicht ueber das Kabel -- der Datenaustausch sagt das, statt zum ping einzuladen
        lauf = { quelle: wahl, nachrichten: [], pos: 0, selbst: true }; zeichneDaten();
      } else {
        zeilen.push({ text: "PING " + arg });
        lauf = { quelle: wahl, nachrichten: ping(q, arg), pos: 0, vorhersage: vIn.value.trim() };
        meldung.className = "meldung"; meldung.textContent = "▸ eine Nachricht oder ▸▸ alle.";
      }
    } else if ((cmd === "verbinde" || cmd === "sende") && mitDienst() && !tisch.vorlage.web) {
      dienstBefehl(cmd, text.slice(cmd.length).trim(), q, zeilen);
    } else if (cmd === "host" && tisch.vorlage.web) {
      hostBefehl(adresseVon(arg || ""), q, zeilen);
    } else if (cmd === "ipconfig") {
      q.ports.forEach(p => { zeilen.push({ text: "IP-Adresse . . : " + (p.ip || "–") }); zeilen.push({ text: "Netzmaske . . . : " + (p.maske || "–") }); });
      if (tisch.vorlage.felder.includes("gateway")) zeilen.push({ text: "Gateway . . . . : " + (q.gateway || "–") });
      if (tisch.vorlage.felder.includes("dns")) zeilen.push({ text: "DNS-Server . . : " + (q.dns || "–") });
    } else if (cmd === "hilfe" || cmd === "help") {
      zeilen.push({ text: "ping <IP-Adresse>   fragt, ob ein Rechner antwortet" }, { text: "ipconfig            zeigt die eigenen Einstellungen" });
      if (tisch.vorlage.web) zeilen.push({ text: "host <Name>         fragt den DNS-Server nach der IP-Adresse" });
      if (mitDienst() && !tisch.vorlage.web) zeilen.push({ text: "verbinde <IP> <Port> verbindet mit einem Dienst" }, { text: "sende <Text>        schickt Text über die Verbindung" });
    } else zeilen.push({ text: "Unbekannter Befehl. Bekannt: ping, ipconfig, " + (tisch.vorlage.web ? "host, " : mitDienst() ? "verbinde, sende, " : "") + "hilfe", art: "rot" });
    zeichneBefehlszeile(); zeichneKnoepfe();
  }
  // Der Client (dienst, 28.10.): verbinde baut die Verbindung auf -- drei Nachrichten wie am Telefon („Verbindung?“ –
  // „Ja, bereit.“ – „Gut.“, Lehrerwahl: das Wort TCP faellt erst in namen) --, sende schickt Text, der Echo-Dienst
  // schickt ihn zurueck. Auf einem Port ohne Dienst lehnt der Rechner sichtbar ab (anders als in kabel: er ist da).
  const mitDienst = () => netz.geraete.some(g => (g.dienste || []).length);
  const kurzText = t => t.length > 18 ? t.slice(0, 17) + "…" : t;
  function zeilenAnhaengen(liste, neu) {
    if (liste.length) { const m = liste[liste.length - 1]; m.danach = (m.danach || []).concat(neu); } else liste.push({ leer: true, danach: neu });
  }
  function dienstBefehl(cmd, rest, q, zeilen) {
    const von = q.ports[0].ip, liste = [];
    if (cmd === "verbinde") {
      const [ip, p] = rest.split(/\s+/), port = +p;
      if (!ip || !gueltig(ip) || !/^\d+$/.test(p || "") || port < 1 || port > 65535) { zeilen.push({ text: "So geht es: verbinde 192.168.0.12 55555", art: "rot" }); return; }
      verbunden.delete(q.id);
      const da = zustellen(q, von, ip, "Verbindung? (Port " + port + ")", liste, "tcp", "Verbindung?", { transport: { prot: "TCP", von: PORT_CLIENT, an: port } });
      if (!da) { zeilenAnhaengen(liste, [{ text: liste.length ? "Keine Antwort von " + ip + "." : "Ziel nicht erreichbar.", art: "rot" }]); }
      else {
        const d = (da.dienste || []).find(x => x.port === port);
        zustellen(da, ip, von, d ? "Ja, bereit." : "Abgelehnt: kein Dienst auf Port " + port, liste, "tcp", d ? "Ja, bereit." : "Abgelehnt", { transport: { prot: "TCP", von: port, an: PORT_CLIENT } });
        if (d) {
          zustellen(q, von, ip, "Gut.", liste, "tcp", "Gut.", { transport: { prot: "TCP", von: PORT_CLIENT, an: port } });
          verbunden.set(q.id, { ip, port, dienst: d.name });
          zeilenAnhaengen(liste, [{ text: "Verbunden mit " + ip + ", Port " + port + " (" + d.name + ")." }]);
        } else zeilenAnhaengen(liste, [{ text: "Verbindung abgelehnt: Auf Port " + port + " läuft kein Dienst.", art: "rot" }]);
      }
    } else {
      const v = verbunden.get(q.id);
      if (!v) { zeilen.push({ text: "Nicht verbunden. Erst: verbinde <IP-Adresse> <Port>", art: "rot" }); return; }
      if (!rest) { zeilen.push({ text: "So geht es: sende Hallo", art: "rot" }); return; }
      const da = zustellen(q, von, v.ip, "Nachricht: " + rest, liste, "tcp", kurzText(rest), { transport: { prot: "TCP", von: PORT_CLIENT, an: v.port }, anwendung: { prot: "Echo", text: rest } });
      if (da) zustellen(da, v.ip, von, "Echo: " + rest, liste, "tcp", kurzText("Echo: " + rest), { transport: { prot: "TCP", von: v.port, an: PORT_CLIENT }, anwendung: { prot: "Echo", text: rest } });
      zeilenAnhaengen(liste, [da ? { text: "Echo: " + rest } : { text: "Keine Antwort von " + v.ip + ".", art: "rot" }]);
    }
    lauf = { quelle: q.id, nachrichten: liste.filter(m => !m.leer || m.danach), pos: 0, vorhersage: vIn.value.trim() };
    meldung.className = "meldung"; meldung.textContent = "▸ eine Nachricht oder ▸▸ alle.";
  }
  // ---------- Namen und Seiten (namen, 29.10.) ----------
  // DNS: Der Rechner fragt den DNS-Server aus seiner Karte, der schaut in seinen Eintraegen nach. Der Browser holt die
  // Seite danach wie der Client in dienst: Verbindung zu Port 80, GET, die Datei zurueck. Der DNS-Server steht in
  // Netz 1 -- die Frage geht ueber den Router, ein fehlendes Gateway zeigt sich auch hier.
  const PORT_CLIENT = 49152;
  const istDns = g => (g.dienste || []).some(d => d.name === "DNS-Server");
  const istWeb = g => (g.dienste || []).some(d => d.name === "Webserver");
  // klein geschrieben wird nur der Name des Rechners -- Pfad und Formulardaten bleiben, wie sie sind (meldung, 09.11.:
  // vorher kam „Nilay Brandt“ als nilay+brandt an)
  const adresseVon = x => { const t = String(x).trim().replace(/^https?:\/\//i, ""), i = t.indexOf("/"); return i < 0 ? t.toLowerCase() : t.slice(0, i).toLowerCase() + t.slice(i); };
  function laufStarten(q, liste, mehr) {
    lauf = Object.assign({ quelle: q.id, nachrichten: liste.filter(m => !m.leer || m.danach || m.browser), pos: 0, vorhersage: vIn.value.trim() }, mehr || {});
    meldung.className = "meldung"; meldung.textContent = "▸ eine Nachricht oder ▸▸ alle.";
  }
  function aufloesen(q, name, liste) {
    const von = q.ports[0].ip;
    if (!gueltig(q.dns || "")) return { fehler: "Kein DNS-Server eingetragen: " + name + " lässt sich nicht nachschlagen." };
    const vorher = liste.length;
    const da = zustellen(q, von, q.dns, "DNS: Wer ist " + name + "?", liste, "dns", "DNS: Wer ist …?",
      { transport: { prot: "UDP", von: PORT_CLIENT, an: 53 }, anwendung: { prot: "DNS", text: "Wer ist " + name + "?" } });
    if (!da) return { fehler: liste.length > vorher ? "Keine Antwort vom DNS-Server " + q.dns + "." : "DNS-Server " + q.dns + " nicht erreichbar." };
    if (!istDns(da)) return { fehler: "Keine Antwort: Auf " + q.dns + " läuft kein DNS-Server." };
    const e = (da.eintraege || []).filter(x => x.name === name).pop(), text = e ? name + " ist " + e.ip : name + " kenne ich nicht";
    const zurueck = zustellen(da, q.dns, von, "DNS: " + text, liste, "dns", e ? "DNS: " + kurz(e.ip) : "DNS: unbekannt",
      { transport: { prot: "UDP", von: 53, an: PORT_CLIENT }, anwendung: { prot: "DNS", text } });
    if (zurueck !== q) return { fehler: "Keine Antwort vom DNS-Server " + q.dns + "." };
    return e ? { ip: e.ip } : { fehler: "Der DNS-Server kennt " + name + " nicht." };
  }
  function hostBefehl(name, q, zeilen) {
    if (!name) { zeilen.push({ text: "So geht es: host www.gepaeck-suche.de", art: "rot" }); return; }
    if (gueltig(name)) { zeilen.push({ text: name + " ist schon eine IP-Adresse." }); return; }
    const liste = [], r = aufloesen(q, name, liste);
    zeilenAnhaengen(liste, [r.ip ? { text: name + " hat die Adresse " + r.ip } : { text: r.fehler, art: "rot" }]);
    laufStarten(q, liste);
  }
  // Der Browser: erst der Name (falls keine Nummer), dann Verbindung, GET, Antwort. Was er am Ende zeigt, haengt an der
  // letzten Nachricht (wie die Zeilen der Befehlszeile) -- die Seite erscheint, wenn die Antwort angekommen ist.
  function laden(q, eingabe, sendung) {
    // sendung (Tisch formular): {methode, daten} -- ein abgeschicktes Formular; GET traegt die Daten schon in der Adresse
    const roh = adresseVon(eingabe), [wirt, ...pfad] = roh.split("/"), datei = pfad.join("/") || "index.html";
    const post = !!(sendung && sendung.methode === "post"), datName = datei.split("?")[0];
    const adresse = "http://" + roh, von = q.ports[0].ip, liste = [];
    // was der Server zu dieser Datei hat: der Abholschein (Programm melden), eine Seite der Klasse, die index.html
    const formular = !!tisch.vorlage.formular;
    let html = null, gibt = datName === "index.html" && !(formular && seiteUrl("index.html") && seiten.has("index.html"));
    if (formular && datName === "melden") { gibt = true; html = abholschein(post ? "POST" : "GET", post ? sendung.daten : (datei.split("?")[1] || "")); }
    else if (formular && seiten.has(datName)) { gibt = true; html = seiten.get(datName); }
    const ende = (art, text) => {
      const b = { adresse, art, text, datei: datName, html };
      if (liste.length) liste[liste.length - 1].browser = b; else liste.push({ leer: true, browser: b });
    };
    brStand.set(q.id, { adresse, art: "laedt" });
    let ip = wirt;
    if (!gueltig(wirt)) { const r = aufloesen(q, wirt, liste); if (!r.ip) { ende("fehler", r.fehler); laufStarten(q, liste, { browser: true }); return; } ip = r.ip; }
    const tcp = (a, b) => ({ transport: { prot: "TCP", von: a, an: b } });
    const vorher = liste.length;
    const da = zustellen(q, von, ip, "Verbindung? (Port 80)", liste, "tcp", "Verbindung?", tcp(PORT_CLIENT, 80));
    if (!da) ende("fehler", liste.length > vorher ? "Keine Antwort von " + ip + "." : ip + " ist nicht erreichbar.");
    else {
      const web = istWeb(da);
      const zurueck = zustellen(da, ip, von, web ? "Ja, bereit." : "Abgelehnt: kein Dienst auf Port 80", liste, "tcp", web ? "Ja, bereit." : "Abgelehnt", tcp(80, PORT_CLIENT));
      if (zurueck !== q) ende("fehler", "Keine Antwort von " + ip + ".");
      else if (!web) ende("fehler", "Auf " + ip + " läuft kein Webserver (Port 80).");
      else {
        zustellen(q, von, ip, "Gut.", liste, "tcp", "Gut.", tcp(PORT_CLIENT, 80));
        // POST: die erste Zeile ohne Daten, die Daten stehen dahinter -- im Kabel genauso lesbar (meldung, Mehr)
        const get = post ? "POST /" + datName : "GET /" + datei;
        const text = post ? get + "   Daten: " + (sendung.daten || "(keine)") : get;
        zustellen(q, von, ip, text, liste, "http", post ? "POST" : "GET", Object.assign(tcp(PORT_CLIENT, 80), { anwendung: { prot: "HTTP", text } }));
        const antwort = gibt ? "200 OK: " + (datName === "melden" ? "Abholschein" : datName) : "404 Nicht gefunden: " + datName;
        const dazu = datName === "melden" ? "der Abholschein" : "die Datei " + datName;
        zustellen(da, ip, von, antwort, liste, "http", gibt ? "200 OK" : "404", Object.assign(tcp(80, PORT_CLIENT), { anwendung: { prot: "HTTP", text: gibt ? "200 OK, dazu " + dazu : "404 Nicht gefunden" } }));
        ende(gibt ? "seite" : "fehler", gibt ? "" : "Auf " + ip + " gibt es die Datei " + datName + " nicht (404).");
      }
    }
    laufStarten(q, liste, { browser: true });
  }
  function browserLaden(text, frisch, sendung) {
    if (!String(text || "").trim()) return;
    // Tisch formular: Tippt ein Mensch die Adresse, holt die Werkstatt die Seite frisch vom Lernraum (die Klasse hat
    // vielleicht gerade gespeichert); der Film nimmt, was gemerkt ist
    const datei = (adresseVon(text).split("/").slice(1).join("/") || "index.html").split("?")[0];
    if (frisch && tisch.vorlage.formular && seiteUrl(datei)) { seiteHolen(datei).then(() => browserLaden(text, false, sendung)); return; }
    if (lauf) abschliessen();
    laden(geraet(wahl), text, sendung);
    zeichneBefehlszeile(); zeichneDaten(); zeichneKnoepfe();
  }
  // Ein Formular abschicken (Tisch formular): je Feld mit name ein Paar, wie der Browser es schreibt (name=Wert&…,
  // Leerzeichen als +). Ein Feld ohne name reist nicht mit. GET haengt die Daten an die Adresse, POST schickt sie dahinter.
  const KNOPF = ["submit", "button", "reset", "image"];
  const sichtbareFelder = form => [...form.elements].filter(el => !KNOPF.includes((el.type || "").toLowerCase()) && (el.type || "").toLowerCase() !== "hidden" && el.tagName !== "BUTTON" && el.tagName !== "FIELDSET");
  function formularSenden(form) {
    const paare = [];
    for (const el of form.elements) {
      const t = (el.type || "").toLowerCase();
      if (!el.name || el.disabled || KNOPF.includes(t) || el.tagName === "BUTTON" || el.tagName === "FIELDSET") continue;
      if ((t === "checkbox" || t === "radio") && !el.checked) continue;
      paare.push([el.name, el.value]);
    }
    const daten = new URLSearchParams(paare).toString(), methode = (form.getAttribute("method") || "get").trim().toLowerCase() === "post" ? "post" : "get";
    const action = (form.getAttribute("action") || "").trim().replace(/^\//, "");
    const st = browserJetzt(wahl), wirt = st ? adresseVon(st.adresse).split("/")[0] : "www.gepaeck-suche.de";
    const ziel = action || (st && st.datei) || "index.html";
    browserLaden(wirt + "/" + ziel + (methode === "get" ? "?" + daten : ""), false, { methode, daten });
  }
  // dasselbe aus dem Text der Seite (Film: + absenden: Wert | Wert …) -- die Werte gehen der Reihe nach in die
  // sichtbaren Felder, so wie die Klasse sie von oben nach unten ausfuellt
  function formularAusText(text, werte) {
    const d = new DOMParser().parseFromString(text, "text/html"), form = d.forms[0];
    if (!form) return;
    sichtbareFelder(form).forEach((el, i) => { if (werte[i] != null) el.value = werte[i]; });
    formularSenden(form);
  }
  // Der Abholschein, wie der Server ihn schreibt -- wortgleich mit abholschein_seite() in kursserver/server.py
  function abholschein(methode, daten) {
    const esc = t => String(t).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;");
    const paare = [...new URLSearchParams(daten)];
    const zeile = methode + " /melden" + (methode === "GET" ? "?" + daten : "");
    let x = 2166136261; for (let i = 0; i < daten.length; i++) { x ^= daten.charCodeAt(i); x = Math.imul(x, 16777619) >>> 0; }
    const nr = x % 9000 + 1000;
    const inhalt = paare.length
      ? "<p>Ihre Meldung ist angekommen. Beim Server steht:</p><table>" + paare.map(([n, w]) => "<tr><th>" + esc(n) + "</th><td>" + (w ? esc(w) : "<i>leer</i>") + "</td></tr>").join("") + "</table>"
        + '<p class="schein">Abholschein Nr. ' + nr + "</p><p>Wir suchen weiter, auch dort, wo Koffer eigentlich nicht hindürfen.</p>"
      : "<p>Angekommen ist eine Meldung <strong>ohne Inhalt</strong>.</p><p>Wessen Koffer sollen wir suchen? Wir haben nichts als ein Fragezeichen.</p>"
        + '<p class="schein">Abholschein Nr. ????</p>';
    const rumpf = '<p class="anfrage">So kam die Anfrage an: <code>' + esc(zeile) + "</code>" + (methode === "POST" ? "<br>Daten dahinter: <code>" + esc(daten || "(keine)") + "</code>" : "") + "</p>";
    return '<!DOCTYPE html><html><head><meta charset="utf-8"><title>Abholschein – Gepäcksuche</title>'
      + '<link rel="stylesheet" href="flughafen.css"><style>'
      + "body{font-family:system-ui,'Segoe UI',sans-serif}table{border-collapse:collapse;margin:.4em 0 .8em}"
      + "th,td{text-align:left;padding:.25em .9em .25em 0;border-bottom:1px solid #e6e1d8}th{font-family:ui-monospace,Menlo,monospace;font-weight:600}"
      + ".anfrage{margin-top:1.4em;font-size:.85em;color:#6f6a63}.anfrage code{word-break:break-all;color:#1c1b1a}"
      + '</style></head><body><h1>Abholschein</h1><p class="unter">Gepäcksuche · Fundbüro</p>' + inhalt + rumpf + "</body></html>";
  }
  function browserJetzt(id) {
    if (lauf && lauf.browser && lauf.quelle === id) {
      const da = lauf.nachrichten.slice(0, lauf.pos).filter(m => m.browser);
      if (da.length) return da[da.length - 1].browser;
    }
    return brStand.get(id) || null;
  }
  function zeichneBrowser() {
    const st = browserJetzt(wahl);
    if (document.activeElement !== brIn) brIn.value = st ? st.adresse.replace(/^http:\/\//, "") : "";
    // dieselbe Seite noch einmal: der Rahmen bleibt stehen -- sonst ginge verloren, was im Formular getippt ist, sobald
    // irgendetwas neu zeichnet (ein Reiter, die naechste Nachricht; meldung, 09.11.)
    if (st && st === brGezeigt.st && quelltextAn === brGezeigt.q && brSeite.firstChild) return;
    brGezeigt = { st, q: quelltextAn };
    brSeite.textContent = ""; brSeite.className = "br-seite";
    if (!st) { brSeite.append(h("p", "br-leer", "Eine Adresse eingeben: eine IP-Adresse wie 192.168.0.12 oder einen Namen.")); return; }
    if (st.art === "laedt") { brSeite.classList.add("laedt"); brSeite.append(h("p", "br-leer", "Lädt " + st.adresse + " …")); return; }
    if (st.art === "fehler") { brSeite.classList.add("fehler"); brSeite.append(h("h4", "", "Seite nicht erreichbar"), h("p", "", st.text)); return; }
    if (quelltextAn) { brSeite.classList.add("quelltext"); brSeite.append(quelltextBild(st.html != null ? st.html : GEPAECK_INDEX)); return; }
    brSeite.classList.add("echt");
    brSeite.append(st.html != null ? klassenSeite(st.html) : gepaeckSeite());
  }
  // Eine Seite der Klasse oder der Abholschein (Tisch formular): im Rahmen ohne Skripte (sandbox), CSS und Bilder vom
  // Lernraum (base) -- ausserhalb des Lernraums das CSS des Flughafens eingebettet. Links und Knoepfe fuehren nicht aus
  // dem Rahmen hinaus, sie gehen durch das Netz der Werkstatt: ein Link laedt seine Seite, ein Knopf schickt ab.
  function klassenSeite(text) {
    const f = h("iframe", "gs-rahmen"); f.title = "Seite"; f.setAttribute("sandbox", "allow-same-origin");
    // CSS und Bilder als volle Adressen: Ein <base> uebergeht der Rahmen (about:srcdoc, sandbox) -- das CSS kam dann von
    // /flughafen.css (Browsertest 09.11.). Umgeschrieben werden nur link und img; Links (a) bleiben, wie sie sind, die
    // faengt der Klick ab.
    const basis = seitenBasis() ? new URL(seitenBasis(), location.href).href : "";
    f.srcdoc = basis ? text.replace(/<(link|img)\b[^>]*>/gi, tag => tag.replace(/\b(href|src)="(?![a-z][\w+.-]*:|\/|#)([^"]*)"/i, (m, a, v) => a + '="' + basis + v + '"'))
      : text.replace(/<link rel="stylesheet" href="flughafen.css">/, "<style>" + FLUGHAFEN_CSS + "</style>");
    f.addEventListener("load", () => {
      let d = null; try { d = f.contentDocument; } catch (e) { return; }
      if (!d) return;
      d.addEventListener("click", e => {
        const ziel = e.target && e.target.closest ? e.target : e.target.parentElement;
        const a = ziel && ziel.closest("a[href]");
        if (a) { e.preventDefault(); const href = a.getAttribute("href") || ""; if (/^[\w.-]+\.html$/.test(href)) { const st = browserJetzt(wahl); browserLaden((st ? adresseVon(st.adresse).split("/")[0] : "www.gepaeck-suche.de") + "/" + href, true); } return; }
        const k = ziel && ziel.closest("button, input[type=submit]");
        if (k && k.form && (k.tagName !== "BUTTON" || (k.getAttribute("type") || "submit").toLowerCase() === "submit")) { e.preventDefault(); formularSenden(k.form); }
      });
      d.addEventListener("keydown", e => { const t = e.target; if (e.key === "Enter" && t && t.tagName === "INPUT" && t.form) { e.preventDefault(); formularSenden(t.form); } });
    });
    return f;
  }
  // Die Seite auf dem Webserver 0.12 als ECHTE Datei (Attrappe ⑥ A, Lehrerwahl 29.10.2026; bis dahin baute die Werkstatt
  // sie aus eigenem Code nach): index.html, das Aussehen aus flughafen.css (fertig vom Flughafen), das Bild aus
  // bilder/koffer.svg. Ab webseite/station baut die Klasse genau diese Seite weiter -- ihre Startdatei muss diesem Text
  // gleichen (LIESMICH „HTML-Arbeitsplatz“). Gezeigt in einem iframe (srcdoc): CSS und Bild stehen dort eingebettet.
  function gepaeckSeite() {
    const f = h("iframe", "gs-rahmen"); f.title = "www.gepaeck-suche.de";
    f.srcdoc = GEPAECK_INDEX.replace('<link rel="stylesheet" href="flughafen.css">', "<style>" + FLUGHAFEN_CSS + "</style>")
      .replace('src="bilder/koffer.svg"', 'src="data:image/svg+xml;utf8,' + encodeURIComponent(KOFFER_SVG.replace("<svg ", '<svg xmlns="' + SVGNS + '" ')) + '"');
    return f;
  }
  // Der Quelltext mit Farben wie im Editor -- ohne den Editor (die Werkstatt laeuft auch ausserhalb des Lernraums)
  function quelltextBild(text) {
    const pre = h("pre", "br-text");
    for (const zeile of text.split("\n")) {
      const z = h("span", "br-zeile");
      for (const teil of zeile.split(/(<[^>]*>)/)) {
        if (!teil) continue;
        if (teil.startsWith("<")) {
          const m = teil.match(/^(<\/?)([!\w]+)(.*?)(\/?>)$/s);
          if (!m) { z.append(teil); continue; }
          const tag = h("span", m[2] === "!DOCTYPE" ? "q-dt" : "q-tag");
          tag.append(m[1], h("b", "", m[2]));
          for (const at of m[3].split(/(\s+[\w-]+="[^"]*")/)) {
            const a = at.match(/^(\s+)([\w-]+)="([^"]*)"$/);
            if (a) tag.append(a[1], h("span", "q-attr", a[2]), "=", h("span", "q-wert", '"' + a[3] + '"')); else if (at) tag.append(at);
          }
          tag.append(m[4]); z.append(tag);
        } else z.append(teil);
      }
      pre.append(z, "\n");
    }
    return pre;
  }
  // Die Lupe (Attrappe ① C, Lehrerwahl 27.10.: „erst am Tisch web“): eine Nachricht als Huellen ineinander -- aussen die
  // MAC-Adressen dieses Abschnitts, darin die IP-Adressen, darin die Ports, innen die Anwendung
  function lupeOeffnen(m) { if (!m || m.leer) return; lupe = m; karteOffen = "lupe"; zeichnePlan(); zeichneKarte(); }
  function lupeBild(m) {
    const huelle = (schicht, zeile) => { const d = h("div", "huelle s-" + schicht.toLowerCase()); d.append(h("div", "huelle-kopf", schicht), h("div", "huelle-zeile", zeile)); return d; };
    const aussen = huelle("Netzzugang", "MAC von " + m.macVon + " an " + (m.macAn === ALLE_MAC ? "alle" : m.macAn));
    const innen = (el, text) => { el.append(h("div", "huelle-inhalt", text)); return aussen; };
    if (m.art === "arp") return innen(aussen, m.bem);
    const inet = huelle("Internet", "IP von " + m.von + " an " + m.an); aussen.append(inet);
    if (!m.transport) return innen(inet, m.bem);
    const tr = huelle("Transport", m.transport.prot + " · von Port " + m.transport.von + " an Port " + m.transport.an); inet.append(tr);
    if (!m.anwendung) return innen(tr, m.bem);
    const an = huelle("Anwendung", m.anwendung.prot); tr.append(an);
    return innen(an, m.anwendung.text);
  }
  // Die Eintraege des DNS-Servers: Name und IP-Adresse je Zeile, unten eine leere Zeile fuer einen neuen. Geaendert wird
  // ohne die Karte neu zu zeichnen -- sonst ginge beim Tab vom Namen zur Adresse der Fokus verloren.
  function eintraegeKarte(g) {
    const box = h("div", "eintraege");
    box.append(h("p", "notiz dienst", "Einträge · Name → IP-Adresse"));
    const zeile = e => {
      const z = h("div", "eintrag"), n = h("input"), i = h("input");
      n.type = i.type = "text"; n.spellcheck = i.spellcheck = false; n.placeholder = "www.…"; i.placeholder = "192.168.…";
      n.setAttribute("aria-label", "Name"); i.setAttribute("aria-label", "IP-Adresse");
      n.value = e ? e.name : ""; i.value = e ? e.ip : "";
      const merken = () => {
        const name = adresseVon(n.value), ip = i.value.trim();
        i.classList.toggle("falsch", !!ip && !gueltig(ip));
        if (!e && name && ip) { e = { name, ip }; g.eintraege.push(e); box.append(zeile(null)); }
        else if (e && !name && !ip) { g.eintraege.splice(g.eintraege.indexOf(e), 1); e = null; z.remove(); }
        else if (e) { e.name = name; e.ip = ip; }
      };
      n.addEventListener("change", merken); i.addEventListener("change", merken);
      z.append(n, h("span", "pfeil-text", "→"), i);
      return z;
    };
    (g.eintraege = g.eintraege || []).forEach(e => box.append(zeile(e)));
    box.append(zeile(null));
    return box;
  }
  // Pfeil hoch/runter blaettert wie in einer Shell durch alle frueheren Befehle des Geraets;
  // unter dem neuesten steht wieder, was gerade getippt war
  let blaettern = null;
  bzIn.addEventListener("keydown", e => {
    if (e.key === "Enter") { const t = bzIn.value; bzIn.value = ""; blaettern = null; befehl(t); return; }
    if (e.key !== "ArrowUp" && e.key !== "ArrowDown") { if (e.key.length === 1 || e.key === "Backspace") blaettern = null; return; }
    const v = verlauf.get(wahl) || [];
    if (!v.length) return;
    e.preventDefault();
    if (!blaettern || blaettern.geraet !== wahl) blaettern = { geraet: wahl, pos: v.length, entwurf: bzIn.value };
    blaettern.pos = Math.max(0, Math.min(v.length, blaettern.pos + (e.key === "ArrowUp" ? -1 : 1)));
    bzIn.value = blaettern.pos < v.length ? v[blaettern.pos] : blaettern.entwurf;
  });
  bz.addEventListener("click", () => bzIn.focus());

  // ---------- Datenaustausch ----------
  // Eng (Vortrag mit Folie daneben, meldung W3, 10.11.) steht die Adresse kurz wie im Plan -- „1.10“ statt
  // „192.168.1.10“ --, damit die Bemerkung (die Anfrage) Platz hat; der Text der Zelle bleibt die ganze Adresse
  function ipZelle(text) {
    const m = /^(\d+\.\d+\.)(\d+\.\d+)$/.exec(String(text));
    const td = h("td", m ? "ip" : "");
    if (m) td.append(h("span", "ip-vorn", m[1]), m[2]); else td.textContent = text;
    return td;
  }
  function zeichneDaten() {
    const g = geraet(wahl);
    daTitel.textContent = "Datenaustausch – " + g.name;
    daTab.textContent = "";
    const web = !!tisch.vorlage.web;
    const kopfz = h("tr"); ["Nr", "Quelle", "Ziel"].concat(web ? ["Schicht"] : [], ["Bemerkung"]).forEach(t => kopfz.append(h("th", "", t))); daTab.append(kopfz);
    const alt = gesehen.get(wahl) || [];
    const neu = lauf ? lauf.nachrichten.slice(0, lauf.pos).filter(m => !m.leer && m.sieht.includes(wahl)) : [];
    const zeilen = datenZeilen(wahl);
    const jetzt = lauf && lauf.pos ? lauf.nachrichten[lauf.pos - 1] : null;
    zeilen.forEach((m, i) => {
      const z = h("tr", m.art + (m === jetzt ? " jetzt" : "") + (web && m === lupe ? " lupe" : ""));
      z.append(h("td", "", String(i + 1)), ipZelle(m.von), ipZelle(m.an));
      if (web) z.append(h("td", "schicht", m.schicht || ""));
      z.append(h("td", "bem", m.bem));
      // am Tisch web legt ein Klick auf die Zeile die Nachricht unter die Lupe
      if (web) { z.title = "Unter die Lupe"; z.addEventListener("click", () => lupeOeffnen(m)); }
      daTab.append(z);
    });
    // ein ping, bei dem nichts losging (Ziel nicht im eigenen Netz, kein Gateway), sagt das -- nicht „Noch nichts“
    // ebenso ein ping an sich selbst (geht nicht ueber das Kabel) -- auch unter alten Zeilen, sonst saehe es aus, als gehoerten sie dazu
    const stumm = lauf && lauf.pos && !lauf.nachrichten.some(m => !m.leer);
    const neuWort = alt.length ? "Keine neue Nachricht" : "Keine Nachricht";
    const text = lauf && lauf.selbst ? neuWort + " über das Kabel: Der Rechner hat sich selbst geantwortet."
      : stumm ? neuWort + " ist losgegangen."
      : !alt.length && !neu.length ? (g.art === "router" ? "Noch nichts: Durch den Router ist noch keine Nachricht gegangen."
        : tisch.vorlage.formular ? "Noch nichts. Im Browser die Adresse eingeben, Los -- dann gehen die Nachrichten los."
        : "Noch nichts. Tippe in der Befehlszeile zum Beispiel ping " + (netz.geraete.find(x => x.id !== wahl && x.ports.length) || g).ports[0].ip) : "";
    if (text) { const z = h("tr", "leer"); const td = h("td", "", text); td.colSpan = web ? 5 : 4; z.append(td); daTab.append(z); }
    const zeile = daTab.querySelector("tr.jetzt"); if (zeile && zeile.scrollIntoView && daBox.scrollHeight > daBox.clientHeight) daBox.scrollTop = zeile.offsetTop - daBox.clientHeight / 2;
  }

  // am Router (mitlesen) steht eine weitergeleitete Nachricht zweimal: sie kommt an und geht weiter -- einmal genuegt.
  // Dieselbe Liste fuer Tabelle und Lupe (+ lupe: 7 meint die siebte Zeile, die man sieht)
  const datenZeilen = id => {
    const l = (gesehen.get(id) || []).concat(lauf ? lauf.nachrichten.slice(0, lauf.pos).filter(m => !m.leer && m.sieht.includes(id)) : []);
    return geraet(id).art !== "router" ? l : l.filter((m, i) => !(i && l[i - 1].von === m.von && l[i - 1].an === m.an && l[i - 1].bem === m.bem && l[i - 1].art === m.art));
  };

  // ---------- Ablauf ----------
  function zeichneKnoepfe() {
    const offen = lauf && lauf.pos < lauf.nachrichten.length;
    kEin.disabled = !offen || belegt; kAlle.disabled = !offen || belegt; kZur.disabled = !lauf || !lauf.pos || belegt;
  }
  function eine(dauer, weiter) {
    if (!lauf || lauf.pos >= lauf.nachrichten.length) { zeichneKnoepfe(); return; }
    const m = lauf.nachrichten[lauf.pos];
    belegt = true; zeichneKnoepfe();
    lauf.pos++;
    zeichneDaten();
    fahre(m, dauer, () => {
      belegt = false; zeichneBefehlszeile(); zeichneKnoepfe();
      if (lauf.pos >= lauf.nachrichten.length) pruefeVorhersage();
      if (weiter) weiter();
    });
  }
  function alle() { const naechste = () => { if (lauf && lauf.pos < lauf.nachrichten.length) setTimeout(() => eine(520 * faktor(), naechste), RUHIG ? 0 : 90 * faktor()); }; eine(520 * faktor(), naechste); }
  function zurueck() {
    if (!lauf || !lauf.pos || belegt) return;
    anim++; lauf.pos--;
    lagen.umschlag.textContent = "";
    const m = lauf.pos ? lauf.nachrichten[lauf.pos - 1] : null;
    if (m) { fahre(m, 0, () => {}); } else leuchte(null);
    meldung.className = "meldung"; meldung.textContent = "";
    zeichneDaten(); zeichneBefehlszeile(); zeichneKnoepfe();
  }
  function pruefeVorhersage() {
    const n = lauf.nachrichten.filter(m => !m.leer).length, v = (vIn.value || lauf.vorhersage || "").trim();
    meldung.className = "meldung"; meldung.textContent = "";
    if (v === "") return;
    const ok = parseInt(v, 10) === n;
    vIn.value = ""; lauf.vorhersage = "";
    meldung.className = "meldung " + (ok ? "wahr" : "falsch");
    meldung.textContent = ok ? "✓ Stimmt: " + n + " Nachrichten." : "Nicht ganz: Es waren " + n + " Nachrichten. Welche zeigt der Datenaustausch, die du nicht mitgezählt hast?";
  }
  // ein angefangener Lauf geht in den Datenaustausch ein, wenn ein neuer Befehl kommt
  function abschliessen() {
    if (!lauf) return;
    anim++; belegt = false;
    lauf.nachrichten.forEach(m => {
      if (m.browser) brStand.set(lauf.quelle, m.browser);
      if (m.leer) return;
      m.sieht.forEach(id => { const l = gesehen.get(id) || []; l.push(m); gesehen.set(id, l); });
      const k = zeilenVon(lauf.quelle); (m.danach || []).forEach(z => k.push(z));
    });
    lauf.nachrichten.filter(m => m.leer).forEach(m => (m.danach || []).forEach(z => zeilenVon(lauf.quelle).push(z)));
    lauf = null; lagen.umschlag.textContent = ""; leuchte(null);
  }
  function abbrechen() { if (lauf && lauf.browser && (brStand.get(lauf.quelle) || {}).art === "laedt") brStand.delete(lauf.quelle); anim++; belegt = false; lauf = null; if (lagen) { lagen.umschlag.textContent = ""; leuchte(null); } zeichneDaten(); zeichneBefehlszeile(); zeichneKnoepfe(); }
  function neu() { arp.clear(); verbunden.clear(); gesehen.clear(); konsole.clear(); brStand.clear(); lupe = null; if (karteOffen === "lupe") { karteOffen = null; zeichnePlan(); zeichneKarte(); } vIn.value = ""; meldung.textContent = ""; meldung.className = "meldung"; abbrechen(); }

  function start() {
    tische.forEach(t => t.knopf.classList.toggle("an", t === tisch));
    wurzel.dataset.tisch = tisch.kennung;
    netz = JSON.parse(JSON.stringify(tisch.vorlage));
    wahl = (tisch.vorlage.start && geraet(tisch.vorlage.start) ? geraet(tisch.vorlage.start) : netz.geraete.find(g => g.art === "rechner")).id; karteOffen = null;
    vorh.textContent = ""; vorh.append(h("span", "frage", "Vorhersage: " + tisch.vorlage.frage + " "), vIn); vIn.value = "";
    // Tisch formular: gezählt wird hier nicht -- die Frage ist, wer mitliest (meldung, 09.11.)
    if (tisch.vorlage.formular) vorh.style.display = "none"; else if (String(opt.vorhersage || "") !== "aus") vorh.style.display = "";
    arp.clear(); verbunden.clear(); gesehen.clear(); konsole.clear(); verlauf.clear(); brStand.clear(); lauf = null; lupe = null; ansicht = "befehlszeile";
    quelltextAn = false; brQuelle.setAttribute("aria-pressed", "false"); brQuelle.classList.remove("an");
    // Tisch formular: gleich der Browser, die Adresse der Meldung als Vorschlag (die Klasse tippt sie nicht aus dem Kopf)
    if (tisch.vorlage.formular) ansicht = "browser";
    brIn.placeholder = tisch.vorlage.formular ? "www.gepaeck-suche.de/" + ALS : "www.gepaeck-suche.de";
    meldung.textContent = ""; meldung.className = "meldung";
    zeichnePlan(); zeichneKarte(); zeichneBefehlszeile(); zeichneDaten(); zeichneKnoepfe();
  }
  // ---------- Film im Vortrag (28.10., kabel: „wie beim Live-Coding schrittweise durchklicken“) ----------
  // Ein Schritt ist {aktion, befehl?, geraet?, wert?} (bauen.py, werkstatt_film_lesen). filmSpielen zeigt ihn animiert,
  // filmHerstellen baut den Stand nach einer Liste von Schritten ohne Animation von vorn auf -- die Werkstatt rechnet
  // jedes Mal gleich, deshalb geht der Film auch rueckwaerts.
  let filmNr = 0, filmBelegt = false;
  const geraetZu = x => netz.geraete.find(g => g.ports.some(p => p.ip === x) || g.name === x) || null;
  function filmSchritt(x, animiert) {
    const g = x.geraet ? geraetZu(x.geraet) : null, nr = ++filmNr;
    filmBelegt = false;   // ein abgebrochener Schritt davor meldet sich nicht mehr fertig
    const fertig = () => { if (nr === filmNr) filmBelegt = false; };
    const tippen = (feld, wert, dann) => {
      if (!animiert || RUHIG || !feld) { dann(); return; }
      filmBelegt = true; feld.value = ""; let n = 0;
      const zug = () => {
        if (nr !== filmNr) return;
        feld.value = wert.slice(0, ++n);
        // gibt dann() true zurueck, tippt es selbst weiter (eintrag: erst der Name, dann die Adresse)
        if (n < wert.length) setTimeout(zug, 45); else setTimeout(() => { if (nr !== filmNr) return; if (!dann()) fertig(); }, 300);
      };
      zug();
    };
    if (x.aktion === "tippe") {
      // eine offene Karte schliesst sich: sonst wird der Plan klein und die Antwort rutscht aus dem Bild (kabel ⑤)
      if (karteOffen) { karteOffen = null; zeichnePlan(); zeichneKarte(); }
      if (ansicht !== "befehlszeile") { ansicht = "befehlszeile"; zeichneBefehlszeile(); }
      if (!animiert || RUHIG) { befehl(x.befehl); return; }
      filmBelegt = true; bzIn.value = ""; let i = 0;
      const zug = () => {
        if (nr !== filmNr) return;
        bzIn.value = x.befehl.slice(0, ++i);
        if (i < x.befehl.length) setTimeout(zug, 45);
        else setTimeout(() => { if (nr !== filmNr) return; bzIn.value = ""; befehl(x.befehl); fertig(); }, 300);
      };
      zug();
    } else if (x.aktion === "eine") {
      if (animiert) { filmBelegt = true; eine(900 * faktor(), fertig); if (!belegt) fertig(); } else eine(0);
    } else if (x.aktion === "alle") {
      if (!animiert) { while (lauf && lauf.pos < lauf.nachrichten.length) eine(0); return; }
      filmBelegt = true;
      const naechste = () => {
        if (nr !== filmNr) return;
        if (lauf && lauf.pos < lauf.nachrichten.length) setTimeout(() => { if (nr === filmNr) eine(520 * faktor(), naechste); }, RUHIG ? 0 : 90 * faktor());
        else fertig();
      };
      naechste();
    } else if (x.aktion === "browser") {
      // namen (29.10.): der Browser des gewaehlten Rechners, die Adresse sichtbar getippt, dann geladen
      if (karteOffen) { karteOffen = null; zeichnePlan(); zeichneKarte(); }
      ansicht = "browser"; zeichneBefehlszeile();
      tippen(brIn, x.wert, () => { brIn.blur(); browserLaden(x.wert); });
    } else if (x.aktion === "absenden") {
      // meldung (09.11.): die Werte der Reihe nach in die Felder der Seite im Browser, dann ab -- animiert erst sichtbar
      // in den Rahmen, ohne Animation gleich aus dem Text der Seite
      if (karteOffen) { karteOffen = null; zeichnePlan(); zeichneKarte(); }
      ansicht = "browser"; zeichneBefehlszeile();
      const st = browserJetzt(wahl), werte = String(x.befehl || "").split("|").map(v => v.trim());
      if (!st || st.html == null) return;
      const text = st.html, ab = () => formularAusText(text, werte);
      const f = brSeite.querySelector("iframe"); let d = null; try { d = f && f.contentDocument; } catch (e) { d = null; }
      const felder = d && d.forms && d.forms[0] ? sichtbareFelder(d.forms[0]) : [];
      if (!animiert || RUHIG || !felder.length) { ab(); return; }
      filmBelegt = true;
      felder.forEach((el, i) => { if (werte[i] != null) el.value = werte[i]; });
      setTimeout(() => { if (nr !== filmNr) return; ab(); fertig(); }, 1100);
    } else if (x.aktion === "quelltext") {
      // station (29.10.): was der Server geschickt hat -- der Knopf Quelltext im Browser
      ansicht = "browser"; zeichneBefehlszeile(); quelltextSetzen(true);
    } else if (x.aktion === "eintrag") {
      // ein Eintrag im DNS-Server: Name und IP-Adresse in die leere Zeile seiner Karte
      const d = netz.geraete.find(istDns); if (!d) return;
      karteOffen = d.id; zeichnePlan(); zeichneKarte();
      const felder = [...karte.querySelectorAll(".eintrag")].pop(), [fn, fi] = felder ? felder.querySelectorAll("input") : [];
      const setzen = () => { const alt = d.eintraege.find(e => e.name === adresseVon(x.name)); if (alt) alt.ip = x.wert; else d.eintraege.push({ name: adresseVon(x.name), ip: x.wert }); zeichneKarte(); };
      tippen(fn, x.name, () => { if (!animiert || RUHIG || !fi) { setzen(); return false; } tippen(fi, x.wert, setzen); return true; });
    } else if (x.aktion === "lupe") {
      if (karteOffen && karteOffen !== "lupe") { karteOffen = null; zeichneKarte(); }
      lupeOeffnen(datenZeilen(wahl)[(+x.zeile || 0) - 1]);
    } else if ((x.aktion === "karte" || x.aktion === "ip" || x.aktion === "gateway" || x.aktion === "dns") && g) {
      karteOffen = g.id; zeichnePlan(); zeichneKarte();
      if (x.aktion !== "karte") {
        // ip: die (erste) IP-Adresse; gateway (router, 28.10.): das Gateway-Feld -- beide sichtbar in die Karte getippt
        const setzen = () => { if (x.aktion === "ip") g.ports[0].ip = x.wert; else if (x.aktion === "dns") g.dns = x.wert; else g.gateway = x.wert; geaendert(); };
        const muster = x.aktion === "ip" ? /^IP-Adresse/ : x.aktion === "dns" ? /^DNS-Server/ : /^Gateway/;
        const feld = [...karte.querySelectorAll(".ezeile")].find(z => muster.test(z.firstChild.textContent));
        const i = feld && feld.querySelector("input");
        if (!animiert || RUHIG || !i) { setzen(); return; }
        filmBelegt = true; i.value = ""; i.focus(); let n = 0;
        const zug = () => {
          if (nr !== filmNr) return;
          i.value = x.wert.slice(0, ++n);
          if (n < x.wert.length) setTimeout(zug, 45); else setTimeout(() => { if (nr !== filmNr) return; i.blur(); setzen(); fertig(); }, 300);
        };
        zug();
      }
    } else if (x.aktion === "einsetzen") {
      const l = netz.geraete.find(y => y.art === "fehlt");
      if (!l) return;
      if (!animiert || RUHIG || l.soll !== x.wahl) { if (l.soll === x.wahl) einsetzen(l); return; }
      filmBelegt = true; karteOffen = l.id; zeichnePlan(); zeichneKarte();
      const b = karte.querySelector('button[data-art="' + x.wahl + '"]'); if (b) b.classList.add("gleich");
      setTimeout(() => { if (nr !== filmNr) return; einsetzen(l); fertig(); }, 900);
    } else if (x.aktion === "rechner" && g) {
      wahl = g.id; zeichneBefehlszeile(); zeichneDaten(); zeichnePlan();
    } else if (x.aktion === "neu") neu();
  }
  let zuletzt = null;   // die letzte Herstellung -- kommt die Seite der Klasse erst danach an, wird neu hergestellt
  function filmHerstellen(liste) {
    zuletzt = liste;
    filmNr++; filmBelegt = false; anim++; belegt = false;
    start();
    liste.forEach(x => filmSchritt(x, false));
    filmNr++; filmBelegt = false;
  }

  mBz.addEventListener("click", () => { ansicht = "befehlszeile"; zeichneBefehlszeile(); });
  mBr.addEventListener("click", () => { ansicht = "browser"; zeichneBefehlszeile(); brIn.focus(); });
  function quelltextSetzen(an) { quelltextAn = an; brQuelle.setAttribute("aria-pressed", String(an)); brQuelle.classList.toggle("an", an); zeichneBrowser(); }
  brQuelle.addEventListener("click", () => quelltextSetzen(!quelltextAn));
  brLeiste.addEventListener("submit", e => { e.preventDefault(); brIn.blur(); browserLaden(brIn.value, true); });
  kEin.addEventListener("click", () => eine(900 * faktor()));
  kAlle.addEventListener("click", alle);
  kZur.addEventListener("click", zurueck);
  kNeu.addEventListener("click", neu);
  tisch = tische[0];
  start();
  if (opt.datei && opt.basis) seiteHolen(ALS).then(() => { if (zuletzt) filmHerstellen(zuletzt); else if (ansicht === "browser") zeichneBrowser(); });
  return {
    befehl, eine: () => eine(0), alle: () => { while (lauf && lauf.pos < lauf.nachrichten.length) eine(0); }, zurueck, neu,
    waehle: id => { wahl = id; zeichneBefehlszeile(); zeichneDaten(); zeichnePlan(); },
    stand: () => ({ tisch: tisch.kennung, pos: lauf ? lauf.pos : 0, anzahl: lauf ? lauf.nachrichten.filter(m => !m.leer).length : 0,
      zeilen: [...daTab.querySelectorAll("tr")].slice(1).map(z => [...z.children].map(td => td.textContent).join(" | ")),
      konsole: [...bzAus.children].map(z => z.textContent), meldung: meldung.textContent,
      ansicht, browser: (() => { const b = browserJetzt(wahl); return b ? b.art + ": " + (b.art === "seite" ? (quelltextAn ? "Quelltext " + brSeite.textContent : b.html != null ? b.datei + (b.datei === "melden" ? " " + b.html.replace(/<style>[\s\S]*?<\/style>/, "").replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim() : "") : "Gepäcksuche (index.html)") : b.text || b.adresse) : ""; })(),
      lupe: karteOffen === "lupe" ? [...karte.querySelectorAll(".huelle-kopf, .huelle-zeile, .huelle-inhalt")].map(x => x.textContent) : null }),
    tische: () => tische.map(t => t.kennung),
    film: { spielen: x => filmSchritt(x, true), herstellen: filmHerstellen, laeuft: () => filmBelegt || belegt },
  };
};
// der Satz über dem Reiter Werkstatt je nach Tisch (uebung.js, werkstattSeite): am Tisch formular (meldung) geht die
// eigene Seite durchs Netz -- die allgemeine Einleitung („ping tippen“) passte dort nicht
window.Werkstaetten.netz.einleitungFuer = opt => String((opt || {}).tische || "").split("|").includes("formular")
  ? "Eure eigene meldung.html im Netz der Werkstatt: Rechner 1.10 öffnet sie im Browser (Adresse, Los, dann ▸▸ alle). Füllt das Formular aus, schickt es ab und spielt die Nachrichten mit ▸▸ alle ab. Dann klickt die Reiter der Geräte an: Wer hat eure Meldung gesehen? Ein Klick auf eine Zeile legt sie unter die Lupe."
  : "";
window.Werkstaetten.netz.einleitung = "Die Werkstatt Netz: Erst vorhersagen, dann in der Befehlszeile ping tippen und die Nachrichten einzeln über das Kabel schicken. Der Datenaustausch zeigt jede Nachricht, die der Rechner gesehen hat. Ein Klick auf ein Gerät zeigt seine Einstellungen.";
