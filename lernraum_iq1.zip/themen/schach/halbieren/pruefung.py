"""Selbstcheck „Binäre Suche“ -- prueft das Programm im Ordner rangliste/ (es laeuft portal.py).

Die Klasse schreibt in rangliste.py finde_position_binaer(wertung) (Aufgabe 2 ★) und get_fragen() (Aufgabe 2 ★★),
dazu in portal.py die Zeile fuer die Shell. Der Check prueft die Klasse ueber OBJEKTE, die er selbst baut (LC8):
eigene, sortierte Ranglisten mit eigenen Mitgliedern -- nie die zwanzig aus mitglieder.py --, mit den Raendern (erste
Wertung, letzte, eine die fehlt, leere Liste, ein Mitglied). Dass wirklich HALBIERT wird, liest er an einer Liste, die
mitzaehlt, wie oft jemand hineinsieht (die lineare Suche faellt daran auf). Das Portal liest er an einem FRISCHEN
Lauf, auf dem er klickt wie die Maus (klick_auf, LC6), und sieht nach, welche Zeile danach blau ist.

Das Portal startet unsortiert wie nach Bubblesort; die Kopfzeile sortiert (der Bubblesort der Klasse), ein Klick auf
eine Zeile sucht (seit 17.11., Reihensichtung Teil II, Befund 7 -- vorher war die Liste am Start sortiert, und die
Kopfzeile suchte 1400). Aufgabe 3 untersucht die Vorbedingung am eigenen Programm: vor dem Sortieren klicken -- es wird
nichts mehr auskommentiert.

Startzustand (= nach_bubblesort mit vorbereitetem portal.py): die Grundlage passt, offen ist genau Aufgabe 2 ★ (die
Methode fehlt), alles andere wartet. Mehr 6 wartet, bis ist_sortiert steht; die Expertenaufgabe, bis in
rangliste_erste.py die Klasse mit finde_erste_position steht.
"""
import ast
import importlib
import re
import sys

import pruefen
from pruefen import erwarte, braucht, quelltext, anspielen, erzeuge, rufe, klasse, klick_auf

TITEL = "Binäre Suche · Selbstcheck"
EINGABEN = []
HINTS = {"aufnehmen": {"None"}, "anzahl": {"int"}, "get_mitglied": {"Mitglied"}, "finde_position": {"int"},
         "durchgang": {"None", "bool"}, "sortiere": {"None"}, "get_vergleiche": {"int"},
         "finde_position_binaer": {"int"}, "get_fragen": {"int"}, "ist_sortiert": {"bool"}}
DIAGRAMMTYPEN = {"String", "integer", "boolean", "Integer", "Boolean"}
BLAU = "#cfe0fa"
SIEBEN = [("Ada", 10), ("Bo", 20), ("Cem", 30), ("Dua", 40), ("Eli", 50), ("Fin", 60), ("Gül", 70)]
ANMELDUNG = [("Aylin", 1480), ("Bence", 1215), ("Chiara", 1630), ("Dawit", 1342), ("Emre", 1105), ("Finja", 1577),
             ("Goran", 1290), ("Hanh", 1418), ("Ilias", 1048), ("Jule", 1466), ("Kofi", 1712), ("Liv", 1322),
             ("Milan", 1189), ("Nuria", 1540), ("Oskar", 1401), ("Pari", 1273), ("Quinn", 1433), ("Rosa", 1163),
             ("Samir", 1502), ("Tuana", 1251)]
SORTIERT = sorted(ANMELDUNG, key=lambda p: p[1])


def _binaer(wertungen, gesucht):
    """Eigene Rechnung des Checks: (Index oder -1, Zahl der Fragen)."""
    links, rechts, fragen = 0, len(wertungen) - 1, 0
    while links <= rechts:
        mitte = (links + rechts) // 2
        fragen += 1
        if wertungen[mitte] == gesucht:
            return mitte, fragen
        if wertungen[mitte] < gesucht:
            links = mitte + 1
        else:
            rechts = mitte - 1
    return -1, fragen


def _zahlen(text):
    return [int(z) for z in re.findall(r"-?\d+", text)]


def _liste(paare, k="Rangliste"):
    """Eine Rangliste der Klasse mit eigenen Mitgliedern, in dieser Reihenfolge."""
    r = erzeuge(k)
    for name, wertung in paare:
        rufe(r, "aufnehmen", erzeuge("Mitglied", name, wertung))
    return r


def _mitgliedern(n):
    return "einem Mitglied" if n == 1 else "%d Mitgliedern" % n


def _wertungen(paare):
    return ", ".join(str(w) for n, w in paare) or "(keine)"


class _Zaehlliste(list):
    """Eine Liste, die mitschreibt, wie oft jemand hineinsieht -- und ob jemand sie ganz durchlaeuft."""
    gelesen = 0
    ganz = False

    def __getitem__(self, platz):
        self.gelesen += 1
        return list.__getitem__(self, platz)

    def __iter__(self):
        self.ganz = True
        return list.__iter__(self)


def _zaehlend(r):
    """Haengt der Rangliste eine Liste unter, die mitzaehlt. Gibt sie zurueck -- None, wenn die Mitglieder nicht mehr in
    self.__mitglieder stehen."""
    innen = getattr(r, "_Rangliste__mitglieder", None)
    if not isinstance(innen, list):
        return None
    z = _Zaehlliste(innen)
    setattr(r, "_Rangliste__mitglieder", z)
    return z


def _spiel():
    """portal.py noch einmal, frisch. Gibt (Shell am Start, Namensraum, letzte Fehlerzeile) -- der Namensraum ist
    None, wenn das Programm nicht bis zum Ende lief."""
    alt = pruefen._QUELLE
    pruefen._QUELLE = alt + "\nprint('--ENDE--')\n"
    try:
        aus, ns = anspielen([])
    finally:
        pruefen._QUELLE = alt
    zeilen = [z for z in aus.strip().splitlines() if z.strip() and "--ENDE--" not in z]
    fehler = zeilen[-1] if zeilen and "Error" in zeilen[-1] else ""
    return "\n".join(zeilen), (ns if "--ENDE--" in aus else None), fehler


def _klick(zeile):
    """Klickt wie die Maus auf eine Zeile der Liste (-1: die Kopfzeile) -- im Fenster des letzten frischen Laufs.
    Gibt, was dabei in der Shell erschien."""
    a = sys.modules.get("anzeige")
    c = a.flaeche
    y = a.KOPF // 2 if zeile < 0 else a.KOPF + zeile * a.ZEILE + a.ZEILE // 2
    alt = pruefen._FENSTER
    pruefen._FENSTER = c.winfo_toplevel()
    try:
        return klick_auf(120, y, wo="die Kopfzeile" if zeile < 0 else "Zeile %d der Liste" % (zeile + 1))
    finally:
        pruefen._FENSTER = alt


def _blau():
    """Welche Zeilen der Liste sind im Fenster des letzten frischen Laufs blau markiert? (ab 0)"""
    a = sys.modules.get("anzeige")
    c = a.flaeche
    zeilen = []
    for i in c.find_all():
        if c.type(i) == "rectangle" and c.itemcget(i, "fill") == BLAU:
            oben = c.coords(i)[1]
            if oben >= a.KOPF:
                zeilen.append(int(oben - a.KOPF) // a.ZEILE)
    return sorted(zeilen)


def _modul(name):
    m = sys.modules.get(name)
    if m is not None:
        return m
    try:
        return importlib.import_module(name)
    except Exception:  # noqa: BLE001 -- dann gibt es das Modul fuer den Check nicht
        return None


def _ok(pruefung):
    """Passt eine Pruefung? (nur fuer braucht -- faengt den Befund, LC8; auch die Endlosschleife: Die meldet dann
    nur die Pruefung, zu der sie gehoert)"""
    try:
        pruefung()
    except (AssertionError, pruefen._ZuLang):
        return False
    return True


def _start():
    """Ein frischer Lauf, der bis zum Ende kommt -- sonst Befund. Gibt (Shell am Start, Namensraum)."""
    shell, ns, fehler = _spiel()
    erwarte(ns is not None, "portal.py bricht ab, bevor die Liste im Fenster steht%s -- seht in der Shell nach, in "
            "welcher Zeile." % (" (%s)" % fehler if fehler else ""))
    return shell, ns


def pruefe_00_grundlage():
    """Grundlage · portal.py läuft, und ein Klick auf die Kopfzeile sortiert die Liste"""
    shell, ns = _start()
    r = ns.get("rangliste")
    erwarte(r is not None and rufe(r, "anzahl") == 20, "In portal.py gibt es die Rangliste mit den zwanzig Mitgliedern "
            "nicht mehr -- die Zeilen oben in portal.py bleiben, wie sie waren.")
    try:
        _klick(-1)
    except pruefen.Offen as fehler:
        meldung = str(fehler)
        if "wertung" in meldung or "markiert" in meldung:
            meldung += (" Steht die Zeile für die Shell aus Aufgabe 2 ★★ im Zweig für eine Zeile (unter else) -- dort, "
                        "wo es eine Wertung gibt?")
        erwarte(False, meldung)
    ist = [rufe(rufe(r, "get_mitglied", i), "get_wertung") for i in range(20)]
    erwarte(ist == sorted(ist), "Nach einem Klick auf die Kopfzeile ist die Liste des Portals nicht sortiert -- in "
            "klick ruft die Kopfzeile rangliste.sortiere(), wie in Bubblesort. Diese Zeile bleibt.")


def pruefe_20_suche():
    """Aufgabe 2 ★ · finde_position_binaer(wertung): der Index oder -1 -- durch Halbieren, und der Klick markiert die Zeile"""
    braucht(_ok(pruefe_00_grundlage), "Erst läuft portal.py wieder mit der sortierten Liste (Grundlage).")
    k = klasse("Rangliste")
    erwarte(hasattr(k, "finde_position_binaer"), "In rangliste.py fehlt noch die Methode "
            "finde_position_binaer(wertung) -- ein Klick auf eine Zeile ruft sie.")
    r = _liste(SIEBEN)
    for platz, (name, wertung) in enumerate(SIEBEN):
        ist = rufe(r, "finde_position_binaer", wertung)
        erwarte(ist == platz and isinstance(ist, int), "Sieben Mitglieder mit den Wertungen 10, 20, 30, 40, 50, 60, 70: "
                "finde_position_binaer(%d) gibt %r -- erwartet %d%s." % (wertung, ist, platz,
                " (ganz vorn)" if platz == 0 else " (ganz hinten)" if platz == 6 else ""))
    for wertung, wo in ((45, "zwischen zwei Wertungen"), (5, "kleiner als alle"), (99, "größer als alle")):
        ist = rufe(r, "finde_position_binaer", wertung)
        erwarte(ist == -1, "Sieben Mitglieder mit den Wertungen 10 bis 70: finde_position_binaer(%d) gibt %r -- die "
                "Wertung gibt es nicht (%s), erwartet -1." % (wertung, ist, wo))
    for paare in ([], [("Ada", 10)], [("Ada", 10), ("Bo", 20)], SORTIERT):
        r = _liste(paare)
        for platz, (name, wertung) in enumerate(paare):
            ist = rufe(r, "finde_position_binaer", wertung)
            erwarte(ist == platz, "Eine sortierte Rangliste mit %s (%s): finde_position_binaer(%d) gibt %r "
                    "-- erwartet %d." % (_mitgliedern(len(paare)), _wertungen(paare[:4]) + (" …" if len(paare) > 4 else ""), wertung, ist, platz))
        ist = rufe(r, "finde_position_binaer", 15)
        erwarte(ist == -1, "Eine Rangliste %s: finde_position_binaer(15) gibt %r -- erwartet -1."
                % ("ohne Mitglieder" if not paare else "mit " + _mitgliedern(len(paare)), ist))
    viele = [("M%d" % i, 1000 + 3 * i) for i in range(200)]
    r = _liste(viele)
    z = _zaehlend(r)
    erwarte(z is not None, "In rangliste.py stehen die Mitglieder nicht mehr in self.__mitglieder -- der Konstruktor "
            "bleibt, wie er war.")
    for wertung, soll in ((1000 + 3 * 199, 199), (1000, 0), (1001, -1)):
        z.gelesen, z.ganz = 0, False
        ist = rufe(r, "finde_position_binaer", wertung)
        erwarte(ist == soll, "200 sortierte Mitglieder: finde_position_binaer(%d) gibt %r -- erwartet %d." % (wertung, ist, soll))
        erwarte(not z.ganz and z.gelesen <= 32, "200 sortierte Mitglieder: Die Suche findet das Richtige, sieht dafür "
                "aber %s in die Liste -- mit Halbieren sind es höchstens 8 Fragen. Das ist noch die lineare Suche."
                % ("Platz für Platz" if z.ganz else "%d-mal" % z.gelesen))
    shell, ns = _start()
    _klick(-1)
    _klick(11)
    blau = _blau()
    erwarte(blau == [11], "Erst die Kopfzeile (sortiert), dann ein Klick auf Hanh (1418, Index 11): Genau diese Zeile "
            "soll blau markiert sein -- markiert ist %s." % ("keine" if not blau else "Index " + ", ".join(str(b) for b in blau)))
    for zeile in (0, 19):
        _klick(zeile)
        blau = _blau()
        erwarte(blau == [zeile], "In der sortierten Liste soll ein Klick auf die %s Zeile genau diese Zeile markieren -- "
                "markiert ist %s." % ("oberste" if zeile == 0 else "unterste",
                                      "keine" if not blau else "Index " + ", ".join(str(b) for b in blau)))


def pruefe_25_fragen():
    """Aufgabe 2 ★★ · Die Rangliste zählt die Fragen der letzten Suche, und der Klick nennt sie in der Shell"""
    braucht(_ok(pruefe_20_suche), "Erst sucht die Rangliste durch Halbieren (Aufgabe 2 ★).")
    k = klasse("Rangliste")
    erwarte(hasattr(k, "get_fragen"), "In rangliste.py fehlt noch die Methode get_fragen().")
    r = _liste(SIEBEN)
    f = rufe(r, "get_fragen")
    erwarte(f == 0, "Eine neue Rangliste hat noch nicht gesucht -- get_fragen() gibt %r." % (f,))
    werte = [w for n, w in SIEBEN]
    for wertung in (40, 60, 50, 45, 40, 5):
        rufe(r, "finde_position_binaer", wertung)
        f = rufe(r, "get_fragen")
        soll = _binaer(werte, wertung)[1]
        erwarte(f == soll, "Sieben Mitglieder mit den Wertungen 10 bis 70, gesucht %d: Das %s -- "
                "get_fragen() gibt %r. Gezählt wird jeder Blick auf die Mitte, und jede Suche beginnt wieder bei 0."
                % (wertung, "ist 1 Frage" if soll == 1 else "sind %d Fragen" % soll, f))
    shell, ns = _start()
    _klick(-1)
    eins = _klick(11)
    z = _zahlen(eins)
    erwarte(1418 in z and 11 in z and 3 in z, "Erst die Kopfzeile, dann ein Klick auf Hanh (Index 11): In der Shell "
            "sollen die Wertung (1418), der Index (11) und die Fragen (3) stehen -- dort steht: %s"
            % (eins.strip()[:70] or "nichts"))
    shell, ns = _start()
    zwei = _klick(1)
    z = _zahlen(zwei)
    erwarte(1215 in z and -1 in z and 4 in z, "Vor dem Sortieren ein Klick auf Bence (1215, Zeile 2): Dort sollen die "
            "Wertung 1215, der Index -1 und 4 Fragen stehen -- dort steht: %s" % (zwei.strip()[:70] or "nichts"))


def pruefe_60_sortiert():
    """Aufgabe 6 ★★ · ist_sortiert(): True, wenn kein Mitglied höher steht als sein rechter Nachbar"""
    k = klasse("Rangliste")
    braucht(hasattr(k, "ist_sortiert"), "Erst die Methode ist_sortiert() in rangliste.py.")
    for werte, soll, was in (([10, 20, 30, 40], True, ""), ([10, 30, 20, 40], False, ""), ([10, 20, 20, 30], True,
                             " -- zwei gleiche Wertungen nebeneinander sind in Ordnung"), ([20, 10], False, ""),
                             ([10, 20, 30, 25], False, " -- das letzte Paar steht falsch herum"),
                             ([30, 10, 20, 40], False, " -- das erste Paar steht falsch herum"),
                             ([], True, " -- eine leere Liste gilt als sortiert"), ([7], True, " -- ein Mitglied allein ist sortiert")):
        r = _liste([("M%d" % i, w) for i, w in enumerate(werte)])
        ist = rufe(r, "ist_sortiert")
        erwarte(ist is soll, "Mitglieder mit den Wertungen %s: ist_sortiert() gibt %r -- erwartet %r%s."
                % (", ".join(str(w) for w in werte) or "(keine)", ist, soll, was))
    r = _liste(ANMELDUNG)
    vorher = [rufe(rufe(r, "get_mitglied", i), "get_name") for i in range(20)]
    rufe(r, "ist_sortiert")
    nachher = [rufe(rufe(r, "get_mitglied", i), "get_name") for i in range(20)]
    erwarte(vorher == nachher, "ist_sortiert() soll nur nachsehen -- danach steht die Liste aber in einer anderen "
            "Reihenfolge als vorher.")


def pruefe_70_erste():
    """Aufgabe 7 ★★★ · rangliste_erste.py: finde_erste_position(wertung) -- die erste von mehreren, weiter durch Halbieren"""
    m = _modul("rangliste_erste")
    k = getattr(m, "Rangliste", None) if m is not None else None
    braucht(isinstance(k, type) and hasattr(k, "finde_erste_position"), "Erst die Klasse Rangliste mit "
            "finde_erste_position in rangliste_erste.py.")
    for werte in ([10, 20, 20, 20, 30], [20, 20, 20, 20, 20], [10, 10, 20, 30, 30], [10, 20, 30, 40, 50, 60, 70],
                  [10, 20, 20], [20, 20, 30], [10], [], [1048, 1105, 1163, 1215, 1215, 1290, 1342, 1377, 1418]):
        r = _liste([("M%d" % i, w) for i, w in enumerate(werte)], k)
        for wertung in sorted(set(werte)) + [5, 15, 25, 99]:
            soll = werte.index(wertung) if wertung in werte else -1
            ist = rufe(r, "finde_erste_position", wertung)
            erwarte(ist == soll, "Mitglieder mit den Wertungen %s: finde_erste_position(%d) gibt %r -- erwartet %d%s."
                    % (", ".join(str(w) for w in werte) or "(keine)", wertung, ist, soll,
                       " (die Wertung gibt es nicht)" if soll == -1 else " (der kleinste Index mit dieser Wertung)" if werte.count(wertung) > 1 else ""))
    for was, werte, wertung in (("tausend Mitglieder mit derselben Wertung", [1500] * 1000, 1500),
                                ("tausend Mitglieder, die hinteren 600 mit derselben Wertung", [1000 + i for i in range(400)] + [1500] * 600, 1500)):
        r = _liste([("M%d" % i, w) for i, w in enumerate(werte)], k)
        innen = getattr(r, "_Rangliste__mitglieder", None)
        erwarte(isinstance(innen, list), "In rangliste_erste.py stehen die Mitglieder nicht mehr in self.__mitglieder "
                "-- kopiert eure Klasse erst ganz herüber.")
        z = _Zaehlliste(innen)
        setattr(r, "_Rangliste__mitglieder", z)
        ist = rufe(r, "finde_erste_position", wertung)
        soll = werte.index(wertung)
        erwarte(ist == soll, "%s: finde_erste_position(%d) gibt %r -- erwartet %d." % (was[0].upper() + was[1:], wertung, ist, soll))
        erwarte(not z.ganz and z.gelesen <= 40, "%s: Das Ergebnis stimmt, die Suche sieht dafür aber %s in die Liste "
                "-- die Auflage ist Halbieren, höchstens zehn Fragen. Von der Fundstelle aus nach links zu gehen, gilt "
                "nicht." % (was[0].upper() + was[1:], "Platz für Platz" if z.ganz else "%d-mal" % z.gelesen))


def pruefe_90_hints():
    """Hinweis · Jede Methode in rangliste.py mit Type Hints (kein Stern)"""
    try:
        baum = ast.parse(quelltext("rangliste.py"))
    except SyntaxError:
        return
    ohne, falsch, diagramm = [], [], []
    for k in ast.walk(baum):
        if not isinstance(k, ast.FunctionDef):
            continue
        for a in k.args.args + [k]:
            typ = a.annotation if isinstance(a, ast.arg) else a.returns
            if typ is not None and any(isinstance(x, ast.Name) and x.id in DIAGRAMMTYPEN for x in ast.walk(typ)):
                diagramm.append("%s (%s)" % (k.name, ast.unparse(typ)))
        parameter = [a for a in k.args.args if a.arg != "self"]
        if any(a.annotation is None for a in parameter) or (k.returns is None and k.name != "__init__"):
            ohne.append(k.name)
        elif k.name in HINTS and ast.unparse(k.returns).replace(" ", "") not in HINTS[k.name]:
            falsch.append("%s -> %s" % (k.name, " oder ".join(sorted(HINTS[k.name]))))
    erwarte(not diagramm, "Hier steht ein Typ in der Schreibweise des Diagramms: %s. In Python heißt er str, int, "
            "float oder bool." % ", ".join(diagramm))
    erwarte(not ohne, "Ohne Type Hint (hinter der Klammer oder an einem Parameter): %s. Es läuft auch ohne; "
            "vereinbart ist es trotzdem -- der Konstruktor braucht hinter der Klammer keinen." % ", ".join(ohne))
    erwarte(not falsch, "Dieser Type Hint passt nicht zu dem, was zurückkommt -- erwartet: %s." % ", ".join(falsch))
