# felder.py -- die 64 Felder, klein gebaut.
from zeichenflaeche import neue_flaeche, zeige

FELDGROESSE = 70
flaeche = neue_flaeche(8 * FELDGROESSE, 8 * FELDGROESSE)

for zeile in range(8):
    for spalte in range(8):
        x = spalte * FELDGROESSE
        y = zeile * FELDGROESSE
        if (zeile + spalte) % 2 == 0:
            farbe = "#f0d9b5"
        else:
            farbe = "#b58863"
        flaeche.create_rectangle(x, y, x + FELDGROESSE, y + FELDGROESSE,
                                 fill=farbe, outline=farbe)

zeige()
