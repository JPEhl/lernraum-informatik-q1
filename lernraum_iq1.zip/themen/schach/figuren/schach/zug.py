# zug.py -- ein Zug: welche Figur, wohin.
# Der Zug kennt seine Figur. Wo sie beim
# Anlegen steht, merkt er sich als Start.

# erlaubt die eigene Klasse als Typ:
from __future__ import annotations
from figur import Figur


class Zug:

    def __init__(self, figur: Figur, zeile: int, spalte: int):
        self.__figur = figur
        self.__start_zeile = figur.get_zeile()
        self.__start_spalte = figur.get_spalte()
        self.__zeile = zeile
        self.__spalte = spalte

    def get_figur(self) -> Figur:
        return self.__figur

    def get_start_zeile(self) -> int:
        return self.__start_zeile

    def get_start_spalte(self) -> int:
        return self.__start_spalte

    def get_zeile(self) -> int:
        return self.__zeile

    def get_spalte(self) -> int:
        return self.__spalte

    def ausfuehren(self) -> bool:
        return self.__figur.ziehen(self.__zeile, self.__spalte)
