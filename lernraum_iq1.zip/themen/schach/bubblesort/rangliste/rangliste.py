# rangliste.py -- die Rangliste des
# Schachportals. Hier arbeitet ihr
# (Aufgabe 2, 3 und 6).

# erlaubt die eigene Klasse als Typ:
from __future__ import annotations
from mitglied import Mitglied


class Rangliste:

    def __init__(self):
        self.__mitglieder: list[Mitglied] = []

    def aufnehmen(self, mitglied: Mitglied) -> None:
        self.__mitglieder.append(mitglied)

    def anzahl(self) -> int:
        return len(self.__mitglieder)

    def get_mitglied(self, platz: int) -> Mitglied:
        return self.__mitglieder[platz]

    def finde_position(self, name: str) -> int:
        for platz in range(len(self.__mitglieder)):
            if self.__mitglieder[platz].get_name() == name:
                return platz
        return -1
