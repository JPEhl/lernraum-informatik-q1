# spieler.py -- ein Spieler und seine
# Figuren (Aufgabe 2). Hier wohnt die
# Klasse.

# erlaubt die eigene Klasse als Typ:
from __future__ import annotations
from zeichenflaeche import zeichne_bild
from figur import Figur
