"""Selbstcheck „Die Verwalterklasse“ -- prueft das Programm im Ordner schach/ (es laeuft partie.py).

Das Spiel haelt beide Spieler, das Brett als Liste von Listen und das Zugrecht. Der Check prueft die Klasse Spiel ueber
OBJEKTE, die er selbst baut (LC8): erzeuge, rufe -- und liest ihr Feld ueber attribute. Figur.darf prueft er an Lagen,
die er selbst ins Feld stellt. Das Brett liest er wie ein Mensch (LC6) an FRISCHEN Laeufen, auf denen er klickt wie die
Maus (klick_auf).

Seit dem Umbau nach Schnitt A (16.11.2026) ist partie.py vorbereitet: Es fragt nur noch das Spiel. Am Start ist das
Brett leer (jeder Rumpf in spiel.py ist pass), und kein Klick tut etwas.

Fallen (LC5): `reihe = []` vor der aeusseren Schleife haengt acht Namen an EINE Zeile -- deshalb muessen die acht Zeilen
verschiedene Listen sein, und eine Figur in Zeile 2 darf nicht in Zeile 6 stehen. Zeile und Spalte vertauscht --
deshalb (2, 5) gegen (5, 2). Eine Figur nur beim Spieler oder nur im Feld -- deshalb fragt der Check beide Stellen, mit
`is`. Das alte Feld NACH dem Ziehen geleert ist das neue -- deshalb zieht derselbe Bauer zweimal. Das Zugrecht nur im
Klick statt im Spiel -- deshalb ruft der Check ziehe selbst, zweimal fuer Weiss. Wechselt das Zugrecht auch nach einem
Zug, der nicht galt? Deshalb ein verbotener Zug und danach derselbe Spieler. Immer bei Schwarz entfernt -- deshalb
schlaegt auch Schwarz. darf: Aufgabe 3 ★ braucht den Weg noch nicht -- deshalb stehen dort nur Zuege auf ein
Nachbarfeld (ein Fehler am Weg faerbt ★ dann nicht). Der Weg (★★): Das Ziel selbst gehoert nicht dazu -- deshalb ein Turm, der
am Ende seines freien Wegs schlaegt, und einer, der dafuer ueber eine Figur muesste. Der Springer springt.
stimmt: `return True` in der Schleife antwortet am ersten Feld. Matt: Wer beim Probieren die geschlagene Figur weiter
Schach geben laesst, haelt „Dame schlaegt f7“ fuer Matt -- der Koenig kann sie aber schlagen.

Startzustand (Arbeitsordner, vorbereitet): partie.py laeuft und zeigt ein leeres Brett. Offen ist genau Aufgabe 2 ★,
alles andere wartet (LC1).
"""
import ast
import importlib
import sys

import pruefen
from pruefen import erwarte, braucht, arbeit, flaeche, quelltext, anspielen, erzeuge, rufe, attribute, klasse, \
    klick_auf

TITEL = "Die Verwalterklasse · Selbstcheck"
EINGABEN = []
HINTS = {"figur_auf": {"Figur"}, "ziehe": {"bool"}, "zeichne": {"None"}, "stimmt": {"bool"}, "__stelle": {"None"},
         "get_am_zug": {"Spieler"}, "ist_vorbei": {"bool"}}
DIAGRAMMTYPEN = {"String", "integer", "boolean", "Integer", "Boolean"}
ARTEN = ["Turm", "Springer", "Läufer", "Dame", "König", "Läufer", "Springer", "Turm"]


def _wo(feld):
    return "Zeile %d, Spalte %d" % tuple(feld)


def _lauf():
    """partie.py noch einmal, frisch. Gibt (Flaeche, Feldgroesse, letzte Fehlerzeile) -- die Flaeche ist None, wenn
    das Programm nicht bis zum Ende lief."""
    alt_q = pruefen._QUELLE
    pruefen._QUELLE = alt_q + "\nprint('--ENDE--')\n"
    try:
        aus, ns = anspielen([])
    finally:
        pruefen._QUELLE = alt_q
    zeilen = [z for z in aus.strip().splitlines() if z.strip() and "--ENDE--" not in z]
    fehler = zeilen[-1] if zeilen and "Error" in zeilen[-1] else ""
    return (ns.get("flaeche") if "--ENDE--" in aus else None), ns.get("FELDGROESSE"), fehler


def _klick(c, feld, g):
    alt = pruefen._FENSTER
    pruefen._FENSTER = c.winfo_toplevel()
    try:
        return klick_auf(feld[1] * g + g // 2, feld[0] * g + g // 2, wo=_wo(feld))
    finally:
        pruefen._FENSTER = alt


def _bilder_auf(c, feld, g):
    """ALLE Bilder, die auf dem Feld liegen -- zwei Figuren auf einem Feld sind der Fehler dieses Themas."""
    aus = []
    for i in c.find_all():
        if c.type(i) == "image":
            k = c.coords(i)
            if (int(k[1]) // g, int(k[0]) // g) == tuple(feld):
                aus.append(pruefen._bilddatei(c, c.itemcget(i, "image")))
    return sorted(aus)


def _texte(c):
    return [str(c.itemcget(i, "text")) for i in c.find_all() if c.type(i) == "text"]


def _alle_bilder(c):
    return [i for i in c.find_all() if c.type(i) == "image"]


def _rahmen(c):
    """Wie viele Felder markiert sind: das rot gerahmte Feld der gewaehlten Figur und ihre Ziele -- seit 16.11.2026
    graue Punkte (ein Rahmen als Ziel zaehlt weiter)."""
    return len([i for i in c.find_all() if (c.type(i) == "rectangle" and c.itemcget(i, "outline") == "red")
                or c.type(i) == "oval"])


def _rote_pfeile(c):
    return len([i for i in c.find_all() if c.type(i) == "line" and c.itemcget(i, "fill") == "red"])


def _ok(pruefung):
    try:
        pruefung()
    except AssertionError:
        return False
    return True


def _modul(name):
    m = sys.modules.get(name)
    if m is not None:
        return m
    try:
        return importlib.import_module(name)
    except Exception:  # noqa: BLE001 -- dann gibt es das Modul fuer den Check nicht
        return None


def _klasse_spiel():
    """Die Klasse Spiel -- auch, solange partie.py spiel.py noch nicht laedt (Aufgabe 2 vor Aufgabe 3)."""
    k = klasse("Spiel")
    if k is None:
        k = getattr(_modul("spiel"), "Spiel", None)
    return k if isinstance(k, type) else None


def _spiel():
    return erzeuge(_klasse_spiel())


def _feld(s):
    return attribute(s).get("__feld")


def _spieler(s, farbe):
    return attribute(s).get("__weiss" if farbe == "weiß" else "__schwarz")


def _hat(spieler, figur):
    """Steht genau dieses Objekt in der Liste des Spielers?"""
    return any(f is figur for f in (attribute(spieler).get("__figuren") or []))


def _platz(figur):
    return (rufe(figur, "get_zeile"), rufe(figur, "get_spalte"))


def _was(figur):
    if figur is None:
        return "nichts (None)"
    if type(figur).__name__ != "Figur":
        return repr(figur)
    return "%s %s" % (rufe(figur, "get_art"), rufe(figur, "get_farbe"))


def _soll(zeile, spalte):
    """Was in der Startaufstellung auf dem Feld steht: (art, farbe) oder None."""
    return {0: (ARTEN[spalte], "schwarz"), 1: ("Bauer", "schwarz"), 6: ("Bauer", "weiß"),
            7: (ARTEN[spalte], "weiß")}.get(zeile)


def _aufgestellt():
    return _klasse_spiel() is not None and _ok(pruefe_25_aufstellung)


def _zieht():
    return _aufgestellt() and _ok(pruefe_30_ziehe)


def _zug(s, von, nach):
    """Ein Zug der Figur, die im Spiel s auf `von` steht -- ueber ziehe. Gibt zurueck, was ziehe sagt."""
    return rufe(s, "ziehe", erzeuge("Zug", rufe(s, "figur_auf", *von), *nach))


def _darf(s, von, nach):
    return rufe(rufe(s, "figur_auf", *von), "darf", nach[0], nach[1], s)


def pruefe_00_grundlage():
    """Grundlage · figur.py, spieler.py und spiel.py laden, das Programm hat eine Zeichenfläche"""
    erwarte(klasse("Figur") is not None, "In figur.py steht keine Klasse Figur mehr -- seht in der Shell nach.")
    erwarte(klasse("Spieler") is not None, "In spieler.py steht keine Klasse Spieler mehr -- seht in der Shell nach.")
    erwarte(_klasse_spiel() is not None, "In spiel.py steht keine Klasse Spiel -- oder spiel.py lässt sich nicht laden. "
            "Seht in der Shell nach.")
    erwarte(flaeche() is not None, "Das Programm bricht ab, bevor es eine Zeichenfläche hat -- seht in der Shell nach.")
    g = getattr(arbeit(), "FELDGROESSE", None)
    erwarte(isinstance(g, int) and g > 0, "FELDGROESSE ist keine ganze Zahl über 0 -- oben in partie.py.")


def pruefe_20_feld():
    """Aufgabe 2 ★ · Das Spiel legt beide Spieler und das leere Brett an, Weiß ist am Zug, figur_auf greift hinein"""
    s = _spiel()
    feld = _feld(s)
    erwarte(isinstance(feld, list) and len(feld) == 8 and all(isinstance(r, list) and len(r) == 8 for r in feld),
            "Im Spiel fehlt noch das Brett: self.__feld als Liste von acht Zeilen, jede eine Liste mit acht Feldern.")
    erwarte(len({id(r) for r in feld}) == 8, "Die acht Zeilen des Bretts sind ein und dieselbe Liste -- eine Figur in "
            "Zeile 0 stünde dann in jeder Zeile. Wo steht reihe = []?")
    for farbe in ("weiß", "schwarz"):
        sp = _spieler(s, farbe)
        erwarte(type(sp).__name__ == "Spieler" and attribute(sp).get("__farbe") == farbe,
                "Das Spiel hat noch keinen Spieler %r in self.__%s." % (farbe, "weiss" if farbe == "weiß" else "schwarz"))
    erwarte(attribute(s).get("__am_zug") is _spieler(s, "weiß"), "Das Spiel merkt sich noch nicht, wer am Zug ist: "
            "self.__am_zug -- am Anfang der weiße Spieler selbst (nicht sein Name, nicht ein neuer Spieler).")
    erwarte(rufe(s, "get_am_zug") is _spieler(s, "weiß"), "get_am_zug() gibt am Anfang nicht den weißen Spieler des "
            "Spiels zurück.")
    probe = erzeuge("Figur", "Läufer", "weiß", 2, 5)
    alt, feld[2][5] = feld[2][5], probe
    try:
        oben = rufe(s, "figur_auf", 2, 5)
        unten = rufe(s, "figur_auf", 5, 2)
        anders = rufe(s, "figur_auf", 6, 5) if feld[6][5] is None else None
    finally:
        feld[2][5] = alt
    erwarte(oben is probe, "Im Feld Zeile 2, Spalte 5 steht ein Läufer -- figur_auf(2, 5) gibt aber %s zurück. Erst die "
            "Zeile, dann die Spalte." % _was(oben))
    erwarte(unten is not probe, "figur_auf(5, 2) gibt den Läufer aus Zeile 2, Spalte 5 zurück -- sind Zeile und Spalte "
            "vertauscht?")
    erwarte(anders is not probe, "Der Läufer steht in Zeile 2 -- figur_auf findet ihn auch in Zeile 6. Ist jede Zeile "
            "eine eigene Liste?")


def pruefe_25_aufstellung():
    """Aufgabe 2 ★★ · Der Konstruktor stellt alle 32 Figuren an beide Stellen"""
    braucht(_ok(pruefe_20_feld), "Erst das leere Brett und figur_auf (Aufgabe 2 ★).")
    s = _spiel()
    weiss, schwarz = _spieler(s, "weiß"), _spieler(s, "schwarz")
    for zeile in range(8):
        for spalte in range(8):
            f = rufe(s, "figur_auf", zeile, spalte)
            soll = _soll(zeile, spalte)
            if soll is None:
                erwarte(f is None, "In Zeile %d, Spalte %d steht %s -- in der Startaufstellung ist das Feld leer."
                        % (zeile, spalte, _was(f)))
                continue
            erwarte(f is not None, "Zeile %d, Spalte %d ist leer -- dort steht in der Startaufstellung %s %s. Kommt jede "
                    "Figur über __stelle ins Feld?" % (zeile, spalte, soll[0], soll[1]))
            erwarte((rufe(f, "get_art"), rufe(f, "get_farbe")) == soll, "In Zeile %d, Spalte %d steht %s statt %s %s."
                    % (zeile, spalte, _was(f), soll[0], soll[1]))
            erwarte(_platz(f) == (zeile, spalte), "Die Figur in Zeile %d, Spalte %d glaubt, sie stehe auf %s -- Feld und "
                    "Figur sagen Verschiedenes." % (zeile, spalte, _platz(f)))
            erwarte(_hat(weiss if soll[1] == "weiß" else schwarz, f), "%s %s steht im Feld (%d, %d), aber nicht in der "
                    "Liste des Spielers %s -- __stelle trägt jede Figur an BEIDEN Stellen ein."
                    % (soll[0], soll[1], zeile, spalte, soll[1]))
    for sp, farbe in ((weiss, "weiß"), (schwarz, "schwarz")):
        n = rufe(sp, "anzahl")
        erwarte(n == 16, "Der Spieler %s hat %r Figuren statt 16 -- steht eine Figur doppelt in seiner Liste?" % (farbe, n))
    # ... und das Spiel zeichnet aus dem Feld: das Brett von partie.py
    c, g = flaeche(), getattr(arbeit(), "FELDGROESSE", None)
    n = len(_alle_bilder(c))
    erwarte(n == 32, "Das Spiel hat alle 32 Figuren -- auf dem Brett liegen aber %d Bilder. Zeichnet zeichne(groesse) "
            "jede Figur, die im Feld steht?" % n)
    for feld, bild, wer in (((0, 4), "koenig-s.png", "der schwarze König"), ((7, 3), "dame-w.png", "die weiße Dame"),
                            ((6, 0), "bauer-w.png", "ein weißer Bauer"), ((1, 7), "bauer-s.png", "ein schwarzer Bauer")):
        dort = _bilder_auf(c, feld, g)
        erwarte(dort == [bild], "Auf %s steht im Spiel %s -- auf dem Brett liegt dort %s. Aus Spalte und Zeile wird x "
                "und y: erst die Spalte." % (_wo(feld), wer, " und ".join(dort) or "nichts"))


def _ziel_ueber_das_spiel():
    """darf ohne den Weg (Aufgabe 3 ★): Wer steht am Ziel? Nur Zuege auf ein NACHBARFELD -- dort liegt kein Feld
    dazwischen, ein Fehler am Weg (★★) faerbt diese Pruefung also nicht (LC3)."""
    erwarte(hasattr(klasse("Figur"), "darf"), "In figur.py fehlt darf(zeile, spalte, spiel) -- der Kopf stand schon da.")
    s = _spiel()
    feld = _feld(s)
    erwarte(_darf(s, (6, 2), (5, 2)) is not None, "darf(zeile, spalte, spiel) in figur.py gibt noch nichts zurück -- der "
            "Rumpf ist eure Arbeit: Wer steht am Ziel?")
    bauer, feld[6][4] = feld[6][4], None
    try:
        for von, nach, soll, warum in (((7, 4), (6, 4), True, "das Ziel ist leer, und der Zug passt zum König"),
                                       ((7, 4), (6, 3), False, "am Ziel steht eine eigene Figur"),
                                       ((7, 4), (5, 4), False, "zwei Felder weit zieht kein König"),
                                       ((6, 2), (5, 2), True, "das Feld vor dem Bauern ist leer")):
            ist = _darf(s, von, nach)
            erwarte(ist is soll, "Ohne den Bauern auf Zeile 6, Spalte 4: Die weiße Figur auf %s fragt darf(%d, %d, spiel) "
                    "und bekommt %r statt %r -- %s." % (_wo(von), nach[0], nach[1], ist, soll, warum))
        feld[6][4] = erzeuge("Figur", "Turm", "schwarz", 6, 4)
        ist = _darf(s, (7, 4), (6, 4))
        erwarte(ist is True, "Vor dem weißen König steht ein schwarzer Turm (Zeile 6, Spalte 4): Der König darf ihn "
                "schlagen -- darf gibt %r." % (ist,))
    finally:
        feld[6][4] = bauer
    feld[5][2] = erzeuge("Figur", "Turm", "schwarz", 5, 2)
    try:
        for von, nach, soll, warum in (((6, 2), (5, 2), False, "geradeaus schlägt ein Bauer nicht"),
                                       ((6, 1), (5, 2), True, "ein Bauer schlägt schräg nach vorn"),
                                       ((6, 1), (5, 0), False, "schräg zieht ein Bauer nur, wenn er schlägt")):
            ist = _darf(s, von, nach)
            erwarte(ist is soll, "Ein schwarzer Turm steht auf Zeile 5, Spalte 2: Der weiße Bauer auf %s fragt "
                    "darf(%d, %d, spiel) und bekommt %r statt %r -- %s." % (_wo(von), nach[0], nach[1], ist, soll, warum))
    finally:
        feld[5][2] = None


def pruefe_30_ziehe():
    """Aufgabe 3 ★ · Wer zieht, fragt das Spiel: Zugrecht, Ziel, beide Stellen -- und geschlagen wird auch"""
    braucht(_aufgestellt(), "Erst stellt das Spiel alle Figuren auf (Aufgabe 2).")
    _ziel_ueber_das_spiel()
    s = _spiel()
    weiss, schwarz = _spieler(s, "weiß"), _spieler(s, "schwarz")
    bauer = rufe(s, "figur_auf", 6, 4)
    antwort = _zug(s, (6, 4), (5, 4))
    erwarte(_platz(bauer) == (5, 4), "Weiß beginnt: ziehe mit dem Bauern von Zeile 6, Spalte 4 nach Zeile 5 -- der Bauer "
            "steht laut sich selbst danach auf %s. Wird der Zug ausgeführt?" % (_platz(bauer),))
    erwarte(rufe(s, "figur_auf", 5, 4) is bauer, "Der Bauer ist nach Zeile 5, Spalte 4 gezogen -- im Feld steht dort "
            "aber %s." % _was(rufe(s, "figur_auf", 5, 4)))
    erwarte(rufe(s, "figur_auf", 6, 4) is None, "Der Bauer ist von Zeile 6, Spalte 4 weggezogen -- im Feld steht dort "
            "aber noch %s. Welches Feld leert ihr -- das alte oder das neue?" % _was(rufe(s, "figur_auf", 6, 4)))
    erwarte(antwort is True, "Der Zug galt -- ziehe gibt aber %r zurück statt True." % (antwort,))
    erwarte(rufe(s, "get_am_zug") is schwarz, "Weiß hat gezogen -- danach ist Schwarz am Zug. get_am_zug() gibt aber "
            "nicht den schwarzen Spieler.")
    noch_einer = rufe(s, "figur_auf", 6, 0)
    antwort = _zug(s, (6, 0), (5, 0))
    erwarte(antwort is False and rufe(s, "figur_auf", 6, 0) is noch_einer and _platz(noch_einer) == (6, 0),
            "Weiß hat gerade gezogen und will gleich noch einmal: ziehe gibt %r zurück%s. Wer nicht am Zug ist, zieht "
            "nicht -- das prüft das Spiel, nicht der Klick."
            % (antwort, "" if rufe(s, "figur_auf", 6, 0) is noch_einer else ", und der Bauer ist gezogen"))
    erwarte(rufe(s, "get_am_zug") is schwarz, "Ein Zug, der nicht galt, ändert das Zugrecht nicht -- Schwarz bleibt am "
            "Zug.")
    opfer = rufe(s, "figur_auf", 1, 3)
    erwarte(_zug(s, (1, 3), (2, 3)) is True and rufe(s, "get_am_zug") is weiss, "Schwarz zieht den Bauern von Zeile 1, "
            "Spalte 3 nach Zeile 2 -- das gilt, und danach ist wieder Weiß am Zug.")
    erwarte(_zug(s, (5, 4), (4, 4)) is True and rufe(s, "figur_auf", 4, 4) is bauer and rufe(s, "figur_auf", 5, 4) is None,
            "Derselbe weiße Bauer zieht weiter nach Zeile 4, Spalte 4: Danach steht dort %s und auf Zeile 5, Spalte 4 %s."
            % (_was(rufe(s, "figur_auf", 4, 4)), _was(rufe(s, "figur_auf", 5, 4))))
    _zug(s, (2, 3), (3, 3))
    antwort = _zug(s, (4, 4), (3, 3))
    erwarte(antwort is True and rufe(s, "figur_auf", 3, 3) is bauer, "Der weiße Bauer schlägt schräg den schwarzen auf "
            "Zeile 3, Spalte 3 -- im Feld steht danach %s. Sucht ihr das Opfer, bevor die Figur zieht?"
            % _was(rufe(s, "figur_auf", 3, 3)))
    erwarte(not _hat(schwarz, opfer) and rufe(schwarz, "anzahl") == 15, "Der schwarze Bauer ist geschlagen -- Schwarz "
            "hat ihn aber noch in seiner Liste (%r Figuren)." % (rufe(schwarz, "anzahl"),))
    erwarte(rufe(weiss, "anzahl") == 16, "Weiß hat nach dem Schlagen %r Figuren statt 16 -- wer verliert die Figur?"
            % (rufe(weiss, "anzahl"),))
    erwarte(_zug(s, (1, 2), (2, 2)) is True and _zug(s, (6, 0), (5, 0)) is True, "Schwarz zieht einen Bauern (Zeile 1, "
            "Spalte 2, ein Feld vor), dann Weiß (Zeile 6, Spalte 0, ein Feld vor) -- beide Züge gelten.")
    schwarzer = rufe(s, "figur_auf", 2, 2)
    antwort = _zug(s, (2, 2), (3, 3))
    erwarte(antwort is True and rufe(s, "figur_auf", 3, 3) is schwarzer and not _hat(weiss, bauer)
            and rufe(weiss, "anzahl") == 15, "Der schwarze Bauer schlägt schräg den weißen auf Zeile 3, Spalte 3 -- "
            "danach hat Weiß %r Figuren statt 15, im Feld steht %s. Wer ist der Gegner, wenn Schwarz zieht?"
            % (rufe(weiss, "anzahl"), _was(rufe(s, "figur_auf", 3, 3))))
    antwort = _zug(s, (7, 4), (5, 4))
    erwarte(antwort is False and rufe(s, "get_am_zug") is weiss, "Der weiße König will zwei Felder vor, nach Zeile 5, "
            "Spalte 4: ziehe gibt %r zurück%s. Fragt ziehe die Figur, ob sie das darf -- und bleibt Weiß danach am Zug?"
            % (antwort, "" if rufe(s, "get_am_zug") is weiss else ", und Schwarz ist am Zug"))
    antwort = _zug(s, (7, 0), (7, 1))
    erwarte(antwort is False and rufe(weiss, "anzahl") == 15, "Der weiße Turm will auf das Feld des eigenen Springers: "
            "ziehe gibt %r zurück, Weiß hat danach %r Figuren." % (antwort, rufe(weiss, "anzahl")))
    erwarte(rufe(s, "ist_vorbei") is False, "Beide Könige stehen noch -- ist_vorbei() gibt %r statt False."
            % (rufe(s, "ist_vorbei"),))
    rufe(schwarz, "entferne", rufe(s, "figur_auf", 0, 4))
    erwarte(rufe(s, "ist_vorbei") is True, "Schwarz hat keinen König mehr -- ist_vorbei() gibt %r statt True."
            % (rufe(s, "ist_vorbei"),))
    # ... und am Brett: geklickt wie die Maus
    c, g, fehler = _lauf()
    erwarte(c is not None, "partie.py bricht ab, bevor das Brett fertig ist%s." % (" (%s)" % fehler if fehler else ""))
    _klick(c, (6, 4), g)
    shell = _klick(c, (5, 4), g)
    erwarte(_bilder_auf(c, (5, 4), g) == ["bauer-w.png"] and not _bilder_auf(c, (6, 4), g), "Am Brett: Ein Klick auf den "
            "weißen Bauern auf Zeile 6, Spalte 4, einer auf das Feld davor -- der Bauer steht danach nicht dort.")
    erwarte("schwarz" in shell, "Weiß hat gezogen -- in der Shell steht nicht, dass Schwarz am Zug ist: %s"
            % (shell.strip()[:60] or "nichts"))
    _klick(c, (6, 0), g)
    _klick(c, (5, 0), g)
    erwarte(_bilder_auf(c, (6, 0), g) == ["bauer-w.png"], "Am Brett: Weiß hat gerade gezogen -- trotzdem zieht gleich "
            "noch ein weißer Bauer.")
    _klick(c, (1, 0), g)
    shell = _klick(c, (2, 0), g)
    erwarte(_bilder_auf(c, (2, 0), g) == ["bauer-s.png"] and "weiß" in shell, "Am Brett: Schwarz ist am Zug -- der "
            "schwarze Bauer von Zeile 1, Spalte 0 zieht aber nicht nach Zeile 2, oder die Shell nennt danach nicht Weiß.")


def pruefe_35_weg():
    """Aufgabe 3 ★★ · Der Weg zählt: Keine Figur springt -- außer dem Springer"""
    braucht(_zieht(), "Erst zieht das Spiel (Aufgabe 3 ★).")
    s = _spiel()
    feld = _feld(s)
    for von, nach, soll, wer, warum in (((7, 0), (5, 0), False, "Der weiße Turm", "der eigene Bauer steht im Weg"),
                                        ((7, 3), (3, 7), False, "Die weiße Dame", "der eigene Bauer steht im Weg"),
                                        ((7, 2), (5, 0), False, "Der weiße Läufer", "der eigene Bauer steht im Weg"),
                                        ((7, 1), (5, 0), True, "Der weiße Springer", "der Springer springt"),
                                        ((6, 4), (4, 4), True, "Der weiße Bauer", "das Feld dazwischen ist leer")):
        ist = _darf(s, von, nach)
        erwarte(ist is soll, "Startaufstellung: %s auf %s fragt darf(%d, %d, spiel) und bekommt %r statt %r -- %s."
                % (wer, _wo(von), nach[0], nach[1], ist, soll, warum))
    feld[5][4] = erzeuge("Figur", "Springer", "schwarz", 5, 4)
    try:
        ist = _darf(s, (6, 4), (4, 4))
        erwarte(ist is False, "Vor dem weißen Bauern auf Zeile 6, Spalte 4 steht ein schwarzer Springer: Zwei Felder vor "
                "darf der Bauer dann nicht -- darf gibt %r." % (ist,))
    finally:
        feld[5][4] = None
    bauer, feld[6][0] = feld[6][0], None
    try:
        for nach, soll, warum in (((2, 0), True, "der Weg ist frei, das Ziel leer"),
                                  ((1, 0), True, "der Weg ist frei, am Ziel steht ein Gegner: Das Ziel gehört nicht zum Weg"),
                                  ((0, 0), False, "dafür müsste er über den schwarzen Bauern hinweg")):
            ist = _darf(s, (7, 0), nach)
            erwarte(ist is soll, "Ohne den Bauern auf Zeile 6, Spalte 0: Der weiße Turm auf Zeile 7, Spalte 0 fragt "
                    "darf(%d, %d, spiel) und bekommt %r statt %r -- %s." % (nach[0], nach[1], ist, soll, warum))
    finally:
        feld[6][0] = bauer
    bauer, feld[1][1] = feld[1][1], None
    try:
        ist = _darf(s, (0, 2), (2, 0))
        erwarte(ist is True, "Ohne den Bauern auf Zeile 1, Spalte 1: Der schwarze Läufer auf Zeile 0, Spalte 2 darf "
                "schräg nach Zeile 2, Spalte 0 -- darf gibt %r. Stimmt die Richtung, wenn die Spalte kleiner wird?" % (ist,))
        ist = _darf(s, (0, 2), (5, 7))
        erwarte(ist is False, "Der schwarze Läufer auf Zeile 0, Spalte 2 will nach Zeile 5, Spalte 7 -- auf Zeile 1, "
                "Spalte 3 steht sein eigener Bauer im Weg. darf gibt %r." % (ist,))
    finally:
        feld[1][1] = bauer
    # ... und am Brett
    c, g, fehler = _lauf()
    erwarte(c is not None, "partie.py bricht ab, bevor das Brett fertig ist%s." % (" (%s)" % fehler if fehler else ""))
    _klick(c, (7, 0), g)
    erwarte(_rahmen(c) == 1 and _rote_pfeile(c) == 0, "Am Brett: Der weiße Turm auf Zeile 7, Spalte 0 ist gewählt. Er "
            "kann nirgendhin -- einen Punkt tragen aber %d Felder, und %d rote Pfeile zeigen auf Gegner."
            % (_rahmen(c) - 1, _rote_pfeile(c)))
    _klick(c, (7, 1), g)
    erwarte(_rahmen(c) == 3, "Am Brett: Der weiße Springer auf Zeile 7, Spalte 1 ist gewählt. Er hat zwei Ziele -- "
            "einen Punkt tragen %d Felder." % (_rahmen(c) - 1))


def pruefe_60_stimmt():
    """Aufgabe 6 ★★ · stimmt(): Sagen Feld und Figuren dasselbe?"""
    braucht(_zieht(), "Erst zieht das Spiel (Aufgabe 3 ★).")
    braucht(hasattr(_klasse_spiel(), "stimmt"), "Erst die Methode stimmt in spiel.py.")
    s = _spiel()
    erwarte(rufe(s, "stimmt") is True, "Ein frisch aufgestelltes Spiel: stimmt() sagt %r statt True."
            % (rufe(s, "stimmt"),))
    _zug(s, (6, 2), (5, 2))
    erwarte(rufe(s, "stimmt") is True, "Nach spiel.ziehe sagt stimmt() %r statt True -- über das Spiel gezogen, stimmen "
            "beide Stellen." % (rufe(s, "stimmt"),))
    rufe(rufe(s, "figur_auf", 7, 7), "ziehen", 4, 7)
    erwarte(rufe(s, "stimmt") is False, "Der Turm auf Zeile 7, Spalte 7 ist am Spiel vorbei nach Zeile 4 gezogen -- "
            "stimmt() sagt trotzdem %r. Fragt ihr jedes Feld -- und reicht es, wenn nur die Zeile nicht passt?"
            % (rufe(s, "stimmt"),))


def _feldname(n):
    """„e4“ -> (4, 4): Spalte a bis h = 0 bis 7, Reihe 1 (Weiß) ist Zeile 7."""
    return (8 - int(n[1]), "abcdefgh".index(n[0]))


def _partie(k, zuege):
    """Ein Spiel der Klasse k, in dem die Züge („e2e4 e7e5“) über ziehe gespielt sind."""
    s = erzeuge(k)
    for z in zuege.split():
        von, nach = _feldname(z[:2]), _feldname(z[2:])
        erwarte(rufe(s, "ziehe", erzeuge("Zug", rufe(s, "figur_auf", *von), *nach)) is True, "In spiel_matt.py: Der Zug "
                "von %s nach %s gilt (Partie: %s) -- ziehe sagt aber nicht True." % (_wo(von), _wo(nach), zuege))
    return s


def _stellung(s):
    return [[(id(f), _platz(f)) if f is not None else None for f in reihe] for reihe in _feld(s)]


def pruefe_70_matt():
    """Aufgabe 7 ★★★ · spiel_matt.py: Schach, Matt und Patt"""
    m = _modul("spiel_matt")
    k = getattr(m, "Spiel", None) if m is not None else None
    braucht(isinstance(k, type) and hasattr(k, "ist_matt"), "Erst die Klasse Spiel mit ist_matt in spiel_matt.py.")
    braucht(_ok(pruefe_35_weg), "Matt und Patt brauchen den Weg (Aufgabe 3 ★★).")
    erwarte(hasattr(k, "ist_patt"), "In spiel_matt.py fehlt noch ist_patt().")
    s = erzeuge(k)
    erwarte(rufe(s, "ist_matt") is False and rufe(s, "ist_patt") is False, "Die Startaufstellung ist weder Matt noch "
            "Patt -- ist_matt() gibt %r, ist_patt() gibt %r." % (rufe(s, "ist_matt"), rufe(s, "ist_patt")))
    s = _partie(k, "f2f3 e7e5 g2g4 d8h4")
    vorher = _stellung(s)
    matt = rufe(s, "ist_matt")
    erwarte(_stellung(s) == vorher and rufe(_spieler(s, "weiß"), "anzahl") == 16
            and rufe(_spieler(s, "schwarz"), "anzahl") == 16, "Die Auflage: Nach ist_matt() steht jede Figur, wo sie "
            "vorher stand, und keine fehlt. Hier ist das Brett danach anders -- wird jeder Zug zur Probe zurückgenommen?")
    erwarte(matt is True and rufe(s, "ist_patt") is False, "Weiß zieht die Bauern vor dem König weg (Spalte 5 ein Feld, "
            "Spalte 6 zwei Felder), die schwarze Dame kommt nach Zeile 4, Spalte 7: Der weiße König steht im Schach, "
            "und kein Zug rettet ihn. ist_matt() gibt %r, ist_patt() gibt %r." % (matt, rufe(s, "ist_patt")))
    s = _partie(k, "f2f3 e7e6 a2a3 d8h4")
    erwarte(rufe(s, "ist_matt") is False, "Die schwarze Dame gibt Schach von Zeile 4, Spalte 7 -- der Bauer auf Zeile 6, "
            "Spalte 6 kann sich aber dazwischenstellen. ist_matt() sagt trotzdem True.")
    vorher = _stellung(s)
    antwort = rufe(s, "ziehe", erzeuge("Zug", rufe(s, "figur_auf", 5, 0), 4, 0))
    erwarte(antwort is False and _stellung(s) == vorher and rufe(rufe(s, "get_am_zug"), "get_farbe") == "weiß",
            "Der weiße König steht im Schach, Weiß zieht aber den Bauern am Rand (Zeile 5, Spalte 0): Der Zug lässt den "
            "König im Schach und gilt nicht -- ziehe gibt %r, und danach muss alles stehen wie vorher." % (antwort,))
    antwort = rufe(s, "ziehe", erzeuge("Zug", rufe(s, "figur_auf", 6, 6), 5, 6))
    erwarte(antwort is True, "Der weiße Bauer stellt sich zwischen Dame und König (nach Zeile 5, Spalte 6) -- der Zug "
            "gilt. ziehe gibt %r." % (antwort,))
    s = _partie(k, "e2e4 e7e5 d1h5 b8c6 h5f7")
    erwarte(rufe(s, "ist_matt") is False, "Die weiße Dame schlägt den Bauern neben dem schwarzen König (Zeile 1, "
            "Spalte 5) und gibt Schach -- der König kann sie aber schlagen. ist_matt() sagt trotzdem True: Zählt beim "
            "Probieren eine Figur mit, die gerade geschlagen wäre?")
    antwort = rufe(s, "ziehe", erzeuge("Zug", rufe(s, "figur_auf", 0, 4), 1, 5))
    erwarte(antwort is True, "Der schwarze König schlägt die Dame, die ihm Schach gibt -- der Zug gilt. ziehe gibt %r."
            % (antwort,))
    s = _partie(k, "e2e4 e7e5 d1h5 b8c6 f1c4 g8f6 h5f7")
    erwarte(rufe(s, "ist_matt") is True, "Dieselbe Dame auf Zeile 1, Spalte 5 -- diesmal deckt sie der weiße Läufer von "
            "Zeile 4, Spalte 2: Der König darf sie nicht schlagen, er stünde wieder im Schach. ist_matt() gibt %r."
            % (rufe(s, "ist_matt"),))
    s = _partie(k, "e2e3 a7a5 d1h5 a8a6 h5a5 h7h5 h2h4 a6h6 a5c7 f7f6 c7d7 e8f7 d7b7 d8d3 b7b8 d3h7 b8c8 f7g6 c8e6")
    erwarte(rufe(s, "ist_patt") is True and rufe(s, "ist_matt") is False, "Eine Partie, in der Weiß zehnmal zieht und an deren "
            "Ende Schwarz nicht im Schach steht und trotzdem keinen Zug hat (das kürzeste Patt, Sam Loyd): ist_patt() "
            "gibt %r, ist_matt() gibt %r." % (rufe(s, "ist_patt"), rufe(s, "ist_matt")))


def pruefe_90_hints():
    """Hinweis · Jede Methode in spiel.py mit Type Hints (kein Stern)"""
    braucht(_aufgestellt(), "Erst stellt das Spiel auf.")
    ohne, falsch, diagramm = [], [], []
    try:
        baum = ast.parse(quelltext("spiel.py"))
    except (SyntaxError, OSError, TypeError):
        return
    for k in ast.walk(baum):
        if not isinstance(k, ast.FunctionDef):
            continue
        for a in k.args.args + [k]:
            typ = a.annotation if isinstance(a, ast.arg) else a.returns
            if typ is not None and any(isinstance(x, ast.Name) and x.id in DIAGRAMMTYPEN for x in ast.walk(typ)):
                diagramm.append("%s (%s)" % (k.name, ast.unparse(typ)))
        parameter = [a for a in k.args.args if a.arg != "self"]
        if any(a.annotation is None for a in parameter) or (k.returns is None and k.name != "__init__"):
            ohne.append(k.name)
        elif k.name in HINTS and ast.unparse(k.returns).replace(" ", "") not in HINTS[k.name]:
            falsch.append("%s -> %s" % (k.name, " oder ".join(sorted(HINTS[k.name]))))
    erwarte(not diagramm, "Hier steht ein Typ in der Schreibweise des Diagramms: %s. In Python heißt er str, int, "
            "float oder bool." % ", ".join(diagramm))
    erwarte(not ohne, "Ohne Type Hint (hinter der Klammer oder an einem Parameter): %s. Es läuft auch ohne; "
            "vereinbart ist es trotzdem." % ", ".join(ohne))
    erwarte(not falsch, "Dieser Type Hint passt nicht zu dem, was zurückkommt -- erwartet: %s." % ", ".join(falsch))
