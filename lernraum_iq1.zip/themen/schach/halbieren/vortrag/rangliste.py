# rangliste.py -- die Rangliste des
# Schachportals: Sie sortiert ihre
# Mitglieder nach der Wertung (Bubblesort)
# und zählt die Vergleiche.

# erlaubt die eigene Klasse als Typ:
from __future__ import annotations
from mitglied import Mitglied


class Rangliste:

    def __init__(self):
        self.__mitglieder: list[Mitglied] = []
        self.__vergleiche = 0

    def aufnehmen(self, mitglied: Mitglied) -> None:
        self.__mitglieder.append(mitglied)

    def anzahl(self) -> int:
        return len(self.__mitglieder)

    def get_mitglied(self, platz: int) -> Mitglied:
        return self.__mitglieder[platz]

    def finde_position(self, name: str) -> int:
        for platz in range(len(self.__mitglieder)):
            if self.__mitglieder[platz].get_name() == name:
                return platz
        return -1

    def durchgang(self, nummer: int) -> None:
        for platz in range(len(self.__mitglieder) - nummer):
            self.__vergleiche = self.__vergleiche + 1
            links = self.__mitglieder[platz]
            rechts = self.__mitglieder[platz + 1]
            if links.get_wertung() > rechts.get_wertung():
                self.__mitglieder[platz] = rechts
                self.__mitglieder[platz + 1] = links

    def sortiere(self) -> None:
        for nummer in range(1, len(self.__mitglieder)):
            self.durchgang(nummer)

    def get_vergleiche(self) -> int:
        return self.__vergleiche
