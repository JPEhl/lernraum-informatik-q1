# spiel.py -- das Spiel: Es hält beide
# Spieler, das Brett als Liste von Listen
# und das Zugrecht. Wer zieht, fragt das
# Spiel -- so sagen Feld und Figur dasselbe.

# erlaubt die eigene Klasse als Typ:
from __future__ import annotations
from zeichenflaeche import zeichne_bild
from figur import Figur
from spieler import Spieler
from zug import Zug

ARTEN = ["Turm", "Springer", "Läufer", "Dame",
         "König", "Läufer", "Springer", "Turm"]


class Spiel:

    def __init__(self):
        self.__weiss = Spieler("weiß")
        self.__schwarz = Spieler("schwarz")
        self.__am_zug = self.__weiss
        self.__feld: list[list[Figur]] = []
        for zeile in range(8):
            reihe: list[Figur] = []
            for spalte in range(8):
                reihe.append(None)
            self.__feld.append(reihe)
        for spalte in range(8):
            self.__stelle(Figur(ARTEN[spalte], "schwarz", 0, spalte), self.__schwarz)
            self.__stelle(Figur("Bauer", "schwarz", 1, spalte), self.__schwarz)
            self.__stelle(Figur("Bauer", "weiß", 6, spalte), self.__weiss)
            self.__stelle(Figur(ARTEN[spalte], "weiß", 7, spalte), self.__weiss)

    def __stelle(self, figur: Figur, spieler: Spieler) -> None:
        spieler.aufnehmen(figur)
        self.__feld[figur.get_zeile()][figur.get_spalte()] = figur

    def figur_auf(self, zeile: int, spalte: int) -> Figur:
        return self.__feld[zeile][spalte]

    def get_am_zug(self) -> Spieler:
        return self.__am_zug

    def ziehe(self, zug: Zug) -> bool:
        figur = zug.get_figur()
        if figur.get_farbe() != self.__am_zug.get_farbe():
            return False
        if not figur.darf(zug.get_zeile(), zug.get_spalte(), self):
            return False
        if self.__am_zug == self.__weiss:
            gegner = self.__schwarz
        else:
            gegner = self.__weiss
        opfer = self.figur_auf(zug.get_zeile(), zug.get_spalte())
        if opfer != None:
            gegner.entferne(opfer)
        self.__feld[figur.get_zeile()][figur.get_spalte()] = None
        zug.ausfuehren()
        self.__feld[zug.get_zeile()][zug.get_spalte()] = figur
        self.__am_zug = gegner
        return True

    def ist_vorbei(self) -> bool:
        return not self.__weiss.hat_koenig() or not self.__schwarz.hat_koenig()

    def materialwert(self, farbe: str) -> int:
        if farbe == "weiß":
            return self.__weiss.materialwert()
        else:
            return self.__schwarz.materialwert()

    def zeichne(self, groesse: int) -> None:
        for zeile in range(8):
            for spalte in range(8):
                figur = self.__feld[zeile][spalte]
                if figur != None:
                    zeichne_bild(figur.bildname(), spalte * groesse,
                                 zeile * groesse, groesse)
