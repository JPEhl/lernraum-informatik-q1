# tausch.py -- dieselbe Dame, zwei Baupläne
from zeichenflaeche import neue_flaeche, zeichne_bild, zeige
from figur_vortrag import Figur

FELDGROESSE = 60
flaeche = neue_flaeche(8 * FELDGROESSE, 8 * FELDGROESSE)


def zeichne_felder() -> None:
    for zeile in range(8):
        for spalte in range(8):
            x = spalte * FELDGROESSE
            y = zeile * FELDGROESSE
            if (zeile + spalte) % 2 == 0:
                farbe = "#eeeed2"
            else:
                farbe = "#769656"
            flaeche.create_rectangle(x, y, x + FELDGROESSE, y + FELDGROESSE,
                                     fill=farbe, outline=farbe)


def zeichne_figur(name: str, zeile: int, spalte: int) -> None:
    zeichne_bild(name, spalte * FELDGROESSE, zeile * FELDGROESSE, FELDGROESSE)


zeichne_felder()
dame = Figur("Dame", "weiß", 7, 3)
dame.ziehen(3, 3)
zeichne_figur("dame-w", dame.get_zeile(), dame.get_spalte())
zeige()
