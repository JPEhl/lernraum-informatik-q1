# zwei.py -- die Figur von eben, jetzt mit
# einer Methode für zwei Figuren.

# erlaubt die eigene Klasse als Typ:
from __future__ import annotations
from zeichenflaeche import neue_flaeche, zeichne_bild, zeige

FELDGROESSE = 60
flaeche = neue_flaeche(8 * FELDGROESSE, 8 * FELDGROESSE)


def zeichne_felder() -> None:
    for zeile in range(8):
        for spalte in range(8):
            x = spalte * FELDGROESSE
            y = zeile * FELDGROESSE
            if (zeile + spalte) % 2 == 0:
                farbe = "#eeeed2"
            else:
                farbe = "#769656"
            flaeche.create_rectangle(x, y, x + FELDGROESSE, y + FELDGROESSE,
                                     fill=farbe, outline=farbe)


def zeichne_figur(name: str, zeile: int, spalte: int) -> None:
    zeichne_bild(name, spalte * FELDGROESSE, zeile * FELDGROESSE, FELDGROESSE)


class Figur:

    def __init__(self, art: str, farbe: str, zeile: int, spalte: int):
        self.art = art
        self.farbe = farbe
        self.zeile = zeile
        self.spalte = spalte

    def ziehen(self, zeile: int, spalte: int) -> None:
        self.zeile = zeile
        self.spalte = spalte

    def gleiches_feld(self, andere: Figur) -> bool:
        return self.zeile == andere.zeile and self.spalte == andere.spalte


zeichne_felder()
dame = Figur("Dame", "weiß", 7, 3)
dame.ziehen(3, 3)
turm = Figur("Turm", "schwarz", 0, 0)
turm.ziehen(4, 0)
zeichne_figur("dame-w", dame.zeile, dame.spalte)
zeichne_figur("turm-s", turm.zeile, turm.spalte)
print(dame.gleiches_feld(turm))
zeige()
