# rangliste_erste.py -- Experten-
# aufgabe: die erste von mehreren
# gleichen Wertungen. Kopiert eure
# Klasse Rangliste hierher.

# erlaubt die eigene Klasse als Typ:
from __future__ import annotations
from mitglied import Mitglied
