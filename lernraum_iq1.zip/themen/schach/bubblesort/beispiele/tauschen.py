wertungen = [1480, 1215]
merke = wertungen[0]
wertungen[0] = wertungen[1]
wertungen[1] = merke
print(wertungen)
