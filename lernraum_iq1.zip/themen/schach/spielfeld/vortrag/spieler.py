# spieler.py -- ein Spieler und seine
# Figuren: Er nimmt sie auf, zeichnet sie,
# kennt ihren Wert, findet und entfernt
# sie -- und weiß, ob sein König steht.

# erlaubt die eigene Klasse als Typ:
from __future__ import annotations
from zeichenflaeche import zeichne_bild
from figur import Figur


class Spieler:

    def __init__(self, farbe: str):
        self.__farbe = farbe
        self.__figuren: list[Figur] = []

    def get_farbe(self) -> str:
        return self.__farbe

    def aufnehmen(self, figur: Figur) -> None:
        self.__figuren.append(figur)

    def anzahl(self) -> int:
        return len(self.__figuren)

    def zeichne_alle(self, groesse: int) -> None:
        for figur in self.__figuren:
            x = figur.get_spalte() * groesse
            y = figur.get_zeile() * groesse
            zeichne_bild(figur.bildname(), x, y, groesse)

    def materialwert(self) -> int:
        summe = 0
        for figur in self.__figuren:
            summe = summe + figur.get_wert()
        return summe

    def finde_figur(self, zeile: int, spalte: int) -> Figur:
        for figur in self.__figuren:
            if figur.get_zeile() == zeile and figur.get_spalte() == spalte:
                return figur
        return None

    def entferne(self, figur: Figur) -> None:
        self.__figuren.remove(figur)

    def hat_koenig(self) -> bool:
        for figur in self.__figuren:
            if figur.get_art() == "König":
                return True
        return False
