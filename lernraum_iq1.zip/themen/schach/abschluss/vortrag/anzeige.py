# anzeige.py -- gegeben: das Fenster des
# Schachportals. Es zeichnet die Rangliste
# und meldet, welche Zeile angeklickt wurde.
# Lesen dürft ihr, ändern nicht.

import tkinter as tk

BREITE = 380
KOPF = 34
ZEILE = 22
fenster = None
flaeche = None


def neue_anzeige(zeilen: int) -> None:
    """Öffnet das Fenster: eine Kopfzeile und Platz für zeilen Zeilen."""
    global fenster, flaeche
    fenster = tk.Tk()
    fenster.title("Schachportal")
    fenster.resizable(False, False)
    flaeche = tk.Canvas(fenster, width=BREITE, height=KOPF + zeilen * ZEILE,
                        bg="white", highlightthickness=0)
    flaeche.pack()


def zeichne_rangliste(rangliste, fest: int = 0, markiert: int = -1) -> None:
    """Zeichnet die Liste neu: je Mitglied eine Zeile mit Index (grau),
    Name und Wertung. Die letzten fest Zeilen sind grün (sie liegen
    fest), die Zeile markiert ist blau (-1: keine)."""
    flaeche.delete("all")
    flaeche.create_rectangle(0, 0, BREITE, KOPF, fill="#244f9a", outline="#244f9a")
    flaeche.create_text(14, KOPF // 2, text="Mitglieder des Portals", anchor="w",
                        font=("Arial", 14, "bold"), fill="white")
    anzahl = rangliste.anzahl()
    if fest >= anzahl - 1:
        fest = anzahl
    for platz in range(anzahl):
        mitglied = rangliste.get_mitglied(platz)
        oben = KOPF + platz * ZEILE
        if platz == markiert:
            farbe = "#cfe0fa"
        elif platz >= anzahl - fest:
            farbe = "#e3f5ec"
        elif platz % 2 == 0:
            farbe = "#ffffff"
        else:
            farbe = "#f6f4ef"
        flaeche.create_rectangle(0, oben, BREITE, oben + ZEILE, fill=farbe, outline=farbe)
        mitte = oben + ZEILE // 2
        flaeche.create_text(40, mitte, text=str(platz), anchor="e",
                            font=("Arial", 11), fill="#8a857c")
        flaeche.create_text(60, mitte, text=mitglied.get_name(), anchor="w",
                            font=("Arial", 13), fill="black")
        flaeche.create_text(BREITE - 16, mitte, text=str(mitglied.get_wertung()), anchor="e",
                            font=("Arial", 13, "bold"), fill="black")


def bei_klick(funktion) -> None:
    """Ruft ab jetzt bei jedem Klick funktion(zeile) auf: zeile ist die
    Nummer der angeklickten Zeile, ab 0 gezählt -- und -1 für die
    Kopfzeile."""
    def weitergeben(ereignis) -> None:
        if ereignis.y < KOPF:
            funktion(-1)
        else:
            funktion((ereignis.y - KOPF) // ZEILE)
    flaeche.bind("<Button-1>", weitergeben)


def zeige() -> None:
    """Zeigt das Fenster, bis es jemand schließt."""
    fenster.mainloop()
