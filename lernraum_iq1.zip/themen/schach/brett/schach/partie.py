# partie.py -- das Schachbrett.
# Hier arbeitet ihr. Gegeben ist
# zeichenflaeche.py: das Fenster, die
# Bilder der Figuren und der Klick.

from zeichenflaeche import neue_flaeche, zeichne_bild, bei_klick, zeige

FELDGROESSE = 70
HELL = "#f0d9b5"
DUNKEL = "#b58863"

flaeche = neue_flaeche(8 * FELDGROESSE, 8 * FELDGROESSE)


# ------------------------ das Brett

def zeichne_felder() -> None:
    for zeile in range(8):
        for spalte in range(8):
            x = spalte * FELDGROESSE
            y = zeile * FELDGROESSE
            if (zeile + spalte) % 2 == 0:
                farbe = HELL
            else:
                farbe = DUNKEL
            flaeche.create_rectangle(x, y, x + FELDGROESSE, y + FELDGROESSE,
                                     fill=farbe, outline=farbe)


def zeichne_figur(name: str, zeile: int, spalte: int) -> None:
    zeichne_bild(name, spalte * FELDGROESSE, zeile * FELDGROESSE, FELDGROESSE)


# ------------------------ die Aufstellung

def zeichne_alles() -> None:
    flaeche.delete("all")
    zeichne_felder()
    zeichne_figur("turm-s", 0, 0)
    zeichne_figur("springer-s", 0, 1)
    zeichne_figur("laeufer-s", 0, 2)
    zeichne_figur("dame-s", 0, 3)
    zeichne_figur("koenig-s", 0, 4)
    zeichne_figur("laeufer-s", 0, 5)
    zeichne_figur("springer-s", 0, 6)
    zeichne_figur("turm-s", 0, 7)
    for spalte in range(8):
        zeichne_figur("bauer-s", 1, spalte)
    for spalte in range(8):
        zeichne_figur("bauer-w", 6, spalte)
    zeichne_figur("turm-w", 7, 0)
    zeichne_figur("springer-w", 7, 1)
    zeichne_figur("laeufer-w", 7, 2)
    zeichne_figur("dame-w", 7, 3)
    zeichne_figur("koenig-w", 7, 4)
    zeichne_figur("laeufer-w", 7, 5)
    zeichne_figur("springer-w", 7, 6)
    zeichne_figur("turm-w", 7, 7)


# ------------------------ der Klick

def klick(x: int, y: int) -> None:
    print("Klick bei", x, y)


zeichne_alles()
bei_klick(klick)
zeige()
