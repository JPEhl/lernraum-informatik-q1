/* Lernraum · kopf.js -- Kopfleiste, Dialoge, Stand-Menü, Schriftgröße der Editoren.
   Teil der Arbeitsseite; alle Teile teilen einen Namensraum und laden in der
   Reihenfolge von index.html (kein Bündler, CSP 'self'). */
"use strict";
// ─── Kopf ──────────────────────────────────────────────────────────────────────
function kopfZeichnen(weg) {
  const w = $("#kopf-weg"); w.textContent = "";
  // Pult mit mehreren Kursen: der Kurs steht immer im Titel (auch am Beamer);
  // der Wechsel-Knopf nur bei Beamer aus (Lehrerentscheidung 14.10.).
  // Kurs wechseln (12.11.2026, Lehrer: „Die Kursauswahl oben links hätte ich lieber als Dropdown-Menü“ -- und dann:
  // „nicht schön … sollte sich mehr ins Design einbetten“): ein Knopf wie die rechts, darunter eine Karte mit den
  // Kursen. Er steht neben dem Titel, nicht in #kopf-weg -- der schneidet ab (overflow, eine Zeile).
  document.querySelector("#kopf > .kurs-menue")?.remove();
  if (Z.lehrer && Z.kurse.length > 1) {
    const menue = h("details", { class: "kurs-menue nur-ohne-beamer" },
      h("summary", { class: "kurs-knopf", title: "Kurs wechseln -- nur bei Beamer aus" }, "Kurs", h("span", { class: "kurs-pfeil" }, "▾")),
      h("div", { class: "kurs-liste" }, Z.kurse.map(e => h("button", { type: "button", class: "kurs-wahl" + (e.kurs === Z.kurs ? " aktiv" : ""),
        onclick: async () => { menue.open = false; if (e.kurs !== Z.kurs) await kursWechseln(e.kurs, ""); } },
        h("b", {}, e.titel), e.untertitel ? h("span", {}, e.untertitel) : null))));
    $("#kopf-titel").after(menue);
  }
  // Im Pult nur das letzte Glied (die Kopfleiste trägt dort zwei Gruppen; Galerie-Karte 15.10.)
  for (const [text, href] of (Z.lehrer ? (weg || []).slice(-1) : weg || [])) { w.append(h("span", {}, "›"), href ? h("a", { href }, text) : h("span", {}, text)); }
  const r = $("#kopf-rechts"); r.textContent = "";
  if (Z.lehrer) {
    // Zwei Gruppen (Galerie 15.10., Rang 2): was im Raum gebraucht wird, und was nur am
    // Schreibtisch -- die zweite verschwindet am Beamer als Ganzes.
    r.append(h("span", { class: "kopf-gruppe" }, h("i", {}, "Unterricht"),
      h("button", { class: Z.beamer ? "beamer-an" : "", onclick: beamerSchalten, title: "Beamer EIN: Übersicht und Namen sind unerreichbar" }, Z.beamer ? "Beamer EIN" : "Beamer aus"),
      h("button", { class: A.haengestellen ? "beamer-an" : "", onclick: haengestellenSchalten, title: "Wo die Klasse Anmerkungen gesetzt hat -- aus den Abgaben in der Übersicht, ohne Namen" }, "Hängestellen"),
      h("a", { href: adr("besprechung"), class: "knopf" }, "Besprechung")));
    r.append(h("span", { class: "kopf-gruppe nur-ohne-beamer" }, h("i", {}, "Vorbereitung"),
      h("button", { class: D.an ? "beamer-an" : "", onclick: durchsichtSchalten, title: "Nadeln und Urteile auf der Seite setzen (Datei _durchsicht/durchsicht.json)" }, D.an ? "Durchsicht EIN" : "Durchsicht"),
      h("a", { href: adr("uebersicht"), class: "knopf" }, "Übersicht"),
      h("a", { href: adr("schuljahr"), class: "knopf", title: "Jahresübersicht: je Person und Thema, was du aus der Übersicht übernommen hast" }, "Schuljahr")));
  } else {
    if (themaRoute()) r.append(h("button", { class: "anmerkung-knopf" + (A.modus ? " beamer-an" : ""), onclick: anmerkungModusSchalten, title: "Taste N: eine Nadel an eine Stelle setzen -- verstehe ich nicht · Fehler · Idee" }, A.modus ? "… jetzt auf die Stelle klicken" : [zeichen(NADEL_ZEICHEN, "z-nadel"), "Anmerkung"]));
    r.append(h("span", { class: "name-anzeige nur-ohne-beamer" }, Z.stand.name || "kein Name"));
    // Mehr Platz (Lehrer 16.11.2026: „die sehr große Menubar verstecken … damit die Folien/Erklärung/Übungen den
    // gesamten Platz des Bildschirms nutzen können“): Kopfleiste und Titelzeile klappen ein, die Reiter werden eine
    // schmale Zeile; oben rechts bleibt ein kleiner Knopf, der sie zurückholt. Gemerkt je Browser, nur in Themen.
    if (themaRoute()) r.append(h("button", { class: "platz-knopf", onclick: () => kopfEinklappen(true), title: "Großansicht: Kopfleiste einklappen, mehr Platz für Folien, Erklärung und Übung" }, "⤢ Großansicht"));
  }
  kopfPlatzAnwenden();
  // Im Pult gehoeren Name und Staende nicht hierher (Lehrer 17.10.); der Stundenplan, der dort stand,
  // ist mit dem Lesezeichen entfallen (19.10.) -- das Pult hat kein Zahnrad mehr
  if (!Z.lehrer) r.append(h("button", { class: "zahnrad", onclick: standMenue, title: "Name, Stand mitnehmen, Stand hereinnehmen", "aria-label": "Mein Stand" }, zeichen(ZAHNRAD_ZEICHEN, "z-zahnrad")));
  // Beenden (Lehrer 25.10.): sichert den Stand und stoppt start.py -- statt nur das Fenster zu schließen
  if (!Z.lehrer) r.append(h("button", { class: "beenden-knopf", onclick: lernraumBeenden, title: "Lernraum beenden: sichert deinen Stand und stoppt start.py" }, "Beenden"));
}
// Mehr Platz in der Schülerfassung: body.kopf-zu (seite.css) -- nur in Themen, im Pult nie (dort gibt es den Beamer)
function kopfPlatzGemerkt() { try { return localStorage.getItem("lernraum.kopfzu") === "1"; } catch (e) { return false; } }
function kopfPlatzAnwenden() {
  document.body.classList.toggle("kopf-zu", !Z.lehrer && !!themaRoute() && kopfPlatzGemerkt());
  if (!$("#kopf-auf")) document.body.append(h("button", { id: "kopf-auf", onclick: () => kopfEinklappen(false), title: "Großansicht beenden: die Kopfleiste wieder zeigen", "aria-label": "Großansicht beenden" }, "✕ Großansicht beenden"));
}
function kopfEinklappen(zu) { try { localStorage.setItem("lernraum.kopfzu", zu ? "1" : "0"); } catch (e) {} kopfPlatzAnwenden(); }
async function beamerSchalten() {
  const a = await api("beamer", { an: !Z.beamer });
  Z.beamer = a.beamer; document.body.classList.toggle("beamer", Z.beamer);
  if (Z.beamer && routeOhneKurs().startsWith("uebersicht")) location.hash = adr("");
  else zeichnen();
}

// Der Knopf „Beenden“: erst warten, bis der Editor gespeichert hat (er speichert 1,2 s nach dem letzten
// Tippen), dann sichert der Server „beim Beenden“ und stoppt sich; die Seite sagt, dass der Stick jetzt raus darf.
function lernraumBeenden() {
  dialog("Lernraum beenden?", h("p", {}, "Dein Stand wird gesichert, dann stoppt start.py. Weiter geht es wieder mit start.py in Thonny."), [
    ["Beenden", async () => {
      await schlafen(1500);
      let a = { gesichert: false };
      try { a = await api("beenden", {}); } catch (e) { /* der Server ist schon weg -- gespeichert war schon alles */ }
      document.title = "Lernraum beendet";
      $("#kopf-rechts").textContent = ""; $("#kopf-weg").textContent = "";
      const haupt = $("#haupt"); haupt.textContent = "";
      haupt.append(h("div", { class: "seite beendet" }, h("h1", {}, "Bis zum nächsten Mal"),
        h("p", { class: "unter" }, "Der Lernraum ist beendet" + (a.gesichert ? " und dein Stand gesichert." : " – dein Stand ist gespeichert.")),
        h("div", { class: "hinweis" }, h("p", {}, "Du kannst dieses Fenster jetzt schließen – und erst jetzt den USB-Stick abziehen."),
          h("p", {}, "Weiter geht es wieder mit ", h("code", {}, "start.py"), " in Thonny (grüner Pfeil)."))));
    }, "primaer"],
    ["Weiterarbeiten", () => {}, "ruhig"]]);
}
// ─── Dialoge ───────────────────────────────────────────────────────────────────
function dialog(titel, inhalt, knoepfe) {
  // Nie zwei Fenster übereinander (Lehrer 16.11.2026: „Wenn man im Einstellungsfenster Enter drückt, lässt sich das
  // Fenster nicht mehr schließen“): Der Fokus blieb auf dem Knopf, der das Fenster geöffnet hatte -- jedes Enter
  // öffnete ein weiteres darüber, „Schließen“ nahm nur das oberste weg. Jetzt: ein offenes Fenster bleibt das eine,
  // der Fokus geht ins Fenster, und Enter in einem Textfeld drückt den Hauptknopf.
  const schon = $("#dialoge .dialog-hintergrund");
  if (schon) return schon;
  if (document.activeElement && document.activeElement.blur) document.activeElement.blur();
  const hinter = h("div", { class: "dialog-hintergrund" });
  const box = h("div", { class: "dialog", tabindex: "-1", role: "dialog", "aria-modal": "true", "aria-label": titel }, h("h2", {}, titel), inhalt, h("div", { class: "knoepfe" }, knoepfe.map(([t, f, cls]) => h("button", { class: cls || "", onclick: async () => { if (await f() !== false) hinter.remove(); } }, t))));
  box.addEventListener("keydown", ev => {
    if (ev.key !== "Enter" || ev.target.tagName !== "INPUT" || ev.target.type === "file") return;
    const haupt = box.querySelector(".knoepfe button.primaer") || box.querySelector(".knoepfe button");
    if (haupt) { ev.preventDefault(); haupt.click(); }
  });
  hinter.append(box); $("#dialoge").append(hinter);
  box.focus();
  return hinter;
}
function standMenue() {
  const vor = h("input", { value: Z.stand.vorname || "" }), nach = h("input", { value: Z.stand.nachname || "" });
  const datei = h("input", { type: "file", accept: ".zip" });
  const bericht = h("div", {});
  const inhalt = h("div", {},
    h("p", {}, "Dein Name steht nur hier in deinem Lernraum und in deiner Abgabe – nirgends sonst."),
    h("div", { class: "zeile" }, h("label", {}, "Vorname"), vor),
    h("div", { class: "zeile" }, h("label", {}, "Nachname"), nach),
    Z.lehrer ? null : speicherstaendeTeil(),
    h("h3", {}, "Stand mitnehmen"),
    h("p", {}, "Eine kleine ZIP mit deinem Stand und deinen Programmen – zum Mailen, wenn der Stick nicht da ist. ",
      h("button", { onclick: async () => { const a = await api("stand/zip", {}); bericht.textContent = ""; bericht.append(h("p", {}, "Gespeichert: ", h("a", { href: "/" + a.datei, download: true }, a.datei), " (" + Math.round(a.groesse / 1024) + " KB) – liegt in ", h("code", {}, a.pfad))); } }, "Stand mitnehmen")),
    h("h3", {}, "Stand hereinnehmen"),
    h("p", {}, "Eine mitgebrachte Stand-ZIP wird zusammengeführt: Neuerer Code gewinnt, Hilfen und Kennwörter werden vereinigt, Konflikte werden gezeigt."),
    h("div", { class: "zeile" }, datei, h("button", { onclick: async () => {
      const f = datei.files[0]; if (!f) return;
      const b64 = await dateiB64(f);
      try { const a = await api("stand/zusammenfuehren", { daten: b64 }); Z.stand = a.stand; bericht.textContent = ""; bericht.append(berichtZeichnen(a.bericht)); }
      catch (e) {
        // Eine neue Fassung statt eines Stands (16.11.2026): weiter zur Kursseite, dort wird sie geprüft und eingespielt
        if (e.daten && e.daten.ist_fassung) { window.fassungVonHand = f; const d = $("#dialoge .dialog-hintergrund"); if (d) d.remove(); if (location.hash !== adr("")) location.hash = adr(""); else zeichnen(); return; }
        bericht.textContent = e.message; bericht.className = "fehler"; }
    } }, "Zusammenführen")),
    bericht);
  dialog("Mein Stand", inhalt, [["Schließen", async () => { const a = await api("stand/name", { vorname: vor.value, nachname: nach.value }); Z.stand = a.stand; kopfZeichnen(Z.weg); if (location.hash.includes("/uebung")) zeichnen(); }, "primaer"]]);
}
// Speicherstände (Lehrerwunsch 16.10.): bei jedem Start eine Sicherung, dazu von Hand; zurück
// ERSETZT Stand und Programme (vorher wird der jetzige Stand gesichert -- auch das lässt sich zurücknehmen).
function speicherstaendeTeil() {
  const liste = h("div", { class: "sicherungen" }, h("p", { class: "leer" }, "Wird geladen …"));
  const notiz = h("input", { placeholder: "wofür? (freiwillig)", maxlength: "80" });
  const meld = h("p", {});
  const zeitText = z => { const m = (z || "").match(/^\d{4}-(\d\d)-(\d\d)T(\d\d:\d\d)/); return m ? m[2] + "." + m[1] + "., " + m[3] : z; };
  function zeigen(alle) {
    liste.textContent = "";
    if (!alle.length) { liste.append(h("p", { class: "leer" }, "Noch keine Sicherung.")); return; }
    for (const s of alle.slice(0, 12)) liste.append(h("div", { class: "sicherung" },
      h("span", { class: "si-zeit" }, zeitText(s.zeit)), h("span", { class: "si-art" }, s.wie + (s.notiz ? " · " + s.notiz : "")),
      h("button", { class: "ruhig", onclick: () => zurueck(s) }, "zurück zu diesem Stand")));
  }
  async function zurueck(s) {
    if (!confirm("Zurück zum Stand vom " + zeitText(s.zeit) + "?\n\nDeine Programme und dein Stand werden ersetzt. Der jetzige Stand wird vorher gesichert – du kannst also auch wieder zurück.")) return;
    meld.className = "laden"; meld.textContent = "Wird zurückgeholt …";
    await schlafen(1500);      // was der Editor noch speichern wollte, ist jetzt gespeichert -- und wird gleich mitgesichert
    try { await api("sicherung/zurueck", { name: s.name }); location.reload(); }
    catch (e) { meld.className = "fehler"; meld.textContent = e.message; }
  }
  api("sicherung/liste", {}).then(r => zeigen(r.sicherungen)).catch(e => { liste.textContent = e.message; });
  return h("div", {},
    h("h3", {}, "Speicherstände"),
    h("p", {}, "Beim Start und beim Beenden legt der Lernraum eine Sicherung an. Vor etwas Großem kannst du selbst einen Speicherstand anlegen – und später dorthin zurück."),
    h("div", { class: "zeile" }, notiz, h("button", { onclick: async () => {
      try { const r = await api("sicherung/anlegen", { notiz: notiz.value }); notiz.value = ""; meld.className = "ok"; meld.textContent = "Gesichert."; zeigen(r.sicherungen); }
      catch (e) { meld.className = "fehler"; meld.textContent = e.message; } } }, "Speicherstand anlegen")),
    meld, liste);
}
function berichtZeichnen(b) {
  const ul = h("ul", {});
  ul.append(h("li", {}, (b.uebernommen || []).length + " übernommen, " + (b.behalten || []).length + " behalten, " + b.kennwoerter + " Kennwort/Kennwörter dazu."));
  for (const k of b.konflikte || []) ul.append(h("li", { class: "fehler" }, "Konflikt bei " + k.datei + ": " + (k.gewinner === "hier" ? "deine Fassung bleibt" : "die mitgebrachte gilt") + ", die andere liegt als " + k.verlierer + "."));
  for (const k of b.ignoriert || []) ul.append(h("li", { class: "leer" }, "nicht übernommen (keine Arbeitsdatei): " + k));
  return ul;
}
function dateiB64(f) { return new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result.split(",")[1]); r.onerror = rej; r.readAsDataURL(f); }); }

// Schriftgroesse der Editoren und der Shell: Stufen, je eigene, gemerkt im Browser (Lehrer 13.10.:
// Schriftgroesse anpassbar; 22.10.: „neben dem Code auch die Schriftgröße der Shell anpassen“).
const SCHRIFT_STUFEN = [0.8, 0.9, 1, 1.15, 1.3, 1.5, 1.75];
// 24.10.: dazu die Variablen des Debuggers (Lehrer: „Code und Debugger Größe einstellen … je nach Auflösung des Beamers“)
// 26.10.: dazu die Folie (Probelauf S6: „von hinten die kleine Schrift nicht lesen“) -- sie wächst als Ganzes (zoom)
const SCHRIFT_ARTEN = { code: { schluessel: "lernraum.schrift", variable: "--editor-schrift" }, shell: { schluessel: "lernraum.schrift.shell", variable: "--shell-schrift" },
  debugger: { schluessel: "lernraum.schrift.debugger", variable: "--debugger-schrift" }, folie: { schluessel: "lernraum.schrift.folie", variable: "--folie-schrift" },
  // 29.10. (router W2): Befehlszeile und Datenaustausch der Werkstatt im Vortrag -- der Plan waechst mit der Spaltenbreite
  werkstatt: { schluessel: "lernraum.schrift.werkstatt", variable: "--werkstatt-schrift" } };
function schriftStufe(art) { const a = SCHRIFT_ARTEN[art || "code"]; try { const s = parseInt(localStorage.getItem(a.schluessel) || "2", 10); return isNaN(s) ? 2 : Math.max(0, Math.min(SCHRIFT_STUFEN.length - 1, s)); } catch (e) { return 2; } }
function schriftAnwenden() { for (const art in SCHRIFT_ARTEN) document.documentElement.style.setProperty(SCHRIFT_ARTEN[art].variable, String(SCHRIFT_STUFEN[schriftStufe(art)])); }
function schriftAendern(d, art) { try { localStorage.setItem(SCHRIFT_ARTEN[art || "code"].schluessel, String(Math.max(0, Math.min(SCHRIFT_STUFEN.length - 1, schriftStufe(art) + d)))); } catch (e) {} schriftAnwenden(); }
schriftAnwenden();
