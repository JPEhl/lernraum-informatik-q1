wertungen = [1048, 1105, 1163, 1215, 1290, 1342, 1418]
links = 4
rechts = 6
mitte = (links + rechts) // 2
print(mitte, wertungen[mitte])
