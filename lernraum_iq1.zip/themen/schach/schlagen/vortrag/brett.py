# brett.py -- gegeben: ein kleines Brett für
# die Beispiele im Vortrag. Lesen dürft ihr,
# ändern nicht.

from zeichenflaeche import neue_flaeche, zeige
from zug import Zug

FELDGROESSE = 60
flaeche = neue_flaeche(8 * FELDGROESSE, 8 * FELDGROESSE)


def zeichne_felder() -> None:
    for zeile in range(8):
        for spalte in range(8):
            x = spalte * FELDGROESSE
            y = zeile * FELDGROESSE
            if (zeile + spalte) % 2 == 0:
                farbe = "#eeeed2"
            else:
                farbe = "#769656"
            flaeche.create_rectangle(x, y, x + FELDGROESSE, y + FELDGROESSE,
                                     fill=farbe, outline=farbe)


def hebe_hervor(zeile: int, spalte: int) -> None:
    x = spalte * FELDGROESSE
    y = zeile * FELDGROESSE
    flaeche.create_rectangle(x, y, x + FELDGROESSE, y + FELDGROESSE,
                             outline="red", width=4)


def zeichne_pfeil(zug: Zug) -> None:
    mitte = FELDGROESSE // 2
    x1 = zug.get_figur().get_spalte() * FELDGROESSE + mitte
    y1 = zug.get_figur().get_zeile() * FELDGROESSE + mitte
    x2 = zug.get_spalte() * FELDGROESSE + mitte
    y2 = zug.get_zeile() * FELDGROESSE + mitte
    flaeche.create_line(x1, y1, x2, y2, fill="#1565c0", width=6,
                        arrow="last", arrowshape=(18, 22, 7))
