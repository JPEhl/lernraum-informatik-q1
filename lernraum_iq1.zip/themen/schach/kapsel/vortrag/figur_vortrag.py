# figur_vortrag.py -- die Figur aus dame.py,
# wie sie im Vortrag entstanden ist.

# erlaubt die eigene Klasse als Typ:
from __future__ import annotations


class Figur:

    def __init__(self, art: str, farbe: str, zeile: int, spalte: int):
        self.art = art
        self.farbe = farbe
        self.__zeile = zeile
        self.__spalte = spalte

    def ziehen(self, zeile: int, spalte: int) -> None:
        self.__zeile = zeile
        self.__spalte = spalte

    def set_zeile(self, zeile: int) -> None:
        if zeile >= 0 and zeile <= 7:
            self.__zeile = zeile

    def get_zeile(self) -> int:
        return self.__zeile

    def get_spalte(self) -> int:
        return self.__spalte
