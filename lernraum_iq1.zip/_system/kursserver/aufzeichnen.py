"""Aufzeichnung: ein Programm laeuft einmal, und jeder Schritt wird notiert --
Zeile, Werte der Variablen, Objekte. Danach kann man auf der Seite vor- und
zurueckgehen (Python-Tutor-Art, ohne fremden Server).

Laeuft als EIGENER Unterprozess:
    python -u aufzeichnen.py <datei>
und schreibt JSON-Zeilen nach stdout -- eine je Ablauf-Ereignis --, die der
Server einsammelt. Ausgaben des Programms (print) landen im selben Strom als
{"art": "ausgabe"}.

tkinter: Vom Programmstart bis mainloop() ist der erste Ablauf. Danach ist
JEDER Aufruf eines Callbacks aus der Ereignisschleife ein eigener Ablauf
("Klick: hoch"). Machbarkeit am 2026-10-12 belegt (Probe im Scratchpad,
danach hier): Der Trace-Haken der Thread bleibt gesetzt, wenn Tcl zurueck
in Python ruft; ein Frame aus der Arbeitsdatei, dessen Vater NICHT aus der
Arbeitsdatei ist, beginnt waehrend mainloop einen neuen Ablauf.

Grenze: GRENZE Schritte insgesamt (Endlosschleife) -> Hinweis, Abbruch.

Python-Ordner (11.11.2026, Ordnung Informatik Schritt 9 Teil 4, fuer iq1 schach):
Setzt der Server LERNRAUM_ORDNER = {"gegeben": ["brett.py", ...]}, gehoert jede
.py im Ordner des Programms zur Arbeit der Klasse, ausser den gegebenen. Schritte
gibt es in JEDER Datei der Klasse (der Schritt sagt "datei"); ein gegebenes Modul
bleibt ein Schritt (LT9), ruft es aber in eine Datei der Klasse zurueck (brett.zeichne
-> figur.get_spalte), wird dort wieder aufgezeichnet. Der Stapel geht durch gegebene
Module und den Import hindurch, damit "Schritt ueber" ueber eine solche Zeile hinweg
geht. Die Variablen des Programms sind immer die der Startdatei.
Ohne LERNRAUM_ORDNER (eine Arbeitsdatei, der Vortrag): nur die Startdatei, wie vorher.

Attribute (11.11.2026): benannt wie im Code (`__zeile`, nicht `_Figur__zeile`) --
mit DERSELBEN Funktion wie im Selbstcheck (pruefen.attribute). Bis dahin liess der
Debugger jedes Attribut mit `_` weg, ein Objekt mit `__zeile` war ein leerer Kasten.
"""
import __future__
import json
import runpy
import sys
import traceback
import types

GRENZE = 5000
KUERZE = 60
TIEFE = 2

_DATEI = None
_ablauf_nr = 0
_schritte = 0
_im_mainloop = False
_gestoppt = False
_ausgabe_puffer = []
_objekte_sicht = {}
_ORDNER = None          # Python-Ordner: der Ordner des Programms (normiert); None = nur die Startdatei
_GEGEBEN = set()        # Python-Ordner: die gegebenen Module (Dateinamen)
_ARTEN = {}             # co_filename -> "eigen" | "durch" (gegebenes Modul, Import) | None
_HAUPT_GLOBALS = None   # die Variablen des Programms (die Startdatei), sobald ihr erster Schritt kommt
_attribute = None       # pruefen.attribute -- dieselbe Umbenennung wie im Selbstcheck


def _norm(pfad):
    import os
    return os.path.normcase(os.path.abspath(pfad))


def _art(dateiname):
    """Wie der Debugger einen Rahmen dieser Datei behandelt -- je Dateiname einmal ausgerechnet (der Haken laeuft fuer
    jeden Aufruf im ganzen Prozess, auch in der Standardbibliothek)."""
    art = _ARTEN.get(dateiname, 0)
    if art != 0:
        return art
    import os
    if _ORDNER is None:
        art = "eigen" if dateiname == _DATEI else None
    elif dateiname.startswith("<frozen importlib"):
        art = "durch"
    else:
        voll = _norm(dateiname)
        if os.path.dirname(voll) != _ORDNER or not voll.endswith(".py"):
            art = None
        elif os.path.basename(voll) in _GEGEBEN:
            art = "durch"
        else:
            art = "eigen"
    _ARTEN[dateiname] = art
    return art


def _eigen(frame):
    return _art(frame.f_code.co_filename) == "eigen"


def _kette(frame):
    """Die Rahmen der Klasse, die zu diesem Ablauf gehoeren: rueckwaerts, durch gegebene Module und den Import hindurch,
    bis zum ersten fremden Rahmen (runpy, tkinter -- dort beginnt ein Klick einen neuen Ablauf)."""
    kette = []
    f = frame
    while f is not None:
        art = _art(f.f_code.co_filename)
        if art is None:
            break
        if art == "eigen":
            kette.append(f)
        f = f.f_back
    return kette


def _senden(**d):
    sys.__stdout__.write(json.dumps(d, ensure_ascii=False) + "\n")
    sys.__stdout__.flush()


class _Ausgabe:
    """print() des Programms faengt hier -- als Ereignis in der Aufzeichnung,
    damit die Seite sagen kann, bei welchem Schritt was gedruckt wurde."""
    def write(self, s):
        if s:
            _senden(art="ausgabe", text=s, ablauf=_ablauf_nr, schritt=_schritte)

    def flush(self):
        pass


def _wert(v, tiefe=0, objekte=None):
    """Einfache Werte als Text, zusammengesetzte als Verweis auf ein Objekt
    (nach id), damit zwei Namen auf dieselbe Liste als EIN Kasten erscheinen."""
    if v is None or isinstance(v, (bool, int, float)):
        return {"art": "wert", "text": repr(v)}
    if isinstance(v, str):
        t = repr(v)
        return {"art": "wert", "text": t if len(t) <= KUERZE else t[:KUERZE] + "…'"}
    if isinstance(v, (types.ModuleType, types.FunctionType, types.BuiltinFunctionType, type)):
        name = getattr(v, "__name__", "?")
        art = {types.ModuleType: "Modul", types.FunctionType: "Funktion",
               types.BuiltinFunctionType: "Funktion"}.get(type(v), "Klasse")
        return {"art": "wert", "text": art + " " + name}
    if objekte is None:
        return {"art": "wert", "text": repr(v)[:KUERZE]}
    # ein Objekt von tkinter (Zeichenflaeche, Fenster, Bild) hat nichts zu zeigen -- sein Kasten stand als
    # „<tkinter.Canvas object .!canvas>“ vor den Objekten der Klasse (Durchsicht iq1 kapsel, W4, 14.11.2026)
    if type(v).__module__.startswith("tkinter"):
        return {"art": "wert", "text": type(v).__name__}
    oid = id(v)
    if oid not in objekte:
        objekte[oid] = {"typ": type(v).__name__}
        if tiefe <= TIEFE:
            if isinstance(v, (list, tuple, set, frozenset)):
                objekte[oid]["inhalt"] = [_wert(x, tiefe + 1, objekte) for x in list(v)[:50]]
                if len(v) > 50:
                    objekte[oid]["mehr"] = len(v) - 50
            elif isinstance(v, dict):
                objekte[oid]["inhalt"] = [[_wert(k, tiefe + 1, objekte), _wert(x, tiefe + 1, objekte)]
                                          for k, x in list(v.items())[:50]]
            elif hasattr(v, "__dict__") and not type(v).__module__.startswith("tkinter"):
                # benannt wie im Code, auch privat (11.11.2026) -- ein Objekt eines gegebenen Moduls ebenso
                try:
                    attr = list(_attribute(v).items())[:30]
                except Exception:  # noqa: BLE001 -- ein seltsames Objekt wird Text, kein Abbruch der Aufzeichnung
                    attr = None
                if attr is None:
                    objekte[oid]["text"] = repr(v)[:KUERZE]
                else:
                    objekte[oid]["inhalt"] = [[{"art": "wert", "text": k}, _wert(x, tiefe + 1, objekte)] for k, x in attr]
            else:
                objekte[oid]["text"] = repr(v)[:KUERZE]
        else:
            objekte[oid]["text"] = "…"
    return {"art": "ref", "id": str(oid)}


def _variablen(namensraum, objekte):
    # ohne `annotations`: die vorgegebene Zeile `from __future__ import annotations` (iq1, Typ der eigenen Klasse)
    # legt es als Variable an -- es stand im Debugger ganz oben (Durchsicht iq1 kapsel, W4, 14.11.2026)
    return {k: _wert(v, 0, objekte) for k, v in namensraum.items()
            if not k.startswith("__") and not isinstance(v, (types.ModuleType, __future__._Feature))}


def _rahmen(frame, objekte):
    """(Variablen des Programms, lokale Variablen). Im Python-Ordner sind die Variablen des Programms immer die der
    Startdatei -- auch in einer Methode in figur.py; der Import eines Moduls der Klasse zeigt dessen Namen als lokal."""
    global _HAUPT_GLOBALS
    zuhause = frame.f_code.co_filename == _DATEI or _ORDNER is None
    if zuhause and _HAUPT_GLOBALS is None:
        _HAUPT_GLOBALS = frame.f_globals
    glob = _variablen(frame.f_globals if zuhause or _HAUPT_GLOBALS is None else _HAUPT_GLOBALS, objekte)
    lok = {}
    if frame.f_code.co_name != "<module>":
        for k, v in frame.f_locals.items():
            if not k.startswith("__"):
                lok[k] = _wert(v, 0, objekte)
    elif not zuhause:
        lok = _variablen(frame.f_globals, objekte)
    return glob, lok


def _stapel(frame):
    return [f.f_code.co_name for f in reversed(_kette(frame))]


def _trace(frame, ereignis, arg):
    global _ablauf_nr, _schritte, _gestoppt
    if _gestoppt or not _eigen(frame):
        return None
    if _im_mainloop and ereignis == "call" and len(_kette(frame)) == 1:
        _ablauf_nr += 1
        _senden(art="ablauf", nr=_ablauf_nr, name="Klick: " + frame.f_code.co_name + "()")
    if ereignis in ("line", "call", "return", "exception"):
        _schritte += 1
        if _schritte > GRENZE:
            _gestoppt = True
            _senden(art="grenze", schritte=GRENZE,
                    text="Nach %d Schritten ist Schluss. Laeuft das Programm vielleicht endlos?" % GRENZE)
            sys.settrace(None)
            raise SystemExit(3)
        objekte = {}
        glob, lok = _rahmen(frame, objekte)
        d = {"art": "schritt", "ablauf": _ablauf_nr, "ereignis": ereignis,
             "zeile": frame.f_lineno, "funktion": frame.f_code.co_name,
             "stapel": _stapel(frame), "global": glob, "lokal": lok, "objekte": objekte}
        if _ORDNER is not None:
            import os
            d["datei"] = os.path.basename(frame.f_code.co_filename)
        if ereignis == "return":
            d["rueckgabe"] = _wert(arg, 0, objekte)
        if ereignis == "exception":
            d["ausnahme"] = "%s: %s" % (arg[0].__name__, arg[1])
        _senden(**d)
    return _trace


def _tk_umbauen():
    try:
        import tkinter as tk
    except ImportError:
        return
    import os
    original = tk.Misc.mainloop
    # Nur fuer Tests (25.10., Teil III): LERNRAUM_KLICKS = JSON-Liste von Knopf-Beschriftungen, "feld=text" tippt
    # ins erste Textfeld; die Klicks laufen aus der Ereignisschleife wie echte, danach schliesst das Fenster.
    # "klick=x,y" (15.11.2026, iq1 schach: geklickt wird am Brett) ist ein Mausklick auf die erste Zeichenflaeche.
    try:
        klicks = json.loads(os.environ.get("LERNRAUM_KLICKS", "null"))
    except ValueError:
        klicks = None

    def nachspielen(wurzel):
        offen, alle = list(wurzel.winfo_children()), []
        while offen:
            w = offen.pop(0)
            alle.append(w)
            offen[0:0] = list(w.winfo_children())
        for k in klicks:
            if k.startswith("feld="):
                for w in alle:
                    if w.winfo_class() == "Entry":
                        w.delete(0, "end")
                        w.insert(0, k[5:])
                        break
                continue
            if k.startswith("klick="):
                x, y = (int(v) for v in k[6:].split(","))
                for w in alle:
                    if w.winfo_class() == "Canvas":
                        w.winfo_id()        # auch ein verstecktes Fenster (Tests) nimmt das Ereignis nur an, wenn es besteht
                        w.event_generate("<Button-1>", x=x, y=y)
                        w.event_generate("<ButtonRelease-1>", x=x, y=y)
                        break
                continue
            for w in alle:
                if w.winfo_class() == "Button" and str(w.cget("text")).strip().lower() == k.strip().lower():
                    w.invoke()
                    break
        wurzel.destroy()

    def mainloop(self, n=0):
        global _im_mainloop
        # Ein Programm, das nur zeichnet, wartet auf niemanden (vorne/sitecustomize.py, Fenster im Browser 13.11.2026):
        # kein echtes Fenster, keine Meldung -- der Lauf endet hier, das Bild steht im Debugger
        nur = getattr(tk, "_lernraum_nur_zeichnen", None)
        if klicks is None and nur is not None and nur():
            return
        _im_mainloop = True
        _senden(art="mainloop", text="Das Fenster steht. Jeder Klick wird jetzt ein eigener Ablauf. Fenster schliessen beendet die Aufzeichnung.")
        if klicks is not None:
            self.after(50, lambda: nachspielen(self))
        try:
            original(self, n)
        finally:
            _im_mainloop = False
    tk.Misc.mainloop = mainloop
    _flaeche_umbauen(tk)


# Das Fenster im Debugger (12.11.2026, Durchsicht iq1 brett W7, Lehrer „A“: *„Beim Schritt mit dem Debugger entsteht
# direkt das komplette Feld. Ist die Idee nicht, dass in jedem Schleifendurchlauf ein neues Feld angezeigt wird?“*):
# Jede Zeichnung auf einer Zeichenflaeche wird ein Ereignis {"art": "zeichnen"} im Strom, wie ein print. Die Seite
# ordnet es dem Schritt zu, der gerade lief, und zeichnet die Flaeche so, wie sie bis zum gezeigten Schritt aussah.
# Ein Bild reist einmal je Datei als Daten mit (die Seite kennt den Ordner des Programms nicht).
_ZEICHNEN = (("create_rectangle", "rechteck"), ("create_oval", "oval"), ("create_line", "linie"),
             ("create_polygon", "vieleck"), ("create_text", "text"), ("create_image", "bild"))
_bilder_gesendet = set()


def _zeichnung_senden(c, was, i):
    def opt(k):
        try:
            return str(c.itemcget(i, k))
        except Exception:  # noqa: BLE001 -- die Option gibt es fuer diese Art nicht
            return ""
    d = {"art": "zeichnen", "was": was, "id": str(i), "flaeche": str(c), "ablauf": _ablauf_nr,
         "k": [round(float(v), 1) for v in c.coords(i)]}
    if was in ("rechteck", "oval", "vieleck"):
        d.update(fill=opt("fill"), outline=opt("outline"), width=opt("width"))
    elif was == "linie":
        # die Pfeilspitze (iq1 beziehung W1, 14.11.)
        d.update(fill=opt("fill"), width=opt("width"), arrow=opt("arrow"), arrowshape=opt("arrowshape"))
    elif was == "text":
        d.update(text=opt("text"), fill=opt("fill"), font=opt("font"), anchor=opt("anchor"))
    elif was == "bild":
        import base64
        import os
        name = opt("image")
        datei = str(c.tk.call(name, "cget", "-file")) if name else ""
        d.update(anchor=opt("anchor"), datei=os.path.basename(datei),
                 breite=int(c.tk.call("image", "width", name)) if name else 0,
                 hoehe=int(c.tk.call("image", "height", name)) if name else 0)
        if datei and datei not in _bilder_gesendet and os.path.isfile(datei) and os.path.getsize(datei) < 200000:
            with open(datei, "rb") as f:
                d["daten"] = base64.b64encode(f.read()).decode("ascii")
            _bilder_gesendet.add(datei)
    _senden(**d)


def _flaeche_umbauen(tk):
    bauen = tk.Canvas.__init__

    def init(self, *a, **kw):
        bauen(self, *a, **kw)
        try:
            _senden(art="zeichnen", was="flaeche", flaeche=str(self), ablauf=_ablauf_nr,
                    breite=int(float(self.cget("width"))), hoehe=int(float(self.cget("height"))), bg=str(self.cget("bg")))
        except Exception:  # noqa: BLE001 -- das Bild im Debugger ist eine Zugabe, nie ein Abbruch
            pass
    tk.Canvas.__init__ = init

    def huelle(name, was):
        f = getattr(tk.Canvas, name)

        def neu(self, *a, **kw):
            i = f(self, *a, **kw)
            try:
                _zeichnung_senden(self, was, i)
            except Exception:  # noqa: BLE001
                pass
            return i
        setattr(tk.Canvas, name, neu)
    for name, was in _ZEICHNEN:
        huelle(name, was)
    loeschen = tk.Canvas.delete

    def delete(self, *a):
        r = loeschen(self, *a)
        try:
            _senden(art="zeichnen", was="weg", flaeche=str(self), ablauf=_ablauf_nr, ziel=[str(x) for x in a])
        except Exception:  # noqa: BLE001
            pass
        return r
    tk.Canvas.delete = delete


def _input_umbauen():
    """input() bekommt zuerst die Eingaben, die die Seite vorab mitgibt (LERNRAUM_EINGABEN als JSON-Liste --
    der Code-Film); sind sie verbraucht, WARTET die Aufzeichnung (Lehrer 24.10.: „dass der Debugger automatisch
    stoppt, wenn man eine Eingabe in die Shell schreiben soll. So kenne ich das“): Sie meldet {"art": "warte"}
    und liest eine Zeile von stdin, die die Seite ueber aufzeichnen/eingabe schickt. Bis dahin aufgezeichnete
    Schritte kann man schon ansehen, auch rueckwaerts. stdin zu -> das Programm endet wie vorher."""
    import builtins
    import os
    try:
        vorrat = json.loads(os.environ.get("LERNRAUM_EINGABEN", "[]"))
    except ValueError:
        vorrat = []

    def eingabe(frage=""):
        _senden(art="ausgabe", text=str(frage), ablauf=_ablauf_nr, schritt=_schritte)
        if vorrat:
            antwort = vorrat.pop(0)
        else:
            _senden(art="warte", frage=str(frage), ablauf=_ablauf_nr, schritt=_schritte)
            zeile = sys.__stdin__.readline()
            if not zeile:
                _senden(art="ausgabe", text="[keine Eingabe mehr -- Ende]\n", ablauf=_ablauf_nr, schritt=_schritte)
                raise SystemExit(0)
            antwort = zeile.rstrip("\r\n")
        _senden(art="ausgabe", text=antwort + "\n", ablauf=_ablauf_nr, schritt=_schritte)
        return antwort
    builtins.input = eingabe


def _attribute_laden():
    """pruefen.attribute aus dem Ordner dieses Skripts, unter eigenem Namen und nicht in sys.modules -- ein Modul der
    Klasse, das pruefen.py hiesse, bliebe ungestoert."""
    global _attribute
    import importlib.util
    import os
    spec = importlib.util.spec_from_file_location(
        "_lernraum_pruefen", os.path.join(os.path.dirname(os.path.abspath(__file__)), "pruefen.py"))
    modul = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(modul)
    _attribute = modul.attribute


def main():
    global _DATEI, _ORDNER, _GEGEBEN
    _DATEI = sys.argv[1]
    _attribute_laden()
    # Der Suchpfad wie beim Ausfuehren (11.11.2026): vorn steht der Ordner des PROGRAMMS, nicht der dieses Skripts.
    # Bis dahin brach der Debugger an `from figur import Figur` mit ModuleNotFoundError ab (das Modul liegt neben
    # dem Programm) -- und `import stand` haette ein Modul des Kursservers geholt.
    import os
    sys.path[0] = os.path.dirname(os.path.abspath(_DATEI))
    try:
        ordner = json.loads(os.environ.get("LERNRAUM_ORDNER", "null"))
    except ValueError:
        ordner = None
    if isinstance(ordner, dict):
        _ORDNER = _norm(os.path.dirname(os.path.abspath(_DATEI)))
        _GEGEBEN = {os.path.normcase(str(g)) for g in ordner.get("gegeben") or []}
    _tk_umbauen()
    _input_umbauen()
    sys.stdout = _Ausgabe()
    sys.stderr = _Ausgabe()
    _senden(art="ablauf", nr=0, name="Programmstart")
    code = 0
    sys.settrace(_trace)
    try:
        runpy.run_path(_DATEI, run_name="__main__")
    except SystemExit as e:
        code = e.code if isinstance(e.code, int) else 0
    except BaseException:  # noqa: BLE001 -- der Fehler des Programms ist Inhalt
        sys.settrace(None)
        tb = traceback.format_exc()
        _senden(art="fehler", text=tb)
        code = 1
    finally:
        sys.settrace(None)
    _senden(art="ende", code=code, schritte=_schritte)
    sys.exit(code)


if __name__ == "__main__":
    main()
