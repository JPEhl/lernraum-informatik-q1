"""Selbstcheck „Bubblesort“ -- prueft das Programm im Ordner rangliste/ (es laeuft portal.py).

Die Klasse schreibt in rangliste.py durchgang(nummer) und sortiere() (Aufgabe 2), get_vergleiche() (Aufgabe 3 ★) und in
portal.py die Zeile fuer die Shell und messreihe() (Aufgabe 3). Der Check prueft die Klasse ueber OBJEKTE, die er
selbst baut (LC8): eigene Ranglisten mit eigenen Mitgliedern -- nie die zwanzig aus mitglieder.py --, und er liest,
welche OBJEKTE danach auf welchem Platz stehen (nicht nur die Wertungen: Das Mitglied wandert, nicht die Zahl).
Das Portal liest er an einem FRISCHEN Lauf, auf dem er klickt wie die Maus (klick_auf, LC6): eine Zeile der Liste
(ein Durchgang) und die Kopfzeile (alles sortiert).

AUFWAND ZAEHLEN (LC5): Wo gezaehlt wird, gibt der Check Wertungen der Klasse _Z hinein -- eine Unterklasse von int, die
jeden Vergleich mitschreibt. So prueft Aufgabe 2 ★★, wie viele Paare ein Durchgang vergleicht, Aufgabe 3 ★, ob der
Zaehler der Rangliste jeden Vergleich zaehlt, und die Expertenaufgabe ihre Auflage.

Seit der Reihensichtung Teil II (17.11.2026): Aufgabe 2 ★ sind BEIDE Methoden (danach laeuft das Programm mit beiden
Klicks -- Befund 22; bis dahin war sortiere ★★, und nach ★ brach der Klick auf die Kopfzeile ab), ★★ ist der kuerzere
Durchgang (- nummer, die Invariante). Aufgabe 3 rechnet nicht mehr mit festen Zahlen: Der Zaehler wird gegen die
mitgezaehlten Vergleiche geprueft, die Zeile der Shell gegen get_vergleiche() nach dem Klick, die Messreihe gegen neue
Ranglisten DERSELBEN Klasse -- so faerbt ein Fehler in messreihe() nur Aufgabe 3 ★★ (Befund 22), und wer Aufgabe 6
(frueher Abbruch) oder Aufgabe 2 ★★ noch nicht gemacht hat, wird in Aufgabe 3 nicht rot. Die Expertenaufgabe ist
Aufgabe 8 (die_besten(k), Befund 16; bis dahin Aufgabe 7 umdrehen()).

Startzustand (= start_rangliste mit vorbereitetem portal.py): die Grundlage passt, offen ist genau Aufgabe 2 ★ (die
Methode durchgang fehlt), alles andere wartet. Steht Aufgabe 2 ★, sind Aufgabe 2 ★★ und Aufgabe 3 ★ dran; die
Messreihe (3 ★★), sobald 3 ★ passt; Mehr 6, sobald 2 ★★ und 3 ★ passen und durchgang etwas zurueckgibt; die
Expertenaufgabe, sobald in rangliste_beste.py die Klasse mit die_besten() steht.
"""
import ast
import importlib
import re
import sys

import pruefen
from pruefen import erwarte, braucht, quelltext, anspielen, erzeuge, rufe, klasse, klick_auf

TITEL = "Bubblesort · Selbstcheck"
EINGABEN = []
HINTS = {"aufnehmen": {"None"}, "anzahl": {"int"}, "get_mitglied": {"Mitglied"}, "finde_position": {"int"},
         "durchgang": {"None", "bool"}, "sortiere": {"None"}, "get_vergleiche": {"int"}}
DIAGRAMMTYPEN = {"String", "integer", "boolean", "Integer", "Boolean"}
PROBE = [("Ada", 30), ("Bo", 10), ("Cem", 50), ("Dua", 20), ("Eli", 40)]
ANMELDUNG = [("Aylin", 1480), ("Bence", 1215), ("Chiara", 1630), ("Dawit", 1342), ("Emre", 1105), ("Finja", 1577),
             ("Goran", 1290), ("Hanh", 1418), ("Ilias", 1048), ("Jule", 1466), ("Kofi", 1712), ("Liv", 1322),
             ("Milan", 1189), ("Nuria", 1540), ("Oskar", 1401), ("Pari", 1273), ("Quinn", 1433), ("Rosa", 1163),
             ("Samir", 1502), ("Tuana", 1251)]


class _Z(int):
    """Eine Wertung, die mitschreibt, wie oft sie verglichen wird (LC5) -- rechnet und druckt wie eine Zahl. Auch
    int < _Z zaehlt: Python fragt bei einer Unterklasse rechts zuerst deren Methode."""
    n = 0

    def __lt__(a, b):
        _Z.n += 1
        return int(a) < int(b)

    def __gt__(a, b):
        _Z.n += 1
        return int(a) > int(b)

    def __le__(a, b):
        _Z.n += 1
        return int(a) <= int(b)

    def __ge__(a, b):
        _Z.n += 1
        return int(a) >= int(b)

    __hash__ = int.__hash__


def _zaehlend(paare):
    """Dieselben Mitglieder, aber mit Wertungen, die ihre Vergleiche zaehlen."""
    return [(n, _Z(w)) for n, w in paare]


def _bubble(paare, durchgaenge=None):
    """Eigene Rechnung des Checks: die Liste nach so vielen Durchgaengen (None: alle)."""
    a = list(paare)
    for d in range(1, len(a) if durchgaenge is None else durchgaenge + 1):
        for i in range(len(a) - d):
            if int(a[i][1]) > int(a[i + 1][1]):
                a[i], a[i + 1] = a[i + 1], a[i]
    return a


def _zahlen(text):
    return [int(z) for z in re.findall(r"\d+", text)]


def _liste(paare, k="Rangliste"):
    """Eine Rangliste der Klasse mit eigenen Mitgliedern -- gibt (Rangliste, [Mitglied-Objekte])."""
    r = erzeuge(k)
    objekte = []
    for name, wertung in paare:
        m = erzeuge("Mitglied", name, wertung)
        objekte.append(m)
        rufe(r, "aufnehmen", m)
    return r, objekte


def _objekte(r):
    return [rufe(r, "get_mitglied", i) for i in range(rufe(r, "anzahl"))]


def _reihe(r):
    """Was auf den Plaetzen steht, wie man es liest: [(Name, Wertung)]."""
    return [(rufe(m, "get_name"), int(rufe(m, "get_wertung"))) for m in _objekte(r)]


def _wertungen(reihe):
    return ", ".join(str(int(w)) for n, w in reihe)


def _dieselben(r, objekte):
    """Stehen in der Rangliste genau diese Objekte (jedes einmal, keines verloren, keines doppelt)?"""
    ist = _objekte(r)
    return len(ist) == len(objekte) and all(any(m is o for m in ist) for o in objekte)


def _spiel():
    """portal.py noch einmal, frisch. Gibt (Shell am Start, Namensraum, letzte Fehlerzeile) -- der Namensraum ist
    None, wenn das Programm nicht bis zum Ende lief."""
    alt = pruefen._QUELLE
    pruefen._QUELLE = alt + "\nprint('--ENDE--')\n"
    try:
        aus, ns = anspielen([])
    finally:
        pruefen._QUELLE = alt
    zeilen = [z for z in aus.strip().splitlines() if z.strip() and "--ENDE--" not in z]
    fehler = zeilen[-1] if zeilen and "Error" in zeilen[-1] else ""
    return "\n".join(zeilen), (ns if "--ENDE--" in aus else None), fehler


def _klick(zeile):
    """Klickt wie die Maus auf eine Zeile der Liste (-1: die Kopfzeile) -- im Fenster des letzten frischen Laufs.
    Gibt, was dabei in der Shell erschien."""
    a = sys.modules.get("anzeige")
    c = a.flaeche
    y = a.KOPF // 2 if zeile < 0 else a.KOPF + zeile * a.ZEILE + a.ZEILE // 2
    alt = pruefen._FENSTER
    pruefen._FENSTER = c.winfo_toplevel()
    try:
        return klick_auf(120, y, wo="die Kopfzeile" if zeile < 0 else "Zeile %d der Liste" % (zeile + 1))
    finally:
        pruefen._FENSTER = alt


def _modul(name):
    m = sys.modules.get(name)
    if m is not None:
        return m
    try:
        return importlib.import_module(name)
    except Exception:  # noqa: BLE001 -- dann gibt es das Modul fuer den Check nicht
        return None


def _ok(pruefung):
    """Passt eine Pruefung? (nur fuer braucht -- faengt den Befund, LC8; auch die Endlosschleife: Die meldet dann
    nur die Pruefung, zu der sie gehoert)"""
    try:
        pruefung()
    except (AssertionError, pruefen._ZuLang):
        return False
    return True


def _methode(datei, name):
    """Der Knoten der Methode im Quelltext -- None, wenn es sie nicht gibt oder die Datei nicht lesbar ist."""
    try:
        baum = ast.parse(quelltext(datei))
    except SyntaxError:
        return None
    for k in ast.walk(baum):
        if isinstance(k, ast.FunctionDef) and k.name == name:
            return k
    return None


def _fremd_sortiert(datei):
    """sort() und sorted() in einer Datei der Klasse (am Baum, nicht am Wort)."""
    try:
        baum = ast.parse(quelltext(datei))
    except SyntaxError:
        return []
    return sorted({k.attr if isinstance(k, ast.Attribute) else k.id for k in ast.walk(baum)
                   if (isinstance(k, ast.Attribute) and k.attr == "sort") or (isinstance(k, ast.Name) and k.id == "sorted")})


def pruefe_00_grundlage():
    """Grundlage · portal.py läuft, und im Fenster steht die Liste der Mitglieder"""
    shell, ns, fehler = _spiel()
    erwarte(ns is not None, "portal.py bricht ab, bevor die Liste im Fenster steht%s -- seht in der Shell nach, in "
            "welcher Zeile." % (" (%s)" % fehler if fehler else ""))
    r = ns.get("rangliste")
    erwarte(r is not None and rufe(r, "anzahl") == 20, "In portal.py gibt es die Rangliste mit den zwanzig Mitgliedern nicht "
            "mehr -- die Zeilen oben in portal.py bleiben, wie sie waren.")


def pruefe_20_sortiert():
    """Aufgabe 2 ★ · durchgang und sortiere: Die Mitglieder tauschen den Platz, ein Klick ist ein Durchgang, die Kopfzeile sortiert alles"""
    k = klasse("Rangliste")
    erwarte(hasattr(k, "durchgang"), "In rangliste.py fehlt noch die Methode durchgang(nummer) -- ein Klick auf die "
            "Liste ruft sie.")
    r, objekte = _liste(PROBE)
    rufe(r, "durchgang", 1)
    ist = _reihe(r)
    erwarte(_dieselben(r, objekte), "Fünf Mitglieder mit den Wertungen 30, 10, 50, 20, 40: Nach durchgang(1) stehen in "
            "der Rangliste nicht mehr dieselben fünf Mitglieder -- beim Tauschen geht eines verloren oder steht doppelt da.")
    erwarte(ist == _bubble(PROBE, 1), "Fünf Mitglieder mit den Wertungen 30, 10, 50, 20, 40: Nach durchgang(1) stehen "
            "dort %s -- erwartet 10, 30, 20, 40, 50 (die höchste Wertung ganz hinten)." % _wertungen(ist))
    rufe(r, "durchgang", 2)
    ist = _reihe(r)
    erwarte(ist == _bubble(PROBE, 2), "Nach durchgang(1) und durchgang(2) stehen dort %s -- erwartet 10, 20, 30, 40, 50."
            % _wertungen(ist))
    erwarte(hasattr(k, "sortiere"), "In rangliste.py fehlt noch die Methode sortiere() -- ein Klick auf die "
            "Kopfzeile ruft sie.")
    for paare in (PROBE, PROBE[::-1], sorted(PROBE, key=lambda p: p[1]), [("Ada", 7)], [],
                  [("Ada", 20), ("Bo", 20), ("Cem", 10)], [("Ada", 3), ("Bo", 2), ("Cem", 1), ("Dua", 4)],
                  ANMELDUNG[:9], ANMELDUNG[:11]):
        r, objekte = _liste(paare)
        rufe(r, "sortiere")
        ist = _reihe(r)
        erwarte(_dieselben(r, objekte), "Nach sortiere() stehen in einer Rangliste mit %d Mitgliedern nicht mehr "
                "dieselben Mitglieder." % len(paare))
        erwarte([w for n, w in ist] == sorted(w for n, w in paare), "Mitglieder mit den Wertungen %s: Nach sortiere() "
                "stehen dort %s -- nicht aufsteigend sortiert." % (_wertungen(paare) or "(keine)", _wertungen(ist) or "(keine)"))
    fremd = _fremd_sortiert("rangliste.py")
    erwarte(not fremd, "In rangliste.py steht %s -- hier sortiert ihr selbst, mit durchgang."
            % " und ".join(n + "()" for n in fremd))
    shell, ns, fehler = _spiel()
    erwarte(ns is not None, "portal.py bricht ab, bevor die Liste im Fenster steht%s." % (" (%s)" % fehler if fehler else ""))
    _klick(3)
    unten = _reihe(ns["rangliste"])[-1]
    erwarte(unten == ("Kofi", 1712), "Ein Klick auf die Liste ist ein Durchgang: Danach soll Kofi (1712) ganz unten "
            "stehen -- dort steht %s (%d)." % unten)
    _klick(-1)
    ist = _reihe(ns["rangliste"])
    erwarte(ist == sorted(ANMELDUNG, key=lambda p: p[1]), "Ein Klick auf die Kopfzeile soll alle zwanzig Mitglieder "
            "sortieren -- oben steht danach %s (%d), unten %s (%d)." % (ist[0] + ist[-1]))


def pruefe_25_kuerzer():
    """Aufgabe 2 ★★ · Hinten liegt schon fest: Jeder Durchgang endet einen Platz früher"""
    braucht(_ok(pruefe_20_sortiert), "Erst sortiert die Rangliste (Aufgabe 2 ★).")
    r, _ = _liste(_zaehlend(PROBE))
    for nummer in (1, 2, 3, 4):
        _Z.n = 0
        rufe(r, "durchgang", nummer)
        gezaehlt = _Z.n
        fest = ("liegt hinten noch nichts fest" if nummer == 1 else "liegt hinten schon ein Platz fest" if nummer == 2
                else "liegen hinten schon %d Plätze fest" % (nummer - 1))
        erwarte(gezaehlt == len(PROBE) - nummer, "Fünf Mitglieder, durchgang(%d): verglichen wurde %d-mal. Vor diesem "
                "Durchgang %s -- zu vergleichen sind %d Paare. Wofür steht nummer?"
                % (nummer, gezaehlt, fest, len(PROBE) - nummer))
    fest = [("Ada", 20), ("Bo", 10), ("Cem", 5), ("Dua", 4), ("Eli", 3)]
    r, objekte = _liste(fest)
    rufe(r, "durchgang", 4)
    ist = _reihe(r)
    erwarte(ist == [("Bo", 10), ("Ada", 20), ("Cem", 5), ("Dua", 4), ("Eli", 3)], "Fünf Mitglieder mit 20, 10, 5, 4, 3: "
            "durchgang(4) vergleicht nur noch das erste Paar -- hinten liegen schon drei Plätze fest. Bei euch steht "
            "danach %s." % _wertungen(ist))


def pruefe_30_vergleiche():
    """Aufgabe 3 ★ · Die Rangliste zählt ihre Vergleiche, und der Klick nennt sie in der Shell"""
    braucht(_ok(pruefe_20_sortiert), "Erst sortiert die Rangliste (Aufgabe 2 ★).")
    k = klasse("Rangliste")
    erwarte(hasattr(k, "get_vergleiche"), "In rangliste.py fehlt noch die Methode get_vergleiche().")
    r, _ = _liste(_zaehlend(PROBE))
    v = rufe(r, "get_vergleiche")
    erwarte(v == 0, "Eine neue Rangliste hat noch nichts verglichen -- get_vergleiche() gibt %r." % (v,))
    _Z.n = 0
    rufe(r, "durchgang", 1)
    gezaehlt = _Z.n
    v = rufe(r, "get_vergleiche")
    erwarte(v == gezaehlt, "Fünf Mitglieder (30, 10, 50, 20, 40), durchgang(1): Verglichen wurde %d-mal, "
            "get_vergleiche() gibt %r. Gezählt wird jeder Vergleich, nicht jeder Tausch." % (gezaehlt, v))
    rufe(r, "durchgang", 2)
    gezaehlt = _Z.n
    v = rufe(r, "get_vergleiche")
    erwarte(v == gezaehlt, "Nach durchgang(1) und durchgang(2) wurde zusammen %d-mal verglichen -- get_vergleiche() "
            "gibt %r. Zählt die Rangliste über alle Durchgänge weiter?" % (gezaehlt, v))
    zweite, _ = _liste(PROBE)
    v = rufe(zweite, "get_vergleiche")
    erwarte(v == 0, "Eine zweite, neue Rangliste beginnt wieder bei 0 -- ihre get_vergleiche() gibt %r. Wo entsteht "
            "der Zähler?" % (v,))
    shell, ns, fehler = _spiel()
    erwarte(ns is not None, "portal.py bricht ab, bevor die Liste im Fenster steht%s." % (" (%s)" % fehler if fehler else ""))
    for klicks in (1, 2):
        text = _klick(3)
        soll = rufe(ns["rangliste"], "get_vergleiche")
        erwarte(klicks in _zahlen(text) and soll in _zahlen(text), "Nach dem %s Klick auf die Liste sollen in der Shell "
                "die Durchgänge (%d) und die Vergleiche der Rangliste (%d) stehen -- dort steht: %s"
                % ("ersten" if klicks == 1 else "zweiten", klicks, soll, text.strip()[:70] or "nichts"))


def pruefe_35_messreihe():
    """Aufgabe 3 ★★ · messreihe() nennt die Vergleiche für 5, 10 und 20 Mitglieder"""
    braucht(_ok(pruefe_30_vergleiche), "Erst zählt die Rangliste ihre Vergleiche (Aufgabe 3 ★).")
    shell, ns, fehler = _spiel()
    erwarte(ns is not None, "portal.py bricht ab, bevor die Liste im Fenster steht%s." % (" (%s)" % fehler if fehler else ""))
    erwarte(callable(ns.get("messreihe")), "In portal.py fehlt noch die Funktion messreihe().")
    zeilen = [_zahlen(z) for z in shell.splitlines()]
    erwarte(any(z for z in zeilen), "messreihe() steht in portal.py, aber am Start steht nichts in der Shell -- wird "
            "sie aufgerufen, bevor das Fenster entsteht?")
    fehlt = []
    for n in (5, 10, 20):
        # gemessen an einer neuen Rangliste DERSELBEN Klasse -- so rechnet der Check mit eurem Bubblesort, auch mit
        # dem fruehen Abbruch (Aufgabe 6) oder vor Aufgabe 2 ★★
        neu, _ = _liste(ANMELDUNG[:n])
        rufe(neu, "sortiere")
        soll = rufe(neu, "get_vergleiche")
        if not any(n in z and soll in z for z in zeilen):
            fehlt.append("%d Mitglieder: %d Vergleiche" % (n, soll))
    oben = _reihe(ns["rangliste"])[0]
    erwarte(oben == ("Aylin", 1480), "Nach der Messreihe ist die Rangliste des Portals schon sortiert (oben steht "
            "%s) -- messen soll sie an neuen Ranglisten, nicht an der des Portals." % oben[0])
    erwarte(not fehlt, "In der Shell fehlt am Start: %s. Jede Größe braucht eine neue Rangliste mit den ersten "
            "Mitgliedern aus alle_mitglieder()." % " · ".join(fehlt))


def pruefe_60_abbruch():
    """Aufgabe 6 ★★ · sortiere() hört auf, sobald ein Durchgang nichts getauscht hat"""
    braucht(_ok(pruefe_30_vergleiche) and _ok(pruefe_25_kuerzer), "Erst sortiert und zählt die Rangliste, mit kürzeren "
            "Durchgängen (Aufgabe 2 und 3).")
    d = _methode("rangliste.py", "durchgang")
    braucht(d is not None and any(isinstance(x, ast.Return) and x.value is not None for x in ast.walk(d)),
            "Erst gibt durchgang zurück, ob es getauscht hat.")
    for was, paare, soll in (("sechs Mitglieder, schon sortiert", [("A", 1), ("B", 2), ("C", 3), ("D", 4), ("E", 5), ("F", 6)], 5),
                             ("sechs Mitglieder, nur zwei Nachbarn vertauscht (1, 2, 3, 5, 4, 6)",
                              [("A", 1), ("B", 2), ("C", 3), ("D", 5), ("E", 4), ("F", 6)], 9),
                             ("sechs Mitglieder, genau falsch herum", [("A", 6), ("B", 5), ("C", 4), ("D", 3), ("E", 2), ("F", 1)], 15)):
        r, _ = _liste(paare)
        rufe(r, "sortiere")
        ist = _reihe(r)
        erwarte([w for n, w in ist] == sorted(w for n, w in paare), "Mit dem frühen Abbruch sortiert sortiere() nicht "
                "mehr richtig: %s -- danach steht dort %s." % (was, _wertungen(ist)))
        v = rufe(r, "get_vergleiche")
        erwarte(v == soll, "%s: sortiere() braucht %r Vergleiche -- mit dem frühen Abbruch sind es %d." % (was[0].upper() + was[1:], v, soll))


# die Expertenaufgabe: je Fall (Mitglieder, k) -- dabei Faelle, in denen k - 1 Durchgaenge NICHT reichen (das k-te
# steht dann noch nicht fest) und ein Fall, in dem die Reihenfolge der Antwort zaehlt
BESTE_FAELLE = [(PROBE, 1), (PROBE, 2), ([("Ada", 50), ("Bo", 40), ("Cem", 10), ("Dua", 20), ("Eli", 30)], 2),
                (ANMELDUNG, 3), (ANMELDUNG, 10), (PROBE, 5)]


def pruefe_80_die_besten():
    """Aufgabe 8 ★★★ · rangliste_beste.py: die_besten(k) mit höchstens k Durchgängen"""
    m = _modul("rangliste_beste")
    k = getattr(m, "Rangliste", None) if m is not None else None
    braucht(isinstance(k, type) and hasattr(k, "die_besten"), "Erst die Klasse Rangliste mit die_besten(k) in "
            "rangliste_beste.py.")
    fremd = _fremd_sortiert("rangliste_beste.py")
    erwarte(not fremd, "Die Auflage: ohne %s -- die_besten sortiert nicht alles." % " und ".join(n + "()" for n in fremd))
    for paare, wie_viele in BESTE_FAELLE:
        n = len(paare)
        r, objekte = _liste(_zaehlend(paare), k)
        _Z.n = 0
        beste = rufe(r, "die_besten", wie_viele)
        gezaehlt = _Z.n
        budget = sum(n - d for d in range(1, wie_viele + 1))
        soll = sorted(objekte, key=lambda o: -int(rufe(o, "get_wertung")))[:wie_viele]
        art = type(beste).__name__
        erwarte(isinstance(beste, list), "die_besten(%d) gibt %s zurück -- erwartet eine Liste von Mitgliedern."
                % (wie_viele, "nichts (None)" if beste is None else "etwas vom Typ " + art))
        ist = ", ".join(str(int(rufe(x, "get_wertung"))) if any(x is o for o in objekte) else repr(x) for x in beste)
        gesucht = "die höchste Wertung" if wie_viele == 1 else "die %d höchsten Wertungen, die beste zuerst" % wie_viele
        erwarte(len(beste) == wie_viele and all(a is b for a, b in zip(beste, soll)), "%d Mitglieder (%s), "
                "die_besten(%d): zurück kommt %s -- erwartet %s."
                % (n, _wertungen(paare), wie_viele, ist or "(nichts)", gesucht))
        erwarte(_dieselben(r, objekte), "Nach die_besten(%d) fehlen in der Rangliste Mitglieder -- die Reihenfolge darf "
                "sich ändern, aber keines darf verloren gehen." % wie_viele)
        kosten = "ein Durchgang kostet" if wie_viele == 1 else "%d Durchgänge kosten" % wie_viele
        erwarte(gezaehlt <= budget, "%d Mitglieder, die_besten(%d): verglichen wurde %d-mal -- %s höchstens %d. Muss "
                "dafür die ganze Liste sortiert sein?" % (n, wie_viele, gezaehlt, kosten, budget))


def pruefe_90_hints():
    """Hinweis · Jede Methode in rangliste.py mit Type Hints (kein Stern)"""
    try:
        baum = ast.parse(quelltext("rangliste.py"))
    except SyntaxError:
        return
    ohne, falsch, diagramm = [], [], []
    for k in ast.walk(baum):
        if not isinstance(k, ast.FunctionDef):
            continue
        for a in k.args.args + [k]:
            typ = a.annotation if isinstance(a, ast.arg) else a.returns
            if typ is not None and any(isinstance(x, ast.Name) and x.id in DIAGRAMMTYPEN for x in ast.walk(typ)):
                diagramm.append("%s (%s)" % (k.name, ast.unparse(typ)))
        parameter = [a for a in k.args.args if a.arg != "self"]
        if any(a.annotation is None for a in parameter) or (k.returns is None and k.name != "__init__"):
            ohne.append(k.name)
        elif k.name in HINTS and ast.unparse(k.returns).replace(" ", "") not in HINTS[k.name]:
            falsch.append("%s -> %s" % (k.name, " oder ".join(sorted(HINTS[k.name]))))
    erwarte(not diagramm, "Hier steht ein Typ in der Schreibweise des Diagramms: %s. In Python heißt er str, int, "
            "float oder bool." % ", ".join(diagramm))
    erwarte(not ohne, "Ohne Type Hint (hinter der Klammer oder an einem Parameter): %s. Es läuft auch ohne; "
            "vereinbart ist es trotzdem -- der Konstruktor braucht hinter der Klammer keinen." % ", ".join(ohne))
    erwarte(not falsch, "Dieser Type Hint passt nicht zu dem, was zurückkommt -- erwartet: %s." % ", ".join(falsch))
