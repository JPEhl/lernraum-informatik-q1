# zahlen.py -- vier Wertungen, klein:
# Bubblesort als Methode einer Klasse.


class Wertungen:

    def __init__(self, zahlen: list[int]):
        self.__zahlen = zahlen

    def get_zahlen(self) -> list[int]:
        return self.__zahlen


wertungen = Wertungen([1480, 1215, 1630, 1342])
print(wertungen.get_zahlen())
