# bedrohung.py -- eine Figur bedroht eine
# andere: zwei Assoziationen zur Figur.
# Echt ist sie, wenn der Angreifer ein
# Gegner ist und so schlagen kann.

# erlaubt die eigene Klasse als Typ:
from __future__ import annotations
from figur import Figur


class Bedrohung:

    def __init__(self, angreifer: Figur, ziel: Figur):
        self.__angreifer = angreifer
        self.__ziel = ziel

    def get_angreifer(self) -> Figur:
        return self.__angreifer

    def get_ziel(self) -> Figur:
        return self.__ziel

    def ist_echt(self) -> bool:
        if not self.__angreifer.ist_gegner(self.__ziel):
            return False
        zeile = self.__ziel.get_zeile()
        spalte = self.__ziel.get_spalte()
        return self.__angreifer.schlaegt(zeile, spalte)
