# zaehlen.py -- derselbe Bubblesort,
# jetzt zählt er seine Vergleiche.

wertungen = [1480, 1215, 1630, 1342,
             1105, 1577, 1290, 1418,
             1048, 1466, 1712, 1322,
             1189, 1540, 1401, 1273]

vergleiche = 0
for durchgang in range(1, len(wertungen)):
    for platz in range(len(wertungen) - durchgang):
        vergleiche = vergleiche + 1
        if wertungen[platz] > wertungen[platz + 1]:
            merke = wertungen[platz]
            wertungen[platz] = wertungen[platz + 1]
            wertungen[platz + 1] = merke

print(wertungen)
print(vergleiche)
