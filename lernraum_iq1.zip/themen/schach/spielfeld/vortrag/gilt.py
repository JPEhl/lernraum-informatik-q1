# gilt.py -- das Spiel aus ziehen.py.
# Neu: Es prüft, bevor es ändert.

from brett import zeichne_felder, hebe_hervor, zeichne_pfeil, FELDGROESSE
from zeichenflaeche import zeichne_bild, zeige
from figur import Figur
from spieler import Spieler
from zug import Zug


class Spiel:

    def __init__(self):
        self.__weiss = Spieler("weiß")
        self.__schwarz = Spieler("schwarz")
        self.__feld: list[list[Figur]] = []
        for zeile in range(8):
            reihe: list[Figur] = []
            for spalte in range(8):
                reihe.append(None)
            self.__feld.append(reihe)
        self.__stelle(Figur("Dame", "weiß", 7, 3), self.__weiss)
        self.__stelle(Figur("König", "weiß", 7, 4), self.__weiss)
        self.__stelle(Figur("Dame", "schwarz", 0, 3), self.__schwarz)
        self.__stelle(Figur("König", "schwarz", 0, 4), self.__schwarz)

    def __stelle(self, figur: Figur, spieler: Spieler) -> None:
        spieler.aufnehmen(figur)
        self.__feld[figur.get_zeile()][figur.get_spalte()] = figur

    def figur_auf(self, zeile: int, spalte: int) -> Figur:
        return self.__feld[zeile][spalte]

    def ziehe(self, zug: Zug) -> bool:
        figur = zug.get_figur()
        self.__feld[figur.get_zeile()][figur.get_spalte()] = None
        zug.ausfuehren()
        self.__feld[zug.get_zeile()][zug.get_spalte()] = figur
        return True

    def zeichne(self, groesse: int) -> None:
        for zeile in range(8):
            for spalte in range(8):
                figur = self.__feld[zeile][spalte]
                if figur != None:
                    zeichne_bild(figur.bildname(), spalte * groesse,
                                 zeile * groesse, groesse)


spiel = Spiel()
dame = spiel.figur_auf(7, 3)
zug = Zug(dame, 3, 3)

zeichne_felder()
zeichne_pfeil(zug)
spiel.ziehe(zug)
print(spiel.figur_auf(3, 3).get_art())
spiel.zeichne(FELDGROESSE)
hebe_hervor(dame.get_zeile(), dame.get_spalte())
zeige()
