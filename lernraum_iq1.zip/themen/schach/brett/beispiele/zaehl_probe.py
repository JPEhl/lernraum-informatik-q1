zahlen = [3, 8, 5]
anzahl = 0
for zahl in zahlen:
    if zahl > 4:
        anzahl = anzahl + 1
print(anzahl)
