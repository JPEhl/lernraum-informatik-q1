# portal.py -- das Schachportal.
# Vorbereitet für dieses Thema: Ein Klick
# auf die Liste ruft durchgang, ein Klick
# auf die Kopfzeile ruft sortiere. Beide
# schreibt ihr in rangliste.py.

from anzeige import neue_anzeige, zeichne_rangliste
from anzeige import bei_klick, zeige
from mitglieder import alle_mitglieder
from rangliste import Rangliste

rangliste = Rangliste()
for mitglied in alle_mitglieder():
    rangliste.aufnehmen(mitglied)

durchgaenge = 0


def klick(zeile: int) -> None:
    global durchgaenge
    if zeile == -1:
        rangliste.sortiere()
        durchgaenge = rangliste.anzahl() - 1
    elif durchgaenge < rangliste.anzahl() - 1:
        durchgaenge = durchgaenge + 1
        rangliste.durchgang(durchgaenge)
    zeichne_rangliste(rangliste, durchgaenge)


neue_anzeige(rangliste.anzahl())
zeichne_rangliste(rangliste, durchgaenge)
bei_klick(klick)
zeige()
