// Werkstatt "Karten" -- Mitgliedskarten des Schachportals, verdeckt: Der Tisch sagt nur, welche von zwei Karten die
// hoehere Wertung hat, und zaehlt. iq1 schach, Teil II (16.11.2026). Drei Attrappen im Film (verdeckt und frei · offen
// mit zwei Zeigern · der Tisch fuehrt eine Vorschrift aus); Lehrerwahl: Fassung A „verdeckt und frei“. Anlass ist sein
// Wunsch, „die Schüler am Anfang auch experimentieren zu lassen. Sie sollen selbst möglichst ‚effiziente‘ Sortierungen
// entwerfen“ -- offene Karten sortiert das Auge, also liegen sie verdeckt, und „effizient“ heisst: wenige Vergleiche.
// Tische (LT9: ein Tisch erscheint erst mit seinem Thema):
//   sortieren -- sortieren: je zwei beliebige Karten vergleichen, tauschen, aufdecken; 4, 8 oder 16 Karten
//   zaehlen   -- sortieren, bubblesort: erst schaetzen, dann zaehlt der Tisch den Bubblesort; Tabelle und Kurve
//   nachbarn  -- bubblesort: nur das Paar am Zeiger -- vergleichen, tauschen, weiter; nach jedem Durchgang liegt eine fest
//   halbieren -- halbieren: sortiert und verdeckt, jede aufgedeckte Karte ist eine Frage
// Kein Rueckgaengig: Ein Vergleich, der gezaehlt ist, bleibt gezaehlt. „von vorn“ legt dieselben Karten wieder hin.
// Ziehen (Lehrer 16.11.2026: „per Drag and Drop auf den Tisch und wieder zurück“ -- „und trotzdem auch mit Knöpfen“):
// am Tisch sortieren laesst sich eine Karte zusaetzlich zum Klick auf den Vergleichstisch und von dort zurueck in die
// Reihe ziehen -- mit Zeiger-Ereignissen (Maus, Finger, Stift), ueber denselben Codeweg wie Klick und Knopf.
// „als Python zeigen“ gibt es nur, wo der Schritt python="ja" traegt (nachbarn, halbieren): Aus Plaetzen werden Indizes.
// Einbinden: Werkstaetten.karten(element, {tisch: "sortieren"} | {tische: "sortieren|zaehlen"})
//   -> { zustand, film: {spielen, herstellen, laeuft} }
// Film (bauen.py, WERKSTATT_FILM): + vergleiche: 3 6 · + tausche · + aufdecken · + karten: 16 · + paar · + weiter ·
//   + durchgang · + schaetze: 30 · + lauf · + suche: 1418 · + decke: 8 · + python · + neu · + halt
window.Werkstaetten = window.Werkstaetten || {};
window.Werkstaetten.karten = function (wurzel, opt) {
  opt = opt || {};
  // die zwanzig Mitglieder in der Reihenfolge ihrer Anmeldung -- dieselben wie in rangliste/mitglieder.py
  const MITGLIEDER = [["Aylin", 1480], ["Bence", 1215], ["Chiara", 1630], ["Dawit", 1342], ["Emre", 1105], ["Finja", 1577], ["Goran", 1290],
    ["Hanh", 1418], ["Ilias", 1048], ["Jule", 1466], ["Kofi", 1712], ["Liv", 1322], ["Milan", 1189], ["Nuria", 1540], ["Oskar", 1401],
    ["Pari", 1273], ["Quinn", 1433], ["Rosa", 1163], ["Samir", 1502], ["Tuana", 1251]];
  // fuer den Tisch zaehlen: bis 64 Karten -- die zwanzig, danach Wertungen aus einer festen Folge (kein Zufall im Vortrag)
  const VIELE = MITGLIEDER.map(m => m[1]);
  for (let i = 20, x = 7; i < 64; i++) { x = (x * 73 + 41) % 997; VIELE.push(1000 + x); }
  // halbieren: sortiert, mit Luecken und einer Wertung, die zweimal vorkommt
  const SORTIERT = [1048, 1105, 1163, 1215, 1215, 1290, 1342, 1377, 1418, 1466, 1502, 1540, 1577, 1630, 1712];
  const SUCHEN = [1418, 1105, 1630, 1215, 1540];
  const NAMEN = { sortieren: "Sortieren", zaehlen: "Zählen", nachbarn: "Nur Nachbarn", halbieren: "Halbieren" };
  const STUFEN = [4, 8, 16, 32, 64];
  const tische = String(opt.tische || opt.tisch || "sortieren").split("|").map(t => t.trim()).filter(t => NAMEN[t]);
  if (!tische.length) tische.push("sortieren");
  const mitPython = opt.python === "ja";

  const h = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };
  const knopf = (text, cls, fn) => { const b = h("button", cls || "", text); b.type = "button"; b.onclick = fn; return b; };
  const platz = i => i + 1;

  let tisch = tische[0];
  const eigen = {};             // was das Paar am Tisch sortieren geschafft hat: Karten -> Vergleiche (fuer den Tisch zaehlen)
  let z = neu(tisch);

  function neu(t, behalte) {
    if (t === "sortieren" || t === "nachbarn") {
      const n = behalte && behalte.n || parseInt(opt.karten, 10) || 8;
      return { tisch: t, n, reihe: (behalte && behalte.start || MITGLIEDER.slice(0, n).map((m, i) => i)).slice(), start: behalte && behalte.start || MITGLIEDER.slice(0, n).map((m, i) => i),
        wahl: [], vergleiche: 0, tausche: 0, offen: false, urteil: "", protokoll: [], zeiger: 0, fest: 0, durchgang: 1, verglichen: false, python: false };
    }
    if (t === "zaehlen") return { tisch: t, n: 4, geschaetzt: {}, eigen: Object.assign({}, eigen), bubble: {}, meldung: "" };
    return { tisch: t, ziel: behalte && behalte.ziel || SUCHEN[0], offen: [], links: 0, rechts: SORTIERT.length - 1, fragen: 0, gefunden: -1, urteil: "", protokoll: [], python: false };
  }
  const kopie = o => JSON.parse(JSON.stringify(o));

  // ─── rechnen ───────────────────────────────────────────────────────────────────────
  const wert = i => MITGLIEDER[z.reihe[i]][1];
  function schreibe(text, code) { z.protokoll.unshift(z.python && code ? code : text); if (z.protokoll.length > 60) z.protokoll.pop(); }
  function vergleiche(a, b) {
    if (z.offen || a === b) return;
    z.vergleiche++; z.wahl = [a, b]; z.verglichen = true;
    const hoeher = wert(a) > wert(b) ? a : b;
    z.urteil = z.python ? "liste[" + a + "].get_wertung() > liste[" + b + "].get_wertung()  →  " + (wert(a) > wert(b) ? "True" : "False")
      : "Platz " + platz(a) + " und Platz " + platz(b) + ": Die höhere Wertung liegt auf Platz " + platz(hoeher) + ".";
    schreibe(platz(a) + " ? " + platz(b) + " – höher: Platz " + platz(hoeher), "liste[" + a + "] > liste[" + b + "]: " + (wert(a) > wert(b) ? "True" : "False"));
  }
  function tausche() {
    if (z.offen || z.wahl.length !== 2) return;
    const [a, b] = z.wahl; [z.reihe[a], z.reihe[b]] = [z.reihe[b], z.reihe[a]]; z.tausche++;
    z.urteil = z.python ? "merke = liste[" + a + "]   liste[" + a + "] = liste[" + b + "]   liste[" + b + "] = merke" : "Getauscht: Platz " + platz(a) + " und Platz " + platz(b) + ".";
    schreibe(platz(a) + " ↔ " + platz(b) + " getauscht", "liste[" + a + "] ↔ liste[" + b + "]");
    if (z.tisch === "sortieren") z.wahl = [];
  }
  // Tisch sortieren: eine Karte der Reihe wählen (Klick oder auf den Tisch gezogen) -- die zweite ist ein Vergleich;
  // ihr leerer Platz angeklickt legt sie zurück, eine dritte räumt den Tisch
  function waehle(i) {
    if (z.offen || z.tisch !== "sortieren") return;
    if (z.wahl.includes(i)) z.wahl = z.wahl.filter(x => x !== i);
    else { if (z.wahl.length === 2) z.wahl = []; z.wahl.push(i); if (z.wahl.length === 2) vergleiche(z.wahl[0], z.wahl[1]); else { z.urteil = ""; z.verglichen = false; } }
  }
  // Tisch sortieren: eine Karte vom Vergleichstisch zurück auf ihren Platz (Klick auf die Karte dort oder in die Reihe gezogen)
  function zurueck(i) {
    if (z.offen || z.tisch !== "sortieren") return;
    z.wahl = z.wahl.filter(x => x !== i); z.urteil = ""; z.verglichen = false;
  }
  const sortiert = () => z.reihe.every((k, i) => !i || MITGLIEDER[z.reihe[i - 1]][1] <= MITGLIEDER[k][1]);
  function aufdecken() {
    if (z.offen) return;
    z.offen = true; z.wahl = [];
    const gut = sortiert();
    z.urteil = gut ? "Sortiert – mit " + z.vergleiche + (z.vergleiche === 1 ? " Vergleich" : " Vergleichen") + " und " + z.tausche + (z.tausche === 1 ? " Tausch." : " Täuschen.")
      : "Noch nicht sortiert. " + z.vergleiche + " Vergleiche, " + z.tausche + " Täusche.";
    if (gut && z.tisch === "sortieren") { eigen[z.n] = z.vergleiche; try { sessionStorage.setItem("lernraum.karten.eigen", JSON.stringify(eigen)); } catch (e) {} }
  }
  // Tisch nachbarn: das Paar am Zeiger
  const paarEnde = () => z.n - 1 - z.fest;                   // der letzte Platz, an dem noch ein Paar beginnt, ist paarEnde - 1
  function paar() { if (!z.offen && z.fest < z.n - 1) vergleiche(z.zeiger, z.zeiger + 1); }
  function weiter() {
    if (z.offen || z.fest >= z.n - 1) return;
    z.wahl = []; z.verglichen = false; z.zeiger++;
    if (z.zeiger >= paarEnde()) {
      z.fest++; z.zeiger = 0;
      if (z.fest >= z.n - 1) { z.fest = z.n; z.urteil = "Kein Paar mehr übrig – " + z.vergleiche + " Vergleiche."; schreibe("fertig nach " + (z.durchgang) + " Durchgängen"); }
      else { schreibe("Durchgang " + z.durchgang + " zu Ende – Platz " + platz(z.n - z.fest) + " liegt fest"); z.durchgang++; z.urteil = "Durchgang " + z.durchgang + ": Die letzte Karte liegt fest."; }
    } else z.urteil = "";
  }
  function durchgang() {
    if (z.offen || z.fest >= z.n - 1) return;
    const d = z.durchgang;
    while (z.durchgang === d && z.fest < z.n - 1) { paar(); if (wert(z.zeiger) > wert(z.zeiger + 1)) tausche(); weiter(); }
  }
  // Tisch zaehlen: der Bubblesort mit zwei Schleifen, ohne fruehen Abbruch -- gezaehlt, nicht ausgerechnet
  function bubbleZaehlen(n) {
    const a = VIELE.slice(0, n); let v = 0;
    for (let d = 0; d < n - 1; d++) for (let i = 0; i < n - 1 - d; i++) { v++; if (a[i] > a[i + 1]) { const m = a[i]; a[i] = a[i + 1]; a[i + 1] = m; } }
    return v;
  }
  function lauf() {
    if (z.geschaetzt[z.n] == null || z.geschaetzt[z.n] === "") { z.meldung = "Erst schätzen: Wie viele Vergleiche braucht der Bubblesort bei " + z.n + " Karten?"; return; }
    z.bubble[z.n] = bubbleZaehlen(z.n); z.meldung = z.n + " Karten: " + z.bubble[z.n] + " Vergleiche.";
  }
  // Tisch halbieren
  function decke(i) {
    if (z.gefunden >= 0 || z.links > z.rechts || z.offen.includes(i) || i < 0 || i >= SORTIERT.length) return;
    z.offen.push(i); z.fragen++;
    const w = SORTIERT[i];
    if (w === z.ziel) { z.gefunden = i; z.urteil = "Platz " + platz(i) + " zeigt " + w + ": gefunden – nach " + z.fragen + (z.fragen === 1 ? " Frage." : " Fragen."); schreibe("Platz " + platz(i) + ": " + w + " – gefunden", "liste[" + i + "] == " + z.ziel); return; }
    if (w < z.ziel) { z.links = Math.max(z.links, i + 1); z.urteil = "Platz " + platz(i) + " zeigt " + w + ": zu niedrig – alles links davon fällt weg."; schreibe("Platz " + platz(i) + ": " + w + " – zu niedrig", "liste[" + i + "] < " + z.ziel + ": links = " + (i + 1)); }
    else { z.rechts = Math.min(z.rechts, i - 1); z.urteil = "Platz " + platz(i) + " zeigt " + w + ": zu hoch – alles rechts davon fällt weg."; schreibe("Platz " + platz(i) + ": " + w + " – zu hoch", "liste[" + i + "] > " + z.ziel + ": rechts = " + (i - 1)); }
    if (z.links > z.rechts) z.urteil += " Kein Platz bleibt: Die Wertung " + z.ziel + " gibt es nicht.";
  }

  // ─── zeichnen ──────────────────────────────────────────────────────────────────────
  wurzel.textContent = "";
  wurzel.classList.add("kartentisch");
  const reiter = h("div", "kt-reiter"), flaeche = h("div", "kt-flaeche");
  if (tische.length > 1) wurzel.append(reiter);
  wurzel.append(flaeche);
  function wechsle(t) { tisch = t; z = neu(t); zeichnen(); }

  function zaehler(...paare) { const d = h("div", "kt-zaehler"); for (const [name, zahl] of paare) { const k = h("div"); k.append(h("small", "", name), h("strong", "", String(zahl))); d.append(k); } return d; }
  function protokollEl() { const u = h("ul", "kt-protokoll" + (z.python ? " code" : "")); z.protokoll.forEach(t => u.append(h("li", "", t))); return u; }
  let eng = false;
  function karte(inhalt, i, cls, fn) {
    const k = knopf("", "kt-karte " + cls, fn);
    if (inhalt) k.append(h("span", "kt-name", inhalt[0]), h("span", "kt-wert", String(inhalt[1])));
    // enge Reihe (mehr als 8 Karten): unter den Karten nur die Zahl -- „Platz 10“ bis „Platz 15“ lagen übereinander (Fotos iq1 halbieren, 16.11.)
    k.append(h("span", "kt-platz", (z.python ? "[" + i + "]" : (eng && i > 0 ? "" : "Platz ") + platz(i))));
    k.setAttribute("aria-label", (inhalt ? inhalt[0] + " " + inhalt[1] + ", " : "verdeckte Karte, ") + "Platz " + platz(i));
    return k;
  }
  function pillen(aktiv, fn, werte) { const d = h("div", "kt-pillen"); d.append(h("span", "", "Karten")); (werte || STUFEN).forEach(n => d.append(knopf(String(n), "kt-pille" + (n === aktiv ? " an" : ""), () => fn(n)))); return d; }

  // Karten gleiten sichtbar an ihren neuen Ort (Durchsicht iq1, 16.11.2026: „Das Tauschen sollte visuell animiert
  // werden“ · „Das Tauschen/Anschauen etc. sollte klarer animiert werden“): Die Fläche wird bei jedem Schritt neu
  // gezeichnet; jede Karte trägt ihre Kennung (data-karte), und wer danach woanders liegt, fährt von der alten Lage
  // dorthin -- vom Platz auf den Vergleichstisch, über Kreuz beim Tausch, zurück in die Reihe.
  const ohneBewegung = !!(window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches);
  function lagen() { const m = new Map(); flaeche.querySelectorAll("[data-karte]").forEach(e => m.set(e.dataset.karte, e.getBoundingClientRect())); return m; }
  function gleiten(vorher) {
    if (ohneBewegung || !vorher.size) return;
    flaeche.querySelectorAll("[data-karte]").forEach(e => {
      const a = vorher.get(e.dataset.karte); if (!a || !e.animate) return;
      const b = e.getBoundingClientRect(), dx = a.left - b.left, dy = a.top - b.top;
      if (!b.width || (Math.abs(dx) < 1 && Math.abs(dy) < 1)) return;
      e.animate([{ transformOrigin: "0 0", transform: "translate(" + dx + "px, " + dy + "px) scale(" + (a.width / b.width) + ")", zIndex: 3 }, { transformOrigin: "0 0", transform: "none", zIndex: 3 }],
        { duration: 560, easing: "cubic-bezier(.2,.7,.3,1)" });
    });
  }
  // ─── ziehen (16.11.2026) ──────────────────────────────────────────────────────────
  // Zeiger-Ereignisse statt der Drag-and-Drop-Schnittstelle von HTML5: Die kennt den Finger am Tablet nicht. Ein Druck,
  // der sich weniger als die Schwelle bewegt, bleibt ein Klick (der Browser schickt click, onclick tut das Übrige). Was das
  // Loslassen bewirkt, entscheiden dieselben Funktionen wie Klick und Knopf: waehle(), zurueck(), tausche().
  //   Reihe → Tisch:  über dem Vergleichstisch loslassen = die Karte anklicken
  //   Tisch → Reihe:  über der Reihe loslassen = die Karte dort anklicken (nur sie geht zurück, auf ihren Platz);
  //                   über dem leeren Platz der ANDEREN Karte loslassen = „tauschen“
  //   daneben loslassen: Die Karte gleitet zurück, nichts ist geschehen.
  // Schwelle in Pixeln: Der Finger wackelt beim Tippen mehr als die Maus -- ein Tipp soll nicht als abgebrochener Zug enden
  const SCHWELLE = 6, SCHWELLE_FINGER = 10;
  let zug = null;               // {el, art: "reihe"|"tisch", i, id, x0, y0, schwelle, los, geist}
  let geschluckt = 0;           // wann der letzte Zug endete -- der click, den der Browser danach schickt, zählt nicht
  const nachZug = ev => { const ja = geschluckt > 0 && ev.detail > 0 && Date.now() - geschluckt < 500; geschluckt = 0; return ja; };
  const andere = () => zug && zug.art === "tisch" && z.wahl.length === 2 ? z.wahl.find(x => x !== zug.i) : null;
  const leerplatz = i => i == null ? null : flaeche.querySelector('.kt-karte.leerplatz[data-platz="' + i + '"]');
  // Großzügige Ziele (Lehrer 17.11.2026: „die Karten rasten nur bei genauem Zielen ein -- wenn man zu schnell oder etwas
  // zu ungenau ist, klappt es nicht“): Es zählt nicht nur die Spitze des Zeigers, sondern auch die gezogene Karte selbst
  // (ihre Mitte, oder dass sie das Ziel überhaupt berührt), und um jedes Ziel liegt ein Rand, der mitzählt -- zur
  // anderen Zone hin bis an deren Kante, damit die Lücke zwischen Reihe und Tisch nicht ins Leere führt; nach unten
  // reicht der Tisch über Urteilszeile und Knöpfe, damit ein schneller Wurf über das Ziel hinaus noch ankommt.
  const RAND = 48, UNTEN = 140;
  const imFeld = (f, x, y) => x >= f.left && x <= f.right && y >= f.top && y <= f.bottom;
  const beruehrt = (a, b) => a.left < b.right && a.right > b.left && a.top < b.bottom && a.bottom > b.top;
  function zielBei(x, y) {
    const k = zug.el.getBoundingClientRect(), mx = (k.left + k.right) / 2, my = (k.top + k.bottom) / 2;
    const tisch = flaeche.querySelector(".kt-tisch"), reihe = flaeche.querySelector(".kt-reihe");
    if (!tisch || !reihe) return null;
    const t = tisch.getBoundingClientRect(), r = reihe.getBoundingClientRect();
    const trifft = (feld, echt) => imFeld(feld, x, y) || imFeld(feld, mx, my) || beruehrt(k, echt);
    if (zug.art === "reihe") {
      const feld = { left: t.left - RAND, right: t.right + RAND, top: Math.min(t.top - RAND, r.bottom), bottom: t.bottom + UNTEN };
      return trifft(feld, t) ? "tisch" : null;
    }
    const feld = { left: r.left - RAND, right: r.right + RAND, top: r.top - RAND, bottom: Math.max(r.bottom + RAND, t.top) };
    if (!trifft(feld, r)) return null;
    // Tauschen: Die Mitte der Karte liegt über dem leeren Platz der anderen (mit einer halben Kartenbreite Spiel) --
    // und näher an ihm als am eigenen Platz, damit bei vielen schmalen Karten das Zurücklegen nicht zum Tausch wird
    const p = leerplatz(andere()), e = leerplatz(zug.i);
    if (p) {
      const pr = p.getBoundingClientRect(), spiel = (pr.right - pr.left) / 2, pm = (pr.left + pr.right) / 2;
      const em = e ? (e.getBoundingClientRect().left + e.getBoundingClientRect().right) / 2 : Infinity;
      if (mx >= pr.left - spiel && mx <= pr.right + spiel && Math.abs(mx - pm) < Math.abs(mx - em)) return "tausch";
    }
    return "zurueck";
  }
  function markiere(ziel) {
    flaeche.querySelectorAll(".drueber").forEach(e => e.classList.remove("drueber"));
    if (ziel === "tisch") {
      const t = flaeche.querySelector(".kt-tisch"), frei = t.querySelectorAll(".kt-ablage")[z.wahl.length === 1 ? 1 : 0];
      t.classList.add("drueber"); if (frei) frei.classList.add("drueber");
    } else if (ziel) { const p = leerplatz(ziel === "tausch" ? andere() : zug.i); if (p) p.classList.add("drueber"); }
  }
  function zugBeginnt() {
    zug.los = true;
    // eine Karte, die noch gleitet oder pulst, folgt sonst nicht dem Zeiger
    if (zug.el.getAnimations) zug.el.getAnimations().forEach(a => a.cancel());
    zug.el.classList.add("zieht");
    if (zug.art === "reihe") {
      flaeche.querySelector(".kt-tisch").classList.add("kt-ziel");
      // wo die Karte lag, bleibt ihr leerer Platz stehen: ein Umriss, der gegen den Zug verschoben wird
      zug.geist = h("span", "kt-geist"); zug.el.append(zug.geist);
    }
    else {
      const eigen = leerplatz(zug.i), fremd = leerplatz(andere());
      if (eigen) eigen.classList.add("kt-ziel");
      if (fremd) { fremd.classList.add("kt-ziel"); fremd.append(h("span", "kt-tauschziel", "tauschen")); }
    }
  }
  // einen laufenden Zug ohne Wirkung beenden (vor jedem Zeichnen, bei pointercancel)
  function zugLoesen() {
    if (!zug) return;
    const g = zug; zug = null;
    try { g.el.releasePointerCapture(g.id); } catch (e) {}
    if (!g.los) return;
    g.el.classList.remove("zieht"); g.el.style.transform = ""; if (g.geist) g.geist.remove();
    flaeche.querySelectorAll(".kt-ziel, .drueber").forEach(e => e.classList.remove("kt-ziel", "drueber"));
    flaeche.querySelectorAll(".kt-tauschziel").forEach(e => e.remove());
  }
  function zugEndet(ev, gilt) {
    if (!zug || ev.pointerId !== zug.id) return;
    if (!zug.los) { zugLoesen(); return; }                 // kein Zug, ein Klick
    // ein schneller Zug: Das Loslassen kann weiter sein als die letzte Bewegung -- die Karte erst dorthin setzen
    if (gilt) { const dx = ev.clientX - zug.x0, dy = ev.clientY - zug.y0; zug.el.style.transform = "translate(" + dx + "px, " + dy + "px)"; }
    const g = zug, ziel = gilt ? zielBei(ev.clientX, ev.clientY) : null;
    geschluckt = Date.now();
    if (!ziel) { const vorher = lagen(); zugLoesen(); gleiten(vorher); return; }
    // die Karte bleibt bis zum Zeichnen, wo sie losgelassen wurde: Von dort gleitet sie an ihren Ort
    zug = null; try { g.el.releasePointerCapture(g.id); } catch (e) {}
    if (ziel === "tisch") waehle(g.i); else if (ziel === "tausch") tausche(); else zurueck(g.i);
    zeichnen();
  }
  function ziehbar(el, art, i) {
    el.classList.add("ziehbar");
    // die Karte kann beim Loslassen schon aus der Seite genommen sein (neu gezeichnet) -- dann erreicht der click nur noch sie
    const klick = el.onclick; el.onclick = ev => { if (!nachZug(ev)) klick.call(el, ev); };
    el.addEventListener("pointerdown", ev => {
      if (ev.button !== 0 || ev.isPrimary === false) return;
      zugLoesen();                                         // ein Zug, dessen Ende nie ankam, sperrt nichts
      zug = { el, art, i, id: ev.pointerId, x0: ev.clientX, y0: ev.clientY, schwelle: ev.pointerType === "touch" ? SCHWELLE_FINGER : SCHWELLE, los: false };
      try { el.setPointerCapture(ev.pointerId); } catch (e) {}
    });
    el.addEventListener("pointermove", ev => {
      if (!zug || zug.el !== el || ev.pointerId !== zug.id) return;
      const dx = ev.clientX - zug.x0, dy = ev.clientY - zug.y0;
      if (!zug.los) { if (Math.hypot(dx, dy) < zug.schwelle) return; zugBeginnt(); }
      el.style.transform = "translate(" + dx + "px, " + dy + "px)";
      if (zug.geist) zug.geist.style.transform = "translate(" + -dx + "px, " + -dy + "px)";
      markiere(zielBei(ev.clientX, ev.clientY));
    });
    el.addEventListener("pointerup", ev => { if (zug && zug.el === el) zugEndet(ev, true); });
    el.addEventListener("pointercancel", ev => { if (zug && zug.el === el) zugEndet(ev, false); });
    el.addEventListener("lostpointercapture", ev => { if (zug && zug.el === el) zugEndet(ev, false); });
  }
  // nach einem Zug schickt der Browser noch einen click (Maus: sofort; Finger: bei kleinem Weg) -- der ist kein Klick.
  // Tastatur und click() aus einem Skript (detail 0) gehen durch, ebenso jeder Klick nach einem neuen Druck.
  flaeche.addEventListener("pointerdown", () => { geschluckt = 0; }, true);
  flaeche.addEventListener("click", ev => { if (nachZug(ev)) { ev.stopPropagation(); ev.preventDefault(); } }, true);

  function zeichnen() {
    zugLoesen();
    const vorher = lagen();
    reiter.replaceChildren(...tische.map(t => knopf(NAMEN[t], t === tisch ? "aktiv" : "", () => wechsle(t))));
    flaeche.replaceChildren();
    flaeche.className = "kt-flaeche kt-" + z.tisch;
    if (z.tisch === "sortieren" || z.tisch === "nachbarn") zeichneReihe();
    else if (z.tisch === "zaehlen") zeichneZaehlen();
    else zeichneHalbieren();
    tischWieReihe();
    gleiten(vorher);
  }
  // Die Karten auf dem Vergleichstisch sind so groß wie die in der Reihe (Lehrer 17.11.2026: „verwirrend finde ich nur,
  // dass im Browser die Tischkarten viel kleiner sind als die Karten am Platz und in der Vorschau in VS Code ist es
  // andersrum“). Die Reihe teilt sich die Breite (höchstens 5.8em je Karte), die Ablage war fest 3.5em -- breit war die
  // Reihe größer, schmal kleiner. Jetzt misst die Werkstatt eine Karte der Reihe und gibt ihre Breite an den Tisch weiter,
  // nach jedem Zeichnen und wenn sich die Breite der Werkstatt ändert.
  function tischWieReihe() {
    const k = flaeche.querySelector(".kt-reihe .kt-karte");
    if (!k) { flaeche.style.removeProperty("--kt-kartenbreite"); return; }
    const b = k.getBoundingClientRect().width;
    if (b > 0) flaeche.style.setProperty("--kt-kartenbreite", b.toFixed(1) + "px");
  }
  // nur auf die BREITE der Werkstatt hören, und erst im nächsten Bild messen: Die neue Ablagenbreite ändert die Höhe der
  // Fläche -- ein Beobachter, der darauf wieder misst, liefe im Kreis („ResizeObserver loop …“, als Skriptfehler gemeldet)
  let breiteZuletzt = -1;
  if (typeof ResizeObserver === "function") new ResizeObserver(eintraege => {
    const b = Math.round(eintraege[eintraege.length - 1].contentRect.width);
    if (b === breiteZuletzt) return;
    breiteZuletzt = b;
    requestAnimationFrame(() => { if (!zug) tischWieReihe(); });
  }).observe(flaeche);
  // Der Vergleichstisch (Durchsicht iq1, 16.11.2026: „Ich hätte gerne einen Tisch, auf den man zwei Karten legen kann
  // und das Programm zeigt an, welche Karte größer ist“): Die zwei gewählten Karten liegen hier, verdeckt; zwischen
  // ihnen steht das Zeichen, über der höheren „höher“. Ein Klick auf eine Karte legt sie zurück (sortieren) -- ebenso,
  // wer sie in die Reihe zieht.
  function tischEl(nachbarn) {
    const t = h("div", "kt-tisch"), [a, b] = z.wahl;
    const hoeher = z.verglichen && z.wahl.length === 2 ? (wert(a) > wert(b) ? a : b) : null;
    const ablage = (i, text) => {
      const d = h("div", "kt-ablage");
      if (i == null) { d.append(h("span", "kt-ablage-leer", text)); return d; }
      const k = knopf("", "kt-tischkarte" + (i === hoeher ? " hoeher" : ""), () => { if (nachbarn) return; zurueck(i); zeichnen(); });
      k.dataset.karte = String(z.reihe[i]);
      k.append(h("span", "kt-platz", z.python ? "[" + i + "]" : "Platz " + platz(i)));
      if (i === hoeher) k.append(h("span", "kt-hoeher", "höher"));
      if (!nachbarn) { k.title = "zurücklegen – anklicken oder in die Reihe ziehen"; ziehbar(k, "tisch", i); }
      k.setAttribute("aria-label", "verdeckte Karte von Platz " + platz(i) + " auf dem Vergleichstisch" + (i === hoeher ? ", die höhere" : ""));
      d.append(k); return d;
    };
    t.append(h("span", "kt-tischname", "Vergleichstisch"), ablage(a, nachbarn ? "links" : "erste Karte"),
      h("span", "kt-zeichen" + (hoeher == null ? " offen" : ""), hoeher == null ? "?" : hoeher === a ? ">" : "<"), ablage(b, nachbarn ? "rechts" : "zweite Karte"));
    return t;
  }
  function zeichneReihe() {
    const nachbarn = z.tisch === "nachbarn";
    const links = h("div", "kt-links"), seite = h("div", "kt-seite");
    links.append(h("p", "kt-auftrag", nachbarn ? "Verglichen wird nur das Paar am Zeiger. Nach jedem Durchgang liegt hinten eine Karte mehr fest."
      : "Zwei Karten anklicken oder ziehen: Sie kommen auf den Vergleichstisch, und er zeigt, welche die höhere Wertung hat. Sortiert heißt: die niedrigste Wertung auf Platz 1."));
    // die Wahl 4 · 8 · 16 nur, wo der Schritt keine feste Kartenzahl nennt (karten="4" im Vortrag)
    if (!nachbarn && !opt.karten) links.append(pillen(z.n, n => { z = neu("sortieren", { n }); zeichnen(); }, [4, 8, 16]));
    eng = z.n > 8;
    const reihe = h("div", "kt-reihe" + (eng ? " viele" : ""));
    z.reihe.forEach((k, i) => {
      // eine gewählte Karte liegt auf dem Vergleichstisch -- in der Reihe bleibt ihr leerer Platz (anklicken legt sie zurück)
      const gehoben = !z.offen && z.wahl.includes(i);
      const cls = (gehoben ? "leerplatz" : z.offen ? "auf" : "zu") + (nachbarn && i >= z.n - z.fest ? " fest" : "");
      const el = karte(z.offen ? MITGLIEDER[k] : null, i, cls, () => {
        if (z.offen || nachbarn) return;
        waehle(i);
        zeichnen();
      });
      if (!gehoben) el.dataset.karte = String(k);
      el.dataset.platz = String(i);
      // ziehen darf, wer klicken darf: eine verdeckte Karte am Tisch sortieren (nicht der leere Platz, nicht „nur Nachbarn“)
      if (!gehoben && !z.offen && !nachbarn) ziehbar(el, "reihe", i);
      if (nachbarn && !z.offen && z.fest < z.n - 1 && (i === z.zeiger || i === z.zeiger + 1)) { el.classList.add("zeiger"); el.append(h("span", "kt-zeiger", i === z.zeiger ? "links" : "rechts")); }
      reihe.append(el);
    });
    links.append(reihe);
    if (!z.offen && !(nachbarn && z.fest >= z.n - 1)) links.append(tischEl(nachbarn));
    links.append(h("div", "kt-urteil" + (z.python ? " code" : "") + (z.urteil ? "" : " leer"), z.urteil || (nachbarn ? "Durchgang " + z.durchgang + ": vergleichen, wenn nötig tauschen, weiter." : z.wahl.length ? "Noch eine Karte." : "Wählt zwei Karten.")));
    const kn = h("div", "kt-knoepfe");
    const fertig = z.offen || (nachbarn && z.fest >= z.n);
    if (nachbarn) {
      const b1 = knopf("vergleichen", "", () => { paar(); zeichnen(); }), b2 = knopf("tauschen", "primaer", () => { tausche(); zeichnen(); }), b3 = knopf("weiter", "", () => { weiter(); zeichnen(); }), b4 = knopf("ganzer Durchgang", "", () => { durchgang(); zeichnen(); });
      b1.disabled = z.offen || z.fest >= z.n - 1 || z.verglichen; b2.disabled = z.offen || !z.verglichen || z.wahl.length !== 2; b3.disabled = b4.disabled = z.offen || z.fest >= z.n - 1;
      kn.append(b1, b2, b3, b4);
    } else {
      const b = knopf("tauschen", "primaer", () => { tausche(); zeichnen(); }); b.disabled = z.offen || z.wahl.length !== 2;
      // zurücklegen (Durchsicht 16.11.: „Man muss Karten, die man ausgewählt hat, mühsam wieder abwählen“)
      const zl = knopf("zurücklegen", "", () => { z.wahl = []; z.urteil = ""; z.verglichen = false; zeichnen(); }); zl.disabled = z.offen || !z.wahl.length;
      kn.append(b, zl);
    }
    const auf = knopf("aufdecken – sortiert?", "", () => { aufdecken(); zeichnen(); }); auf.disabled = z.offen;
    // „von vorn“ und „neu mischen“ ohne die ruhige Farbe (Durchsicht 16.11.: „sehen ausgegraut aus, als könne man es nicht anwählen“)
    kn.append(auf, knopf("von vorn", "", () => { z = neu(z.tisch, { n: z.n, start: z.start }); zeichnen(); }));
    if (!nachbarn) kn.append(knopf("neu mischen", "", () => { const s = z.start.slice(); for (let i = s.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [s[i], s[j]] = [s[j], s[i]]; } z = neu("sortieren", { n: z.n, start: s }); zeichnen(); }));
    if (mitPython) kn.append(knopf(z.python ? "in Worten zeigen" : "als Python zeigen", "", () => { z.python = !z.python; z.urteil = ""; zeichnen(); }));
    links.append(kn);
    if (fertig && z.offen && !sortiert()) links.append(h("p", "kt-hinweis", "„von vorn“ legt dieselben Karten wieder verdeckt hin."));
    seite.append(nachbarn ? zaehler(["Vergleiche", z.vergleiche], ["Täusche", z.tausche], ["Durchgang", Math.min(z.durchgang, z.n - 1)]) : zaehler(["Vergleiche", z.vergleiche], ["Täusche", z.tausche]), h("h3", "", "Protokoll"), protokollEl());
    flaeche.append(links, seite);
  }
  function zeichneZaehlen() {
    const links = h("div", "kt-links"), rechts = h("div", "kt-kurve");
    links.append(h("p", "kt-auftrag", "Dasselbe Verfahren mit mehr Karten: Was kostet es? Erst schätzen, dann zählt der Tisch den Bubblesort."), pillen(z.n, n => { z.n = n; z.meldung = ""; zeichnen(); }));
    const t = h("table", "kt-tabelle"), kopf = h("tr"); ["Karten", "geschätzt", "euer Verfahren", "Bubblesort"].forEach(x => kopf.append(h("th", "", x))); t.append(kopf);
    STUFEN.forEach(n => {
      const tr = h("tr", n === z.n ? "an" : ""); tr.append(h("td", "", String(n)));
      for (const feld of ["geschaetzt", "eigen"]) {
        const td = h("td"), ein = h("input"); ein.type = "text"; ein.inputMode = "numeric"; ein.value = z[feld][n] == null ? "" : z[feld][n];
        ein.setAttribute("aria-label", (feld === "eigen" ? "euer Verfahren" : "geschätzt") + " bei " + n + " Karten");
        ein.onchange = () => { const v = ein.value.trim(); z[feld][n] = /^\d+$/.test(v) ? parseInt(v, 10) : ""; if (feld === "eigen") eigen[n] = z.eigen[n]; zeichnen(); };
        td.append(ein); tr.append(td);
      }
      tr.append(h("td", "kt-bubble", z.bubble[n] == null ? "" : String(z.bubble[n]))); t.append(tr);
    });
    const kn = h("div", "kt-knoepfe"); kn.append(knopf("Bubblesort bei " + z.n + " Karten zählen", "primaer", () => { lauf(); zeichnen(); }), knopf("von vorn", "ruhig", () => { z = neu("zaehlen"); zeichnen(); }));
    links.append(t, kn, h("p", "kt-urteil" + (z.meldung ? "" : " leer"), z.meldung || "Doppelt so viele Karten – wie viel mehr Vergleiche?"));
    rechts.innerHTML = kurve();
    flaeche.append(links, rechts);
  }
  function kurve() {
    const B = 420, H = 280, L = 50, U = 232, R = 404, O = 20;
    const zahlen = k => Object.keys(z[k]).filter(n => z[k][n] !== "" && z[k][n] != null).map(n => [parseInt(n, 10), z[k][n]]);
    const pb = zahlen("bubble"), pe = zahlen("eigen"), alle = pb.concat(pe);
    const nMax = Math.max(16, ...alle.map(p => p[0])), vMax = Math.max(40, ...alle.map(p => p[1]), nMax);
    const x = n => L + (R - L) * n / nMax, y = v => U - (U - O) * v / vMax;
    let s = '<svg viewBox="0 0 ' + B + ' ' + H + '" role="img" aria-label="Vergleiche über der Zahl der Karten"><line class="achse" x1="' + L + '" y1="' + U + '" x2="' + R + '" y2="' + U + '"/><line class="achse" x1="' + L + '" y1="' + U + '" x2="' + L + '" y2="' + O + '"/>';
    STUFEN.filter(n => n <= nMax).forEach(n => { s += '<text class="zahl" x="' + x(n) + '" y="' + (U + 20) + '" text-anchor="middle">' + n + '</text>'; });
    s += '<text class="zahl" x="' + (L - 6) + '" y="' + (U + 4) + '" text-anchor="end">0</text><text class="zahl" x="' + (L - 6) + '" y="' + (O + 4) + '" text-anchor="end">' + vMax + '</text><text class="zahl" x="' + ((L + R) / 2) + '" y="' + (H - 6) + '" text-anchor="middle">Karten</text>';
    s += '<line class="gerade" x1="' + x(0) + '" y1="' + y(0) + '" x2="' + x(nMax) + '" y2="' + y(nMax) + '"/><text class="leg grau" x="' + (R - 4) + '" y="' + (y(nMax) - 8) + '" text-anchor="end">ein Vergleich je Karte</text>';
    if (pb.length >= 2) { pb.sort((a, b) => a[0] - b[0]); s += '<polyline class="linie" points="' + pb.map(p => x(p[0]) + "," + y(p[1])).join(" ") + '"/>'; }
    pb.forEach(p => { s += '<circle class="punkt" cx="' + x(p[0]) + '" cy="' + y(p[1]) + '" r="5.5"/>'; });
    pe.forEach(p => { s += '<rect class="eigen" x="' + (x(p[0]) - 5) + '" y="' + (y(p[1]) - 5) + '" width="10" height="10"/>'; });
    if (pb.length) s += '<text class="leg blau" x="' + (L + 14) + '" y="' + (O + 14) + '">● Bubblesort</text>';
    if (pe.length) s += '<text class="leg amber" x="' + (L + 14) + '" y="' + (O + 32) + '">■ euer Verfahren</text>';
    return s + "</svg>";
  }
  function zeichneHalbieren() {
    const links = h("div", "kt-links"), seite = h("div", "kt-seite");
    links.append(h("p", "kt-auftrag", "Sortiert und verdeckt. Jede aufgedeckte Karte ist eine Frage."), h("p", "kt-gesucht", "Gesucht: die Wertung " + z.ziel));
    eng = true;
    const reihe = h("div", "kt-reihe viele");
    SORTIERT.forEach((w, i) => {
      const auf = z.offen.includes(i), weg = !auf && (i < z.links || i > z.rechts || z.gefunden >= 0);
      reihe.append(karte(auf ? ["", w] : null, i, (auf ? "auf" : "zu") + (weg ? " weg" : "") + (i === z.gefunden ? " treffer" : auf ? " wahl" : ""), () => { decke(i); zeichnen(); }));
    });
    links.append(reihe, h("div", "kt-urteil" + (z.python ? " code" : "") + (z.urteil ? "" : " leer"), z.urteil || "Welche Karte deckt ihr zuerst auf?"));
    const kn = h("div", "kt-knoepfe");
    kn.append(knopf("neue Suche", "", () => { z = neu("halbieren", { ziel: SUCHEN[(SUCHEN.indexOf(z.ziel) + 1) % SUCHEN.length] }); zeichnen(); }),
      knopf("eine Wertung, die es nicht gibt", "", () => { z = neu("halbieren", { ziel: 1400 }); zeichnen(); }), knopf("von vorn", "ruhig", () => { z = neu("halbieren", { ziel: z.ziel }); zeichnen(); }));
    if (mitPython) kn.append(knopf(z.python ? "in Worten zeigen" : "als Python zeigen", "ruhig", () => { z.python = !z.python; zeichnen(); }));
    links.append(kn);
    seite.append(zaehler(["Fragen", z.fragen], ["noch möglich", z.gefunden >= 0 ? 1 : Math.max(0, z.rechts - z.links + 1)]), h("h3", "", "Protokoll"), protokollEl());
    flaeche.append(links, seite);
  }

  try { Object.assign(eigen, JSON.parse(sessionStorage.getItem("lernraum.karten.eigen") || "{}")); } catch (e) {}
  if (z.tisch === "zaehlen") z.eigen = Object.assign({}, eigen);
  zeichnen();

  // ─── Film (Vortrag, wie der Code-Film) ─────────────────────────────────────────────
  function filmSchritt(x) {
    const a = x.aktion, zahl = v => parseInt(v, 10);
    if (a === "neu") z = neu(z.tisch, z.tisch === "halbieren" ? { ziel: z.ziel } : { n: z.n, start: z.start });
    else if (a === "karten") { if (z.tisch === "zaehlen") { z.n = zahl(x.wert); z.meldung = ""; } else z = neu(z.tisch, { n: zahl(x.wert) }); }
    else if (a === "vergleiche") vergleiche(zahl(x.von) - 1, zahl(x.nach) - 1);
    else if (a === "tausche") tausche();
    else if (a === "aufdecken") aufdecken();
    else if (a === "paar") paar();
    else if (a === "weiter") weiter();
    else if (a === "durchgang") durchgang();
    else if (a === "schaetze") z.geschaetzt[z.n] = zahl(x.wert);
    else if (a === "lauf") lauf();
    else if (a === "suche") z = neu("halbieren", { ziel: zahl(x.wert) });
    else if (a === "decke") decke(zahl(x.wert) - 1);
    else if (a === "python") z.python = true;
  }
  function filmHerstellen(liste) { z = neu(tisch); if (z.tisch === "zaehlen") z.eigen = {}; liste.forEach(filmSchritt); zeichnen(); }
  return { zustand: () => kopie(z), film: { spielen: x => { filmSchritt(x); zeichnen(); }, herstellen: filmHerstellen, laeuft: () => false } };
};
window.Werkstaetten.karten.einleitung = "Mitgliedskarten des Schachportals, verdeckt: Der Tisch sagt nur, welche von zwei Karten die höhere Wertung hat – und zählt jeden Vergleich.";
