# weiss_alle.py -- die weiße Seite als ein Objekt.
# Die Figur kommt aus figur.py (gekapselt,
# dazu bildname()).

# erlaubt die eigene Klasse als Typ:
from __future__ import annotations
from zeichenflaeche import neue_flaeche, zeichne_bild, zeige
from figur import Figur

FELDGROESSE = 60
flaeche = neue_flaeche(8 * FELDGROESSE, 8 * FELDGROESSE)


def zeichne_felder() -> None:
    for zeile in range(8):
        for spalte in range(8):
            x = spalte * FELDGROESSE
            y = zeile * FELDGROESSE
            if (zeile + spalte) % 2 == 0:
                farbe = "#eeeed2"
            else:
                farbe = "#769656"
            flaeche.create_rectangle(x, y, x + FELDGROESSE, y + FELDGROESSE,
                                     fill=farbe, outline=farbe)


class Spieler:

    def __init__(self, farbe: str):
        self.__farbe = farbe
        self.__figuren: list[Figur] = []

    def aufnehmen(self, figur: Figur) -> None:
        self.__figuren.append(figur)

    def anzahl(self) -> int:
        return len(self.__figuren)

    def zeichne_alle(self, groesse: int) -> None:
        for figur in self.__figuren:
            x = figur.get_spalte() * groesse
            y = figur.get_zeile() * groesse
            zeichne_bild(figur.bildname(), x, y, groesse)


weiss = Spieler("weiß")
dame = Figur("Dame", "weiß", 7, 3)
weiss.aufnehmen(dame)
for spalte in range(8):
    weiss.aufnehmen(Figur("Bauer", "weiß", 6, spalte))
print(weiss.anzahl())

dame.ziehen(3, 3)
zeichne_felder()
weiss.zeichne_alle(FELDGROESSE)
zeige()
