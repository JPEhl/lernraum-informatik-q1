# mitte.py -- sieben Wertungen, sortiert:
# eine Frage der binären Suche.

wertungen = [1048, 1105, 1163, 1215, 1290, 1342, 1418]
gesucht = 1342

links = 0
rechts = len(wertungen) - 1
mitte = (links + rechts) // 2

if wertungen[mitte] == gesucht:
    print("gefunden auf Index", mitte)
elif wertungen[mitte] < gesucht:
    links = mitte + 1
else:
    rechts = mitte - 1

print(links, rechts)
