"""Selbstcheck „Suchen und Entfernen“ -- prueft das Programm im Ordner schach/ (es laeuft partie.py).

Der Spieler sucht und entfernt. Der Check prueft die Klasse Spieler ueber OBJEKTE, die er selbst baut (LC8): erzeuge,
rufe -- mit eigenen Figuren in eigener Reihenfolge, damit eine Antwort nicht zufaellig zur Aufstellung passt.

Seit dem Umbau nach Schnitt A (16.11.2026) bringt die Klasse finde_figur schon mit (aus „Objektlisten“: Sie geht alle
Figuren durch und merkt sich den Treffer). Neu ist, dass die Suche antwortet, SOBALD sie die Figur hat. Am Ergebnis
sieht man das nicht -- der Check gibt deshalb Figuren hinein, die mitzaehlen, wie oft sie gefragt werden (LC5:
Aufwand zaehlen). partie.py ist ein Programm mit Klick; das Brett liest der Check an einem FRISCHEN Lauf, auf dem er
klickt wie die Maus (klick_auf): Die Dame schlaegt einen Bauern (er ist weg, das Material sinkt), und in einer zweiten
Partie faellt ein Koenig (die Partie ist aus, kein Klick tut mehr etwas).

Fallen (LC5): `return None` im else antwortet nach der ersten Figur -- deshalb steht die gesuchte nie nur vorn. Zeile
und Spalte vertauscht -- deshalb (2, 5) und ein leeres (5, 2). Die Suche muss DASSELBE Objekt liefern (is). entferne
nimmt das uebergebene Objekt, nicht das erste gleicher Art -- deshalb zwei Bauern. hat_koenig mit `return False` im
else antwortet nach der ersten Figur -- deshalb steht der Koenig nie vorn. figuren_mit_wert: return in der Schleife
liefert eine Figur, `>` statt `>=` laesst die Tuerme bei 5 weg, wer die eigene Liste filtert, verliert Figuren.

Startzustand (Arbeitsordner, vorbereitet): partie.py laeuft, die Suche fragt immer alle. Offen ist genau Aufgabe 2 ★★
(★ ist der Plan auf der Seite), alles andere wartet (LC1).
"""
import ast
import importlib
import re
import sys

import pruefen
from pruefen import erwarte, braucht, arbeit, flaeche, quelltext, anspielen, erzeuge, rufe, attribute, klasse, \
    klick_auf

TITEL = "Suchen und Entfernen · Selbstcheck"
EINGABEN = []
HINTS = {"finde_figur": {"Figur"}, "entferne": {"None"}, "hat_koenig": {"bool"},
         "figuren_mit_wert": {"list[Figur]", "list"}}
DIAGRAMMTYPEN = {"String", "integer", "boolean", "Integer", "Boolean"}


class _Zaehlfigur:
    """Eine Figur, die mitzaehlt, wie oft sie nach ihrer Zeile gefragt wird (alle zusammen, in gefragt)."""
    gefragt = 0
    schlagfragen = 0

    def __init__(self, zeile, spalte, schlaegt=False, art="Bauer"):
        self._zeile, self._spalte, self._schlaegt, self._art = zeile, spalte, schlaegt, art

    def get_art(self):
        return self._art

    def get_farbe(self):
        return "schwarz"

    def get_wert(self):
        return 1

    def get_zeile(self):
        _Zaehlfigur.gefragt += 1
        return self._zeile

    def get_spalte(self):
        return self._spalte

    def bildname(self):
        return "bauer-s"

    def passt(self, zeile, spalte):
        return self._schlaegt

    def schlaegt(self, zeile, spalte):
        _Zaehlfigur.schlagfragen += 1
        return self._schlaegt


def _wo(feld):
    return "Zeile %d, Spalte %d" % tuple(feld)


def _spiel():
    """partie.py noch einmal, frisch. Gibt (Flaeche, Feldgroesse, letzte Fehlerzeile, Namen des Programms) -- die
    Flaeche ist None, wenn das Programm nicht bis zum Ende lief."""
    alt_q = pruefen._QUELLE
    pruefen._QUELLE = alt_q + "\nprint('--ENDE--')\n"
    try:
        aus, ns = anspielen([])
    finally:
        pruefen._QUELLE = alt_q
    zeilen = [z for z in aus.strip().splitlines() if z.strip() and "--ENDE--" not in z]
    fehler = zeilen[-1] if zeilen and "Error" in zeilen[-1] else ""
    return (ns.get("flaeche") if "--ENDE--" in aus else None), ns.get("FELDGROESSE"), fehler, ns


def _schon_aus(ns):
    """Sagt partie_vorbei() schon am Start Ja? Dann tut kein Klick etwas -- das ist ein Fehler von Aufgabe 3 ★★,
    nicht von ★ (LC3): pruefe_30 laesst dann das Brett aus, pruefe_35 meldet es."""
    f = ns.get("partie_vorbei")
    try:
        return callable(f) and bool(f())
    except Exception:  # noqa: BLE001 -- ein Absturz in partie_vorbei ist ebenfalls Sache von ★★
        return callable(f)


def _klick(c, feld, g):
    alt = pruefen._FENSTER
    pruefen._FENSTER = c.winfo_toplevel()
    try:
        return klick_auf(feld[1] * g + g // 2, feld[0] * g + g // 2, wo=_wo(feld))
    finally:
        pruefen._FENSTER = alt


def _bilder_auf(c, feld, g):
    """ALLE Bilder, die auf dem Feld liegen -- zwei Figuren auf einem Feld sind der Fehler dieses Themas."""
    aus = []
    for i in c.find_all():
        if c.type(i) == "image":
            k = c.coords(i)
            if (int(k[1]) // g, int(k[0]) // g) == tuple(feld):
                aus.append(pruefen._bilddatei(c, c.itemcget(i, "image")))
    return sorted(aus)


def _texte(c):
    return [str(c.itemcget(i, "text")) for i in c.find_all() if c.type(i) == "text"]


def _ok(pruefung):
    try:
        pruefung()
    except AssertionError:
        return False
    return True


def _spieler_mit(*figuren):
    """Ein eigener Spieler mit Figuren (art, zeile, spalte) -- gibt Spieler und die Figuren zurueck."""
    s = erzeuge("Spieler", "schwarz")
    fs = [erzeuge("Figur", art, "schwarz", zeile, spalte) for art, zeile, spalte in figuren]
    for f in fs:
        rufe(s, "aufnehmen", f)
    return s, fs


def _was(x, fs):
    """Was zurueckkam, in Worten: eine der eigenen Figuren als „Springer (2, 1)“, sonst repr."""
    for f in fs:
        if x is f:
            return "%s (%s, %s)" % (rufe(f, "get_art"), rufe(f, "get_zeile"), rufe(f, "get_spalte"))
    return "eine andere Figur" if type(x).__name__ == "Figur" else repr(x)


def _findet():
    k = klasse("Spieler")
    if k is None or not hasattr(k, "finde_figur"):
        return False
    return _ok(pruefe_20_finde)


def pruefe_00_grundlage():
    """Grundlage · figur.py und spieler.py laden, das Programm hat eine Zeichenfläche"""
    erwarte(klasse("Figur") is not None, "In figur.py steht keine Klasse Figur mehr -- seht in der Shell nach.")
    erwarte(klasse("Spieler") is not None, "In spieler.py steht keine Klasse Spieler mehr -- seht in der Shell nach.")
    erwarte(flaeche() is not None, "Das Programm bricht ab, bevor es eine Zeichenfläche hat -- seht in der Shell nach.")
    g = getattr(arbeit(), "FELDGROESSE", None)
    erwarte(isinstance(g, int) and g > 0, "FELDGROESSE ist keine ganze Zahl über 0 -- oben in partie.py.")


def pruefe_20_finde():
    """Aufgabe 2 ★★ · Der Spieler findet die Figur auf einem Feld -- oder sagt None"""
    erwarte(hasattr(klasse("Spieler"), "finde_figur"), "In spieler.py fehlt finde_figur(zeile, spalte).")
    s, fs = _spieler_mit(("Turm", 0, 0), ("Springer", 2, 1), ("Bauer", 2, 5), ("Dame", 7, 3), ("Läufer", 4, 4))
    liste = "Turm (0, 0), Springer (2, 1), Bauer (2, 5), Dame (7, 3), Läufer (4, 4)"
    vorn = rufe(s, "finde_figur", 0, 0)
    erwarte(vorn is fs[0], "%s: finde_figur(0, 0) gibt %s zurück statt des Turms, der aufgenommen wurde."
            % (liste, _was(vorn, fs)))
    for z, sp in ((5, 2), (0, 4), (6, 6)):
        leer = rufe(s, "finde_figur", z, sp)
        erwarte(leer is None, "%s: Auf (%d, %d) steht niemand -- finde_figur gibt aber %s zurück. Werden Zeile UND "
                "Spalte verglichen, jede mit dem richtigen Parameter?" % (liste, z, sp, _was(leer, fs)))
    mitte = rufe(s, "finde_figur", 2, 5)
    erwarte(mitte is not None, "%s: finde_figur(2, 5) gibt None zurück, obwohl dort der Bauer steht. Antwortet die "
            "Suche schon nach der ersten Figur, die nicht passt?" % liste)
    erwarte(mitte is fs[2], "%s: finde_figur(2, 5) gibt %s zurück statt des Bauern -- werden Zeile UND Spalte "
            "verglichen?" % (liste, _was(mitte, fs)))
    hinten = rufe(s, "finde_figur", 4, 4)
    erwarte(hinten is fs[4], "finde_figur(4, 4) findet den Läufer nicht, der zuletzt in der Liste steht (zurück kommt "
            "%s). Fragt die Suche wirklich alle?" % _was(hinten, fs))
    nichts, _ = _spieler_mit()
    erwarte(rufe(nichts, "finde_figur", 0, 0) is None, "Ein Spieler ohne Figuren: finde_figur(0, 0) gibt nicht None "
            "zurück. Steht return None hinter der Schleife?")
    # ... und sie antwortet, SOBALD sie die Figur hat: Fuenf Figuren, die mitzaehlen, wie oft sie gefragt werden
    _Zaehlfigur.gefragt = 0
    zaehler = erzeuge("Spieler", "schwarz")
    for spalte in range(5):
        rufe(zaehler, "aufnehmen", _Zaehlfigur(0, spalte))
    rufe(zaehler, "finde_figur", 0, 0)
    erwarte(_Zaehlfigur.gefragt == 1, "Fünf Figuren, die gesuchte steht vorn: finde_figur findet sie -- und fragt "
            "trotzdem %d Figuren. Gefunden heißt: sofort antworten." % _Zaehlfigur.gefragt)
    _Zaehlfigur.gefragt = 0
    rufe(zaehler, "finde_figur", 0, 2)
    erwarte(_Zaehlfigur.gefragt == 3, "Fünf Figuren, die gesuchte steht an dritter Stelle: finde_figur fragt %d "
            "Figuren statt drei." % _Zaehlfigur.gefragt)


def _entfernt():
    """Der Teil von Aufgabe 3 ★, der die KLASSE prueft."""
    erwarte(hasattr(klasse("Spieler"), "entferne"), "Die Suche stimmt. Eine Figur hergeben kann der Spieler noch "
            "nicht -- entferne fehlt in spieler.py.")
    s, fs = _spieler_mit(("Bauer", 1, 0), ("Turm", 0, 0), ("Bauer", 1, 1))
    rufe(s, "entferne", fs[2])
    erwarte(rufe(s, "anzahl") == 2, "Nach entferne hat der Spieler %r Figuren statt 2." % (rufe(s, "anzahl"),))
    erwarte(rufe(s, "finde_figur", 1, 1) is None and rufe(s, "finde_figur", 1, 0) is fs[0],
            "Bauer (1, 0), Turm, Bauer (1, 1): entferne mit dem Bauern auf (1, 1) nimmt den falschen Bauern -- entfernt "
            "wird genau das Objekt, das übergeben wird.")


def pruefe_30_schlagen():
    """Aufgabe 3 · Wer auf eine fremde Figur zieht, schlägt sie -- sie ist vom Brett, das Material sinkt"""
    braucht(_findet(), "Erst antwortet die Suche sofort (Aufgabe 2 ★★).")
    _entfernt()
    c, g, fehler, ns = _spiel()
    erwarte(c is not None, "partie.py bricht ab, bevor das Brett fertig ist%s." % (" (%s)" % fehler if fehler else ""))
    if _schon_aus(ns):
        return
    _klick(c, (7, 3), g)
    shell = _klick(c, (1, 3), g)
    dort = _bilder_auf(c, (1, 3), g)
    erwarte("dame-w.png" in dort, "Die weiße Dame ist gewählt; ein Klick auf den schwarzen Bauern auf Zeile 1, "
            "Spalte 3 lässt sie nicht dorthin ziehen.")
    erwarte(dort == ["dame-w.png"], "Die Dame ist auf Zeile 1, Spalte 3 gezogen, und der schwarze Bauer steht immer "
            "noch dort -- wird er bei seinem Spieler entfernt?")
    zahlen = re.findall(r"\d+", shell)
    erwarte(zahlen[:2] == ["39", "38"], "Die Dame hat einen Bauern geschlagen: Weiß hat 39, Schwarz 38. In der Shell "
            "steht: %s" % (shell.strip()[:70] or "nichts"))
    _klick(c, (0, 3), g)
    shell = _klick(c, (1, 3), g)
    erwarte(_bilder_auf(c, (1, 3), g) == ["dame-s.png"], "Die schwarze Dame schlägt zurück, auf Zeile 1, Spalte 3 -- "
            "danach steht dort nicht die schwarze Dame allein. Wird eine weiße Figur bei Weiß entfernt?")
    erwarte(re.findall(r"\d+", shell)[:2] == ["30", "38"], "Die schwarze Dame hat die weiße geschlagen: Weiß hat 30, "
            "Schwarz 38. In der Shell steht: %s" % (shell.strip()[:70] or "nichts"))
    _klick(c, (0, 0), g)
    _klick(c, (5, 0), g)
    erwarte(_bilder_auf(c, (5, 0), g) == ["turm-s.png"], "Ein Zug auf ein leeres Feld (der schwarze Turm nach Zeile 5, "
            "Spalte 0) geht nicht mehr -- geschlagen wird nur, wenn am Ziel eine Figur steht.")


def _koenig():
    """Der Teil von Aufgabe 3 ★★, der die KLASSE prueft."""
    erwarte(hasattr(klasse("Spieler"), "hat_koenig"), "Geschlagen wird. Ob sein König noch steht, kann der Spieler "
            "noch nicht sagen -- hat_koenig fehlt in spieler.py.")
    for figuren, soll, wie in (((("Turm", 0, 0), ("Bauer", 1, 0), ("König", 0, 4)), True, "Turm, Bauer, König"),
                               ((("König", 0, 4), ("Turm", 0, 0)), True, "König, Turm"),
                               ((("Turm", 0, 0), ("Dame", 0, 3)), False, "Turm, Dame"), ((), False, "ohne Figuren")):
        s, _ = _spieler_mit(*figuren)
        antwort = rufe(s, "hat_koenig")
        erwarte(antwort is soll, "Ein Spieler mit %s: hat_koenig() gibt %r statt %r -- „nicht da“ weiß die Suche "
                "erst, wenn alle gefragt sind." % (wie, antwort, soll))


def pruefe_35_koenig_faellt():
    """Aufgabe 3 ★★ · Fällt ein König, ist die Partie aus"""
    braucht(_ok(pruefe_30_schlagen), "Erst wird geschlagen.")
    _koenig()
    c, g, fehler, ns = _spiel()
    erwarte(c is not None, "partie.py bricht ab, bevor das Brett fertig ist%s." % (" (%s)" % fehler if fehler else ""))
    erwarte(not _schon_aus(ns), "Beide Könige stehen noch -- partie_vorbei() sagt am Start trotzdem, die Partie sei "
            "aus. Dann tut kein Klick mehr etwas.")
    erwarte(not any("aus" in t.lower() for t in _texte(c)), "Am Start steht schon „Die Partie ist aus.“ auf dem "
            "Brett -- beide Könige stehen noch.")
    for feld in ((6, 4), (4, 4), (1, 5), (2, 5), (7, 3), (3, 7), (1, 0), (2, 0), (3, 7)):
        _klick(c, feld, g)
    shell = _klick(c, (0, 4), g)
    erwarte(_bilder_auf(c, (0, 4), g) == ["dame-w.png"], "Die weiße Dame schlägt von Zeile 3, Spalte 7 den schwarzen "
            "König auf Zeile 0, Spalte 4 -- danach steht dort nicht die Dame allein.")
    erwarte(any("aus" in t.lower() for t in _texte(c)), "Der schwarze König ist geschlagen. Auf dem Brett steht aber "
            "nicht, dass die Partie aus ist.")
    erwarte("König" in shell, "Der schwarze König ist geschlagen -- in der Shell steht nichts von einem König: %s"
            % (shell.strip()[-60:] or "nichts"))
    _klick(c, (6, 0), g)
    _klick(c, (5, 0), g)
    erwarte(_bilder_auf(c, (6, 0), g) == ["bauer-w.png"] and not _bilder_auf(c, (5, 0), g), "Die Partie ist aus -- "
            "trotzdem zieht danach noch ein weißer Bauer.")


def pruefe_60_mit_wert():
    """Aufgabe 6 ★★ · Alle Figuren ab einem Wert, als neue Liste"""
    braucht(_findet(), "Erst findet der Spieler seine Figuren (Aufgabe 2).")
    braucht(hasattr(klasse("Spieler"), "figuren_mit_wert"), "Erst die Methode figuren_mit_wert in spieler.py.")
    s, fs = _spieler_mit(("Bauer", 1, 0), ("Turm", 0, 0), ("Dame", 0, 3), ("Springer", 0, 1), ("Turm", 0, 7))
    fuenf = rufe(s, "figuren_mit_wert", 5)
    erwarte(isinstance(fuenf, list), "figuren_mit_wert(5) gibt keine Liste zurück, sondern %r." % (fuenf,))
    erwarte([id(x) for x in fuenf] == [id(fs[1]), id(fs[2]), id(fs[4])], "Bauer, Turm, Dame, Springer, Turm: "
            "figuren_mit_wert(5) gibt %d Figur(en) zurück statt Turm, Dame, Turm -- in der Reihenfolge der Liste. "
            "Kommen alle, die mindestens 5 wert sind?" % len(fuenf))
    erwarte(rufe(s, "anzahl") == 5, "Nach figuren_mit_wert hat der Spieler nur noch %r Figuren -- die eigene Liste "
            "bleibt, wie sie ist." % (rufe(s, "anzahl"),))
    erwarte(rufe(s, "figuren_mit_wert", 10) == [], "figuren_mit_wert(10): Keine Figur ist so viel wert -- zurück soll "
            "eine leere Liste kommen.")
    alle = rufe(s, "figuren_mit_wert", 0)
    erwarte(alle is not attribute(s).get("__figuren") and len(alle) == 5, "figuren_mit_wert(0) gibt die eigene Liste "
            "des Spielers heraus statt einer neuen.")


def _modul(name):
    m = sys.modules.get(name)
    if m is not None:
        return m
    try:
        return importlib.import_module(name)
    except Exception:  # noqa: BLE001 -- dann gibt es das Modul fuer den Check nicht
        return None


def pruefe_70_schach():
    """Aufgabe 7 ★★★ · spieler_schach.py: Steht der König im Schach? Drei Suchen, jede antwortet sofort"""
    m = _modul("spieler_schach")
    k = getattr(m, "Spieler", None) if m is not None else None
    braucht(isinstance(k, type) and hasattr(k, "steht_im_schach"), "Erst die Klasse Spieler mit steht_im_schach in "
            "spieler_schach.py.")
    ohne = [n for n in ("finde_koenig", "bedroht") if not hasattr(k, n)]
    erwarte(not ohne, "In spieler_schach.py fehlt noch: %s." % ", ".join(ohne))

    def spieler(farbe, *figuren):
        s = erzeuge(k, farbe)
        fs = [erzeuge("Figur", art, farbe, z, sp) for art, z, sp in figuren]
        for f in fs:
            rufe(s, "aufnehmen", f)
        return s, fs
    weiss, fs = spieler("weiß", ("Turm", 7, 0), ("König", 7, 4))
    erwarte(rufe(weiss, "finde_koenig") is fs[1], "Turm, König: finde_koenig() gibt nicht genau den König zurück.")
    erwarte(rufe(spieler("weiß", ("Turm", 7, 0))[0], "finde_koenig") is None, "Ein Spieler ohne König: finde_koenig() "
            "gibt nicht None zurück.")
    for figuren, soll, warum in ((( ("Turm", 0, 4),), True, "der schwarze Turm steht in der Spalte des Königs"),
                                 ((("Läufer", 0, 0),), False, "der schwarze Läufer erreicht das Feld des Königs nicht"),
                                 ((("Bauer", 6, 3),), True, "der schwarze Bauer schlägt schräg nach vorn"),
                                 ((("Bauer", 6, 4),), False, "der schwarze Bauer steht gerade vor dem König -- "
                                                             "geradeaus schlägt er nicht"),
                                 ((("Läufer", 0, 0), ("Bauer", 1, 0), ("Dame", 4, 1)), True, "die schwarze Dame steht "
                                                                                             "schräg zum König")):
        schwarz, _ = spieler("schwarz", *figuren)
        antwort = rufe(weiss, "steht_im_schach", schwarz)
        erwarte(antwort is soll, "Weißer König auf Zeile 7, Spalte 4, Schwarz mit %s: steht_im_schach gibt %r statt "
                "%r -- %s." % (", ".join("%s (%d, %d)" % f for f in figuren), antwort, soll, warum))
    ohne_koenig, _ = spieler("weiß", ("Turm", 7, 0))
    erwarte(rufe(ohne_koenig, "steht_im_schach", spieler("schwarz", ("Turm", 0, 0))[0]) is False, "Ein Spieler ohne "
            "König steht nicht im Schach -- steht_im_schach gibt dann False.")
    _Zaehlfigur.schlagfragen = 0
    zaehler = erzeuge(k, "schwarz")
    for spalte in range(5):
        rufe(zaehler, "aufnehmen", _Zaehlfigur(0, spalte, schlaegt=True))
    rufe(zaehler, "bedroht", 7, 4)
    erwarte(_Zaehlfigur.schlagfragen == 1, "Die Auflage: jede Suche antwortet, sobald die Antwort feststeht. Schon die "
            "erste von fünf Figuren bedroht das Feld -- bedroht fragt trotzdem %d." % _Zaehlfigur.schlagfragen)
    schleife = False
    for f in ast.walk(ast.parse(quelltext("spieler_schach.py"))):
        if isinstance(f, ast.FunctionDef) and f.name == "steht_im_schach":
            schleife = any(isinstance(v, (ast.For, ast.While)) for v in ast.walk(f))
    erwarte(not schleife, "Die Auflage: steht_im_schach sucht nicht selbst -- es fragt die zwei anderen Methoden. "
            "Hier steht noch eine Schleife darin.")


def pruefe_90_hints():
    """Hinweis · Jede Methode in spieler.py mit Type Hints (kein Stern)"""
    braucht(_findet(), "Erst findet der Spieler seine Figuren.")
    ohne, falsch, diagramm = [], [], []
    try:
        baum = ast.parse(quelltext("spieler.py"))
    except (SyntaxError, OSError, TypeError):
        return
    for k in ast.walk(baum):
        if not isinstance(k, ast.FunctionDef):
            continue
        for a in k.args.args + [k]:
            typ = a.annotation if isinstance(a, ast.arg) else a.returns
            if typ is not None and any(isinstance(x, ast.Name) and x.id in DIAGRAMMTYPEN for x in ast.walk(typ)):
                diagramm.append("%s (%s)" % (k.name, ast.unparse(typ)))
        parameter = [a for a in k.args.args if a.arg != "self"]
        if any(a.annotation is None for a in parameter) or (k.returns is None and k.name != "__init__"):
            ohne.append(k.name)
        elif k.name in HINTS and ast.unparse(k.returns).replace(" ", "") not in HINTS[k.name]:
            falsch.append("%s -> %s" % (k.name, " oder ".join(sorted(HINTS[k.name]))))
    erwarte(not diagramm, "Hier steht ein Typ in der Schreibweise des Diagramms: %s. In Python heißt er str, int, "
            "float oder bool." % ", ".join(diagramm))
    erwarte(not ohne, "Ohne Type Hint (hinter der Klammer oder an einem Parameter): %s. Es läuft auch ohne; "
            "vereinbart ist es trotzdem." % ", ".join(ohne))
    erwarte(not falsch, "Dieser Type Hint passt nicht zu dem, was zurückkommt -- erwartet: %s." % ", ".join(falsch))
