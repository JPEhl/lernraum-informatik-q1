"""Selbstcheck „Eigene Klassen schreiben“ -- prueft das Programm im Ordner schach/ (es laeuft partie.py).

Die Klasse schreibt figur.py selbst (13.11.2026). Der Check prueft die Klasse ueber OBJEKTE, die er selbst baut (LC8):
erzeuge, rufe, attribute -- mit Zeile ungleich Spalte (sonst faellt ein vertauschter Konstruktor nicht auf) und mit
ZWEI Figuren (erst die zweite zeigt, ob ziehen nur das Objekt vor dem Punkt aendert).

Seit dem Umbau nach Schnitt A (15.11.2026) traegt die Figur ihre Gangart: passt. Aufgabe 2 ★★ verlangt passt erst
„gerade, fuer jede Figur“ (damit partie.py wieder laeuft -- es fragt die Dame, bevor sie zieht), Aufgabe 3 dann nach
der Art. Der Check fragt in Aufgabe 2 deshalb nur einen TURM: Dessen Antworten sind in beiden Fassungen dieselben.
Aufgabe 3 ★★ (drei Figuren, Klick waehlt oder zieht) spielt partie.py frisch an und KLICKT wie die Maus (klick_auf,
LC6); gelesen wird, was man sieht: das Bild auf einem Feld, Rahmen und Punkte ueber ihre Lage.

Wer faerbt was (LC3): Solange in partie.py nur die Dame ein Objekt ist, liest Aufgabe 2 ★★ das Brett („die Dame steht
wieder da, ihre Ziele sind markiert“). Sobald dort eine zweite Figur entsteht, gehoert das Brett Aufgabe 3 ★★ -- ein
Fehler im Umbau von partie.py faerbt dann nur diese Pruefung.

Startzustand: figur.py hat nur einen Kopf, partie.py bricht beim Import ab. Die Grundlage passt dann trotzdem -- der
fehlende Bauplan ist Aufgabe 2, nicht die Grundlage (LC1).
"""
import ast
import importlib
import re
import sys

import pruefen
from pruefen import erwarte, braucht, arbeit, flaeche, quelltext, anspielen, erzeuge, rufe, attribute, gedruckt, \
    klasse, klick_auf

TITEL = "Eigene Klassen schreiben · Selbstcheck"
EINGABEN = []
HINTS = {"get_wert": "int", "ziehen": "None", "ist_gegner": "bool", "passt": "bool", "bildname": "str"}
DIAGRAMMTYPEN = {"String", "integer", "boolean", "Integer", "Boolean"}
WERTE = (("Bauer", 1), ("Springer", 3), ("Läufer", 3), ("Turm", 5), ("Dame", 9), ("König", 0))


def _soll(art, von, zeile, spalte):
    """Die Gangart nach der Beschreibung von Aufgabe 3: Turm gerade, Laeufer schraeg, Dame beides, sonst nie."""
    hoch, quer = abs(zeile - von[0]), abs(spalte - von[1])
    if hoch == 0 and quer == 0:
        return False
    if art == "Turm":
        return hoch == 0 or quer == 0
    if art == "Läufer":
        return hoch == quer
    if art == "Dame":
        return hoch == 0 or quer == 0 or hoch == quer
    return False


def _ziele(art, von):
    return {(z, s) for z in range(8) for s in range(8) if _soll(art, von, z, s)}


def _wo(feld):
    return "Zeile %d, Spalte %d" % tuple(feld)


def _spiel():
    """partie.py noch einmal, frisch, mit der figur.py der Klasse. Gibt (Flaeche, Feldgroesse) -- die Flaeche ist
    None, wenn keine entstand."""
    _, ns = anspielen([])
    return ns.get("flaeche"), ns.get("FELDGROESSE")


def _klick(c, feld, g):
    """Klickt wie die Maus mitten auf das Feld -- auf der Flaeche c eines frischen Laufs."""
    alt = pruefen._FENSTER
    pruefen._FENSTER = c.winfo_toplevel()
    try:
        return klick_auf(feld[1] * g + g // 2, feld[0] * g + g // 2, wo=_wo(feld))
    finally:
        pruefen._FENSTER = alt


def _bild(c, feld, g):
    """Das Bild, das man auf dem Feld SIEHT („dame-w.png“) -- None, wenn dort keins liegt."""
    x, y = feld[1] * g + g // 2, feld[0] * g + g // 2
    for i in reversed(c.find_all()):
        if c.type(i) == "image":
            b = c.bbox(i)
            if b and b[0] <= x < b[2] and b[1] <= y < b[3]:
                return pruefen._bilddatei(c, c.itemcget(i, "image"))
    return None


def _zahl(c):
    return len([i for i in c.find_all() if c.type(i) == "image"])


def _markiert(c, g):
    """Die markierten Felder auf c als Menge von (zeile, spalte): das rot gerahmte Feld der gewaehlten Figur und die
    Felder mit einem Punkt -- ihre Ziele (seit 16.11.2026; ein Rahmen als Ziel zaehlt weiter)."""
    felder = set()
    for i in c.find_all():
        if c.type(i) == "rectangle" and not c.itemcget(i, "fill") and c.itemcget(i, "outline"):
            x1, y1, x2, y2 = (round(v) for v in c.coords(i))
            if x1 % g == 0 and y1 % g == 0 and x2 - x1 == g and y2 - y1 == g:
                felder.add((y1 // g, x1 // g))
        elif c.type(i) == "oval":
            # ein Punkt mitten im Feld: ein Ziel (seit 16.11.2026 zeichnet zeige_ziele Punkte statt Rahmen)
            x1, y1, x2, y2 = (round(v) for v in c.coords(i))
            if (x1 + x2) // 2 % g == g // 2 and (y1 + y2) // 2 % g == g // 2:
                felder.add(((y1 + y2) // 2 // g, (x1 + x2) // 2 // g))
    return felder


def _fertig(c):
    """Ist partie.py bis zum Ende gelaufen? Dann hat die Flaeche ihre Funktion fuer den Klick (bei_klick steht nach
    dem ersten Zeichnen)."""
    return c is not None and pruefen._klick_gebunden(c)


def _mehrere_figuren():
    """Entsteht in partie.py schon mehr als die Dame? Dann gehoert das Brett Aufgabe 3 ★★."""
    return len(re.findall(r"\bFigur\(", quelltext())) > 1


def _figur_lesbar():
    """figur.py laesst sich lesen und laden? Gibt die Meldung oder None. Bricht figur.py beim Laden ab (`art: String`
    im Kopf -- die Schreibweise des Diagramms), gibt es fuer klasse() keine Figur; ohne diese Meldung hiesse es dann
    „noch keine Klasse Figur“, obwohl eine dasteht."""
    q = quelltext("figur.py")
    try:
        code = compile(q, "figur.py", "exec")
    except SyntaxError as e:
        return "figur.py lässt sich nicht lesen: Python versteht Zeile %s nicht." % e.lineno
    try:
        exec(code, {"__name__": "figur"})      # noqa: S102 -- figur.py IST der Pruefgegenstand
    except Exception as e:  # noqa: BLE001 -- der Abbruch ist der Befund
        zeile = None
        tb = e.__traceback__
        while tb is not None:
            if tb.tb_frame.f_code.co_filename == "figur.py":
                zeile = tb.tb_lineno
            tb = tb.tb_next
        nachsatz = ""
        if isinstance(e, NameError) and "'Figur'" in str(e) and "from __future__ import annotations" not in q:
            # Weg A (13.11.): `andere: Figur` braucht die vorgegebene Zeile -- ohne sie bricht Python 3.10 beim Laden ab
            nachsatz = " -- steht oben in figur.py noch die vorgegebene Zeile from __future__ import annotations?"
        return "figur.py bricht schon beim Laden ab%s: %s: %s%s" % (" in Zeile %d" % zeile if zeile else "",
                                                                     type(e).__name__, e, nachsatz)
    return None


def _geht(pruefung):
    """Besteht die Pruefung? (nur fuer braucht)"""
    try:
        pruefung()
    except AssertionError:
        return False
    return True


def _frage(figur, methode, *angaben):
    """Ruft eine Methode, die Ja oder Nein sagen soll. Zeigt sie die Antwort nur an, ist das der Befund."""
    antwort = rufe(figur, methode, *angaben)
    if antwort is None and gedruckt().strip():
        erwarte(False, "%s zeigt die Antwort in der Shell an, statt sie zurückzugeben." % methode)
    return antwort


def _modul(name):
    """Ein Modul aus dem Ordner des Programms -- das geladene, sonst frisch importiert; None, wenn es nicht geht."""
    m = sys.modules.get(name)
    if m is not None:
        return m
    try:
        return importlib.import_module(name)
    except Exception:  # noqa: BLE001 -- dann gibt es das Modul fuer den Check nicht
        return None


def pruefe_00_grundlage():
    """Grundlage · partie.py läuft bis zum Bauplan der Figur"""
    if klasse("Figur") is None:
        return      # partie.py haelt an `from figur import Figur` -- das ist Aufgabe 2 (auch ein Ladefehler dort)
    erwarte(flaeche() is not None, "Das Programm bricht ab, bevor es eine Zeichenfläche hat -- seht in der Shell nach.")
    g = getattr(arbeit(), "FELDGROESSE", None)
    erwarte(isinstance(g, int) and g > 0, "FELDGROESSE ist keine ganze Zahl über 0 -- oben in partie.py.")


def pruefe_20_entsteht():
    """Aufgabe 2 · Die Figur entsteht: Klasse und Konstruktor"""
    lesbar = _figur_lesbar()
    erwarte(lesbar is None, lesbar)
    erwarte(klasse("Figur") is not None, "In figur.py steht noch keine Klasse Figur -- deshalb bricht partie.py "
            "beim Laden ab. Seht euch das Klassendiagramm an.")
    turm = erzeuge("Figur", "Turm", "schwarz", 2, 5)
    werte = attribute(turm)
    fehlt = [n for n in ("art", "farbe", "zeile", "spalte") if n not in werte]
    erwarte(not fehlt, "Eine Figur, gebaut mit Figur('Turm', 'schwarz', 2, 5), hat kein Attribut %s -- im Konstruktor "
            "fehlt self.… = …" % ", ".join(fehlt))
    soll = {"art": "Turm", "farbe": "schwarz", "zeile": 2, "spalte": 5}
    falsch = ["%s ist %r statt %r" % (n, werte[n], w) for n, w in soll.items() if werte[n] != w]
    erwarte(not falsch, "Figur('Turm', 'schwarz', 2, 5): %s -- welcher Parameter landet in welchem Attribut?"
            % "; ".join(falsch))


def _ziehen_und_gerade():
    """Der Teil von Aufgabe 2 ★★, der die KLASSE prueft: ziehen aendert nur die gefragte Figur, passt sagt fuer einen
    Turm Ja zu Feldern in seiner Zeile oder Spalte und sonst Nein -- und bewegt niemanden."""
    k = klasse("Figur")
    erwarte(hasattr(k, "ziehen"), "Die Figur entsteht, ziehen kann sie noch nicht -- die Methode steht im Diagramm.")
    turm = erzeuge("Figur", "Turm", "schwarz", 2, 5)
    laeufer = erzeuge("Figur", "Läufer", "weiß", 6, 1)
    rufe(turm, "ziehen", 4, 0)
    t, l = attribute(turm), attribute(laeufer)
    erwarte((t["zeile"], t["spalte"]) != (2, 5), "Nach turm.ziehen(4, 0) steht der Turm noch auf Zeile 2, Spalte 5 -- "
            "ziehen ändert die Figur nicht. Was merkt sich das Objekt, was nur die Methode?")
    erwarte((t["zeile"], t["spalte"]) == (4, 0), "Nach turm.ziehen(4, 0) steht der Turm auf Zeile %r, Spalte %r statt "
            "Zeile 4, Spalte 0." % (t["zeile"], t["spalte"]))
    erwarte((l["zeile"], l["spalte"]) == (6, 1), "turm.ziehen(4, 0) hat auch den Läufer bewegt -- er steht auf Zeile %r, "
            "Spalte %r statt 6, 1." % (l["zeile"], l["spalte"]))
    erwarte(hasattr(k, "passt"), "ziehen stimmt. partie.py bricht aber noch ab: Es fragt die Dame mit passt, bevor sie "
            "zieht -- lest in der Shell, was der Figur fehlt.")
    turm = erzeuge("Figur", "Turm", "schwarz", 2, 5)
    for feld, soll, warum in (((2, 0), True, "das Feld liegt in seiner Zeile"), ((7, 5), True, "das Feld liegt in "
                              "seiner Spalte"), ((2, 7), True, "das Feld liegt in seiner Zeile"),
                              ((4, 6), False, "das Feld liegt weder in seiner Zeile noch in seiner Spalte"),
                              ((3, 4), False, "das Feld liegt schräg neben ihm")):
        antwort = _frage(turm, "passt", *feld)
        erwarte(antwort is not None, "passt gibt nichts zurück -- im Diagramm steht dahinter boolean.")
        erwarte(antwort is soll, "Ein Turm auf Zeile 2, Spalte 5 antwortet auf passt(%d, %d) mit %r statt %r -- %s."
                % (feld[0], feld[1], antwort, soll, warum))
    t = attribute(turm)
    erwarte((t["zeile"], t["spalte"]) == (2, 5), "passt hat den Turm bewegt: Er steht auf Zeile %r, Spalte %r statt auf "
            "Zeile 2, Spalte 5 -- fragen ändert nichts." % (t["zeile"], t["spalte"]))


def pruefe_25_zieht():
    """Aufgabe 2 ★★ · ziehen und passt: Die Dame steht wieder auf dem Brett und zieht"""
    braucht(_geht(pruefe_20_entsteht), "Erst entsteht die Figur.")
    _ziehen_und_gerade()
    if _mehrere_figuren():
        return      # das Brett mit mehreren Figuren liest Aufgabe 3 ★★
    c, g = _spiel()
    erwarte(_fertig(c), "Die Figur stimmt, partie.py bricht aber noch ab, bevor das Brett fertig ist -- seht in der "
            "Shell nach.")
    erwarte(_bild(c, (7, 3), g) == "dame-w.png", "Das Programm läuft, auf Zeile 7, Spalte 3 steht aber keine weiße Dame.")
    erwarte((3, 3) in _markiert(c, g), "Die Dame steht da, das Feld Zeile 3, Spalte 3 gerade vor ihr ist aber nicht "
            "markiert -- sagt passt für jede Figur Ja, wenn das Feld in ihrer Zeile oder Spalte liegt?")
    _klick(c, (3, 3), g)
    erwarte(_bild(c, (3, 3), g) == "dame-w.png", "Ein Klick auf Zeile 3, Spalte 3: Die Dame zieht nicht dorthin.")


def pruefe_28_wert():
    """Aufgabe 2 ★★★ · get_wert gibt den Wert nach der Beschreibung zurück"""
    braucht(_geht(pruefe_20_entsteht), "Erst entsteht die Figur.")
    braucht(hasattr(klasse("Figur"), "get_wert"), "Erst die Methode get_wert.")
    falsch = []
    for art, wert in WERTE:
        figur = erzeuge("Figur", art, "weiß", 1, 2)
        antwort = rufe(figur, "get_wert")
        if antwort is None and gedruckt().strip():
            erwarte(False, "get_wert zeigt den Wert in der Shell an, statt ihn zurückzugeben.")
        if antwort != wert:
            falsch.append("%s %r statt %d" % (art, antwort, wert))
    erwarte(not falsch, "get_wert gibt zurück: %s." % ", ".join(falsch))


def pruefe_30_gegner():
    """Aufgabe 3 · ist_gegner vergleicht die Farben zweier Figuren"""
    braucht(_geht(pruefe_20_entsteht), "Erst entsteht die Figur.")
    braucht(_geht(_ziehen_und_gerade), "Erst ziehen und passt (Aufgabe 2 ★★).")
    erwarte(hasattr(klasse("Figur"), "ist_gegner"), "In figur.py fehlt noch die Methode ist_gegner.")
    falsch = []
    for a, b, soll in (("weiß", "schwarz", True), ("schwarz", "weiß", True), ("weiß", "weiß", False),
                       ("schwarz", "schwarz", False)):
        eine = erzeuge("Figur", "Dame", a, 3, 3)
        andere = erzeuge("Figur", "Turm", b, 0, 7)
        antwort = _frage(eine, "ist_gegner", andere)
        if antwort is not soll:
            falsch.append("%s fragt %s: %r statt %r" % (a, b, antwort, soll))
    erwarte(not falsch, "ist_gegner antwortet: %s." % "; ".join(falsch))


def pruefe_32_gangart():
    """Aufgabe 3 · passt unterscheidet nach der Art: Turm gerade, Läufer schräg, Dame beides"""
    braucht(_geht(pruefe_20_entsteht), "Erst entsteht die Figur.")
    braucht(_geht(_ziehen_und_gerade), "Erst ziehen und passt (Aufgabe 2 ★★).")
    von = (4, 2)
    for art, ein, regel in (("Läufer", "ein", "schräg"), ("Dame", "eine", "gerade und schräg"), ("Turm", "ein", "gerade"),
                            ("Springer", "ein", "in diesem Thema noch gar nicht"),
                            ("König", "ein", "in diesem Thema noch gar nicht")):
        figur = erzeuge("Figur", art, "weiß", *von)
        ja = {(z, s) for z in range(8) for s in range(8) if _frage(figur, "passt", z, s) is True}
        soll = _ziele(art, von)
        zuviel, fehlt = sorted(ja - soll - {von}), sorted(soll - ja)
        erwarte(not zuviel, "%s %s auf %s sagt Ja zu %s -- %s %s zieht %s."
                % (ein.capitalize(), art, _wo(von), _wo(zuviel[0]) if zuviel else "", ein, art, regel))
        erwarte(not fehlt, "%s %s auf %s sagt Nein zu %s -- %s %s zieht %s."
                % (ein.capitalize(), art, _wo(von), _wo(fehlt[0]) if fehlt else "", ein, art, regel))
        erwarte(von not in ja, "%s %s auf %s sagt zu ihrem eigenen Feld Ja -- stehen bleiben ist kein Zug."
                % (ein.capitalize(), art, _wo(von)) if ein == "eine" else
                "%s %s auf %s sagt zu seinem eigenen Feld Ja -- stehen bleiben ist kein Zug."
                % (ein.capitalize(), art, _wo(von)))


def pruefe_35_drei_figuren():
    """Aufgabe 3 ★★ · Dame, Turm und Läufer: Ein Klick wählt eine Figur oder lässt die gewählte ziehen"""
    braucht(_geht(pruefe_32_gangart), "Erst passt nach der Art.")
    erwarte(_mehrere_figuren(), "In partie.py ist noch nur die Dame ein Objekt -- Turm und Läufer sind Bilder an "
            "festen Zahlen.")
    c, g = _spiel()
    erwarte(_fertig(c), "partie.py bricht ab, bevor das Brett fertig ist -- seht in der Shell nach.")
    erwarte(_bild(c, (7, 3), g) == "dame-w.png" and _bild(c, (7, 0), g) == "turm-w.png"
            and _bild(c, (7, 2), g) == "laeufer-w.png", "Am Start stehen Dame, Turm und Läufer nicht auf Zeile 7, "
            "Spalte 3, 0 und 2.")

    def gewaehlt(art, feld, wann):
        ist = _markiert(c, g)
        erwarte(feld in ist, "%s ist das Feld der gewählten Figur (%s) nicht gerahmt -- gewählt ist jetzt %s."
                % (wann, _wo(feld), {"Dame": "die Dame", "Turm": "der Turm", "Läufer": "der Läufer"}[art]))
        soll = _ziele(art, feld)
        for wessen, a, f in (("der Dame", "Dame", dame), ("des Turms", "Turm", turm), ("des Läufers", "Läufer", laeufer)):
            erwarte(f == feld or ist - {f} != _ziele(a, f) or ist - {feld} == soll, "%s sind noch Feld und Ziele %s "
                    "markiert -- merkt sich das Programm, wer gewählt ist, auch außerhalb von klick? Und wen fragt "
                    "zeige_ziele?" % (wann, wessen))
        erwarte(ist - {feld} == soll, "%s sind nicht genau die Ziele der gewählten Figur markiert (%d Felder statt %d)."
                % (wann, len(ist - {feld}), len(soll)))

    dame, turm, laeufer = (7, 3), (7, 0), (7, 2)
    gewaehlt("Dame", dame, "Am Start")
    _klick(c, turm, g)
    erwarte(_bild(c, turm, g) == "turm-w.png" and _bild(c, dame, g) == "dame-w.png", "Ein Klick auf den Turm: Die Dame "
            "zieht auf sein Feld, statt dass er gewählt wird. Was fragt klick zuerst -- steht dort eine eurer "
            "Figuren, oder passt das Feld?")
    gewaehlt("Turm", turm, "Nach einem Klick auf den Turm")
    _klick(c, (4, 0), g)
    erwarte(_bild(c, (4, 0), g) == "turm-w.png", "Der Turm ist gewählt, ein Klick auf Zeile 4, Spalte 0 lässt ihn aber "
            "nicht dorthin ziehen.")
    erwarte(_bild(c, (7, 0), g) != "turm-w.png", "Der Turm ist nach Zeile 4, Spalte 0 gezogen, auf Zeile 7, Spalte 0 "
            "steht aber noch ein weißer Turm -- sein Bild hängt an festen Zahlen.")
    turm = (4, 0)
    _klick(c, (5, 1), g)
    erwarte(_bild(c, turm, g) == "turm-w.png" and _bild(c, (5, 1), g) is None, "Ein Klick schräg neben den Turm "
            "(Zeile 5, Spalte 1): Er zieht dorthin, obwohl das Feld nicht zu ihm passt.")
    _klick(c, laeufer, g)
    gewaehlt("Läufer", laeufer, "Nach einem Klick auf den Läufer")
    _klick(c, (5, 4), g)
    erwarte(_bild(c, (5, 4), g) == "laeufer-w.png" and _bild(c, (7, 2), g) != "laeufer-w.png",
            "Der Läufer ist gewählt, ein Klick auf Zeile 5, Spalte 4 lässt ihn aber nicht dorthin ziehen.")
    _klick(c, dame, g)
    gewaehlt("Dame", dame, "Nach einem erneuten Klick auf die Dame")
    zahl = _zahl(c)
    erwarte(zahl == 32, "Nach den Zügen stehen %d Figuren auf dem Brett statt 32." % zahl)


def pruefe_60_bildname():
    """Aufgabe 6 ★★ · bildname nennt das Bild jeder Figur, und die Dame wird damit gezeichnet"""
    braucht(_geht(pruefe_20_entsteht), "Erst entsteht die Figur.")
    braucht(hasattr(klasse("Figur"), "bildname"), "Erst die Methode bildname in figur.py.")
    namen = {"Bauer": "bauer", "Springer": "springer", "Läufer": "laeufer", "Turm": "turm", "Dame": "dame",
             "König": "koenig"}
    falsch = []
    for art, datei in namen.items():
        for farbe, k in (("weiß", "w"), ("schwarz", "s")):
            antwort = rufe(erzeuge("Figur", art, farbe, 1, 2), "bildname")
            if antwort != "%s-%s" % (datei, k):
                falsch.append("%s (%s): %r" % (art, farbe, antwort))
    erwarte(not falsch, "bildname gibt zurück: %s." % "; ".join(falsch))
    erwarte(re.search(r"\.bildname\(\)", quelltext()), "bildname stimmt -- aber partie.py zeichnet die Dame noch mit "
            "dem Namen von Hand.")


def pruefe_70_bauer():
    """Aufgabe 7 ★★★ · Der Bauer in figur_bauer.py: Richtung nach Farbe, vom Startfeld zwei -- die Farbe einmal gefragt"""
    m = _modul("figur_bauer")
    k = getattr(m, "Figur", None) if m is not None else None
    braucht(isinstance(k, type) and hasattr(k, "passt"), "Erst die Klasse Figur mit passt in figur_bauer.py.")
    for art in ("Turm", "Läufer", "Dame"):
        figur = erzeuge(k, art, "weiß", 4, 2)
        ja = {(z, s) for z in range(8) for s in range(8) if _frage(figur, "passt", z, s) is True}
        erwarte(ja == _ziele(art, (4, 2)), "In figur_bauer.py zieht ein %s nicht mehr wie in figur.py -- kopiert eure "
                "Klasse erst ganz herüber." % art)
    for farbe, von, ja, nein in (("weiß", (6, 4), [(5, 4), (4, 4)], [(3, 4), (7, 4), (5, 5), (6, 5), (6, 4)]),
                                 ("weiß", (4, 4), [(3, 4)], [(2, 4), (5, 4), (3, 3)]),
                                 ("schwarz", (1, 2), [(2, 2), (3, 2)], [(4, 2), (0, 2), (2, 3), (1, 2)]),
                                 ("schwarz", (3, 2), [(4, 2)], [(5, 2), (2, 2), (4, 1)]),
                                 ("schwarz", (6, 2), [(7, 2)], [(5, 2), (4, 2)])):
        for feld in ja + nein:
            bauer = erzeuge(k, "Bauer", farbe, *von)
            antwort = _frage(bauer, "passt", *feld)
            soll = feld in ja
            erwarte(antwort is soll, "Ein %ser Bauer auf %s antwortet auf passt(%d, %d) mit %r statt %r."
                    % (farbe, _wo(von), feld[0], feld[1], antwort, soll))
    baum = ast.parse(quelltext("figur_bauer.py"))
    fragen = 0
    for f in ast.walk(baum):
        if isinstance(f, ast.FunctionDef) and f.name == "passt":
            for v in ast.walk(f):
                if isinstance(v, ast.Compare) and any(isinstance(x, ast.Attribute) and x.attr == "farbe"
                                                      for x in ast.walk(v)):
                    fragen += 1
    erwarte(fragen <= 1, "Der Bauer zieht richtig. In passt wird die Farbe aber %d-mal gefragt -- die Auflage ist: "
            "einmal." % fragen)


def pruefe_90_hints():
    """Hinweis · Jede Methode in figur.py mit Type Hints (kein Stern)"""
    try:
        baum = ast.parse(quelltext("figur.py"))
    except SyntaxError:
        return
    ohne, falsch, diagramm = [], [], []
    for k in ast.walk(baum):
        if not isinstance(k, ast.FunctionDef):
            continue
        # Weg A (13.11.): Mit `from __future__ import annotations` wertet Python Typangaben nicht mehr aus -- `art: String`
        # (die Schreibweise des Diagramms) bricht nicht mehr ab und fiele sonst niemandem auf (Giftprobe string_typ).
        for a in k.args.args + [k]:
            typ = a.annotation if isinstance(a, ast.arg) else a.returns
            if typ is not None and any(isinstance(x, ast.Name) and x.id in DIAGRAMMTYPEN for x in ast.walk(typ)):
                diagramm.append("%s (%s)" % (k.name, ast.unparse(typ)))
        parameter = [a for a in k.args.args if a.arg != "self"]
        if any(a.annotation is None for a in parameter) or (k.returns is None and k.name != "__init__"):
            ohne.append(k.name)
        elif k.name in HINTS and ast.unparse(k.returns).replace(" ", "") != HINTS[k.name]:
            falsch.append("%s -> %s" % (k.name, HINTS[k.name]))
    erwarte(not diagramm, "Hier steht ein Typ in der Schreibweise des Diagramms: %s. In Python heißt er str, int, "
            "float oder bool." % ", ".join(diagramm))
    erwarte(not ohne, "Ohne Type Hint (hinter der Klammer oder an einem Parameter): %s. Es läuft auch ohne; "
            "vereinbart ist es trotzdem -- der Konstruktor braucht hinter der Klammer keinen." % ", ".join(ohne))
    erwarte(not falsch, "Dieser Type Hint passt nicht zu dem, was zurückkommt -- erwartet: %s." % ", ".join(falsch))
