# spiel_matt.py -- Expertenaufgabe: ein
# Spiel, das Matt und Patt erkennt.
# Kopiert eure Klasse Spiel hierher.

# erlaubt die eigene Klasse als Typ:
from __future__ import annotations
from zeichenflaeche import zeichne_bild
from figur import Figur
from spieler import Spieler
from zug import Zug

ARTEN = ["Turm", "Springer", "Läufer", "Dame",
         "König", "Läufer", "Springer", "Turm"]
