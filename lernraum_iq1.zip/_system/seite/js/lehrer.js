/* Lernraum · lehrer.js -- Regie, Nach der Stunde, Werkbuch-Reiter, Übersicht, Besprechung.
   Teil der Arbeitsseite; alle Teile teilen einen Namensraum und laden in der
   Reihenfolge von index.html (kein Bündler, CSP 'self'). */
"use strict";
// ─── Regie (Lehrer) ─────────────────────────────────────────────────────────────────────
function regieSeite(haupt, T) {
  if (!Z.lehrer) return;
  const s = h("div", { class: "regie-seite" });
  haupt.append(s);
  if (Z.beamer) { s.append(h("p", { class: "hinweis" }, "Beamer ist an – die Regie bleibt zu.")); return; }
  s.append(nachDerStunde(T));
  api("regie", { thema: T.pfad }).then(r => {
    s.append(h("p", {}, "Dieselbe Datei fürs iPad: ", h("a", { href: "/_system/lehrer/regie_" + T.pfad.replace("/", "_") + ".html", target: "_blank" }, "regie_" + T.pfad.replace("/", "_") + ".html"), " (liegt unter ", h("code", {}, r.datei), ")"));
    const doc = new DOMParser().parseFromString(r.html, "text/html");
    const body = doc.body; body.querySelectorAll("textarea").forEach(x => x.remove());
    s.append(h("div", { html: body.innerHTML }));
  }).catch(e => s.append(h("p", { class: "fehler" }, e.message)));
}

// „Nach der Stunde“ (Werkbuch, 14.10.): eine Beobachtung je Eintrag, ohne Stelle; mit Stelle geht
// es über die Durchsicht (Nadel, „Woher: nach der Stunde“). Ersetzt das Feld „Stundenerfahrung“
// der iPad-Regie, das nichts speicherte.
function nachDerStunde(T) {
  const box = h("div", { class: "nach-der-stunde" });
  const feld = h("textarea", { placeholder: "Was ist passiert, wo hing es, was ändern?" });
  const stapel = h("select", {}, STAPEL.map(([k, t]) => { const o = h("option", { value: k }, t); if (k === "stundenbau") o.selected = true; return o; }));
  const liste = h("div", { class: "liste" });
  async function listeZeichnen() {
    await werkbuchLaden(true); liste.textContent = "";
    const da = werkbuchThema(T.pfad).eintraege.filter(e => e.quelle === "stunde");
    if (!da.length) liste.append(h("p", { class: "leer" }, "Noch keine Beobachtung zu diesem Thema."));
    for (const e of da.slice().reverse()) liste.append(werkbuchKarte(e, !!e.anker));
  }
  const speichern = async () => {
    const text = feld.value.trim(); if (!text) return;
    await durchsichtLaden();
    D.daten.nadeln.push({ id: neueKennung("stunde"), quelle: "stunde", nr: D.daten.nadeln.reduce((m, x) => Math.max(m, x.nr || 0), 0) + 1, route: "t/" + T.pfad + "/regie",
      titel: "Thema " + T.thema.nr + " · " + T.thema.titel + " · Nach der Stunde", anker: null, dx: .5, dy: .5, x: null, y: null, text: "", notiz: text, stapel: stapel.value, zeit: new Date().toISOString() });
    await durchsichtSpeichern(); feld.value = ""; meldung("Ins Werkbuch geschrieben."); listeZeichnen();
  };
  box.append(h("h2", {}, "Nach der Stunde"),
    h("p", {}, "Jede Beobachtung wird ein Eintrag im ", h("a", { href: adr("t/" + T.pfad + "/werkbuch") }, "Werkbuch"), ". Zu einer bestimmten Stelle: Durchsicht einschalten und eine Nadel mit „Woher: nach der Stunde“ setzen."),
    feld, h("div", { class: "zeile" }, h("label", {}, "Stapel"), stapel, h("button", { class: "primaer", onclick: speichern }, "Ins Werkbuch")), liste);
  listeZeichnen();
  return box;
}

// ─── Werkbuch-Reiter (Lehrer, nie am Beamer) ───────────────────────────────────────────────
function werkbuchSeite(haupt, T) {
  if (!Z.lehrer) return;
  const s = h("div", { class: "seite werkbuch" }); haupt.append(s);
  if (Z.beamer) { s.append(h("p", { class: "hinweis" }, "Beamer ist an – das Werkbuch bleibt zu.")); return; }
  let filter = { status: "alle", quelle: "alle" };
  try { filter = Object.assign(filter, JSON.parse(localStorage.getItem("lernraum.werkbuch.filter") || "{}")); } catch (e) {}
  const kopf = h("div", {}), filterEl = h("div", { class: "werkbuch-filter" }), liste = h("div", { class: "werkbuch-liste" });
  s.append(h("h1", {}, "Werkbuch"), h("p", { class: "unter" }, "Alles, was zu diesem Thema angemerkt wurde – von dir in der Durchsicht, nach der Stunde, und von der Klasse (ohne Namen) – und was daraus wurde. Nur hier, nie am Beamer."), kopf, filterEl, liste);
  werkbuchLaden(true).then(() => {
    const wt = werkbuchThema(T.pfad), alle = wt.eintraege;
    const zahl = st => alle.filter(e => e.status === st).length;
    kopf.textContent = "";
    kopf.append(h("p", { class: "summe" }, alle.length + " Einträge · " + zahl("eingearbeitet") + " eingearbeitet · " + zahl("offen") + " offen · " + zahl("frage") + " Frage an dich" + (zahl("neu") ? " · " + zahl("neu") + " neu (noch nicht eingelesen)" : "") + (W.daten.gebaut ? " · gebaut " + W.daten.gebaut : "")));
    const urteile = Object.entries(wt.urteile || {});
    if (urteile.length) kopf.append(h("p", { class: "urteile" }, "Urteile: ", urteile.map(([r, u]) => h("a", { href: adr(r), class: "urteil-chip " + u.urteil, title: u.titel || r }, stelleKurz(u.titel) + " · " + u.urteil))));
    function chips(gruppe, werte) {
      const zeile = h("div", { class: "fz" }, h("span", { class: "fl" }, gruppe === "status" ? "Status" : "Quelle"));
      for (const [k, name] of [["alle", "alle"], ...werte]) {
        const n = k === "alle" ? alle.length : alle.filter(e => e[gruppe] === k).length;
        // alle Stufen waehlbar, auch wenn gerade keine darin steht (Lehrer 14.10.)
        zeile.append(h("button", { class: "chip" + (filter[gruppe] === k ? " aktiv" : "") + (n ? "" : " null"), onclick: () => { filter[gruppe] = k; try { localStorage.setItem("lernraum.werkbuch.filter", JSON.stringify(filter)); } catch (e) {} zeigen(); } }, name + " " + n));
      }
      return zeile;
    }
    function zeigen() {
      filterEl.textContent = ""; filterEl.append(chips("status", W_STATUS), chips("quelle", W_QUELLE));
      liste.textContent = "";
      const sicht = alle.filter(e => (filter.status === "alle" || e.status === filter.status) && (filter.quelle === "alle" || e.quelle === filter.quelle));
      if (!sicht.length) liste.append(h("p", { class: "leer" }, alle.length ? "Nichts in dieser Auswahl." : "Noch nichts angemerkt. Einträge entstehen in der Durchsicht, im Regie-Reiter („Nach der Stunde“) und in der Übersicht („Anmerkungen ins Werkbuch“)."));
      for (const e of sicht) liste.append(werkbuchKarte(e, true, true));
    }
    zeigen();
  });
}

// ─── Übersicht (Lehrer) ──────────────────────────────────────────────────────────────────
function uebersichtSeite(haupt) {
  kopfZeichnen([["Übersicht", null]]);
  const s = h("div", { class: "seite uebersicht" }, h("h1", {}, "Übersicht"));
  haupt.append(s);
  if (!Z.lehrer) { s.append(h("p", {}, "Nur in der Lehrerfassung.")); return; }
  if (Z.beamer) { s.append(h("p", { class: "hinweis" }, "Beamer ist an – die Übersicht bleibt zu. Erst „Beamer aus“.")); return; }
  const abgabenFeld = h("input", { type: "file", multiple: true });
  const ordnerFeld = h("input", { type: "file", multiple: true, webkitdirectory: true });
  const listeFeld = h("input", { type: "file", accept: ".doc,.html,.htm" });
  const nachlaufen = h("input", { type: "checkbox", checked: true });
  const ablage = h("div", { class: "ablage" },
    h("p", {}, h("b", {}, "Abgaben aus dem Schulportal"), " – den heruntergeladenen Ordner (oder die ZIP, oder einzelne Dateien) hier hineinziehen oder wählen. Dateien heißen dort ", h("code", {}, "Nachname Vorname abgabe_….zip"), "."),
    h("label", {}, "Ordner: ", ordnerFeld), h("label", {}, "ZIP oder Dateien: ", abgabenFeld),
    h("p", {}, h("b", {}, "Kursliste"), " – der Export aus dem Schulportal (", h("code", {}, "Kursliste_….doc"), ", in Wahrheit HTML). Bleibt auf diesem Rechner."),
    h("label", {}, "Kursliste: ", listeFeld),
    h("label", {}, nachlaufen, " Selbstchecks am abgegebenen Code nachlaufen lassen (isoliert, 10 s je Abgabe)"),
    h("p", {}, h("button", { class: "primaer", onclick: laden }, "Laden"), " ", h("button", { class: "ruhig", onclick: async () => { await api("uebersicht/vergessen", {}); ergebnis.textContent = ""; } }, "Alles vergessen")));
  const gezogene = [];
  ablage.addEventListener("dragover", ev => { ev.preventDefault(); ablage.classList.add("ueber"); });
  ablage.addEventListener("dragleave", () => ablage.classList.remove("ueber"));
  ablage.addEventListener("drop", async ev => { ev.preventDefault(); ablage.classList.remove("ueber"); for (const it of ev.dataTransfer.items) { const e = it.webkitGetAsEntry && it.webkitGetAsEntry(); if (e && e.isDirectory) await ordnerLesen(e, gezogene); else { const f = it.getAsFile(); if (f) gezogene.push(f); } } meldung(gezogene.length + " Datei(en) bereit – jetzt „Laden“."); });
  function ordnerLesen(entry, ziel) { return new Promise(res => { const reader = entry.createReader(); reader.readEntries(async eintraege => { for (const e of eintraege) { if (e.isFile) await new Promise(r2 => e.file(f => { ziel.push(f); r2(); })); else if (e.isDirectory) await ordnerLesen(e, ziel); } res(); }); }); }
  const ergebnis = h("div", {});
  s.append(ablage, ergebnis);
  api("uebersicht/lesen").then(r => { if (!r.leer) tabelle(r); }).catch(() => {});
  async function laden() {
    const dateien = [...gezogene, ...abgabenFeld.files, ...ordnerFeld.files];
    const abgaben = [];
    for (const f of dateien) { const name = f.webkitRelativePath ? f.webkitRelativePath.split("/").pop() : f.name; if (name.startsWith(".")) continue; abgaben.push({ name, daten: await dateiB64(f) }); }
    let kursliste = null; if (listeFeld.files[0]) kursliste = { name: listeFeld.files[0].name, daten: await dateiB64(listeFeld.files[0]) };
    if (!abgaben.length && !kursliste) { meldung("Nichts gewählt.", "fehler"); return; }
    ergebnis.textContent = ""; ergebnis.append(h("p", { class: "laden" }, "Lade " + abgaben.length + " Datei(en)" + (nachlaufen.checked ? " und lasse die Selbstchecks nachlaufen …" : " …")));
    try { const r = await api("uebersicht/laden", { abgaben, kursliste, nachlaufen: nachlaufen.checked }); gezogene.length = 0; tabelle(r); }
    catch (e) { ergebnis.textContent = ""; ergebnis.append(h("p", { class: "fehler" }, e.message)); }
  }
  function tabelle(r) {
    ergebnis.textContent = "";
    if (r.fehler_liste && r.fehler_liste.length) ergebnis.append(h("div", { class: "fehlerliste" }, h("b", {}, r.fehler_liste.length + " Hinweis(e):"), h("ul", {}, r.fehler_liste.map(x => h("li", {}, x)))));
    // Jahresübersicht (Lehrerwunsch 16.10.): nur per Knopf -- sonst landen Probeläufe im Schuljahr
    if (r.personen.length && r.abgegeben) ergebnis.append(h("p", { class: "jahr-knopf" }, h("button", { class: "primaer", onclick: async ev => {
      if (!confirm("Die geltenden Abgaben der " + r.personen.length + " Personen aus der Kursliste ins Schuljahr übernehmen?\n\nGespeichert werden je Person und Thema Sterne, Ziel, Hilfen, mit wem, Mini-Exit ja/nein und wann – kein Code. Eine neuere Abgabe ersetzt eine ältere (als „nachgereicht“ markiert).")) return;
      try { const a = await api("jahr/uebernehmen", {}); const b = a.bericht; ev.target.textContent = "✓ im Schuljahr";
        meldung(b.neu + " neu, " + b.ersetzt + " nachgereicht, " + b.gleich + " schon drin" + (b.aelter ? ", " + b.aelter + " ältere übergangen" : "") + " – siehe „Schuljahr“."); }
      catch (e) { meldung(e.message, "fehler"); } } }, "In die Jahresübersicht übernehmen"),
      h("span", { class: "leer" }, " – nur, was du übernimmst, bleibt; die Übersicht selbst vergisst beim Schließen."), " ", h("a", { href: adr("schuljahr") }, "Schuljahr →")));
    else if (r.abgegeben && !r.personen.length) ergebnis.append(h("p", { class: "leer" }, "Für die Jahresübersicht fehlt die Kursliste – sie macht die Namen verlässlich."));
    ergebnis.append(h("p", {}, r.personen.length + " Person(en) in der Liste, " + r.abgegeben + " Abgabe(n) zugeordnet, " + r.fehlend.length + " fehlen" + (r.dauer != null ? " · " + r.dauer + " s" : "") + (r.nachgelaufen ? " · Selbstchecks nachgelaufen" : " · ohne Nachlaufen (Selbstauskunft)")));
    const auswahl = new Set();
    const planAuswahl = new Map();      // „nr|name“ -> [nr, name]: Plaene fuer die Besprechung (19.10.)
    // Der Plan einer Person unter ihrer Zeile (19.10.): das Bild aus der abgegebenen Quelle, der erste Fall,
    // der nicht stimmt, und „für die Besprechung“. Ein zweiter Klick klappt zu.
    function planDetail(tr, z, anr, p, td) {
      const offen = tr.nextElementSibling && tr.nextElementSibling.classList.contains("plan-detail") ? tr.nextElementSibling : null;
      if (offen) { offen.remove(); if (offen.dataset.aufgabe === anr) return; }
      const K = Werkstaetten.struktogramm.kern;
      const bild = h("div", { class: "strukto-ws pd-bild" });
      try { const g = K.zeichnen(K.lesen(p.quelle || "…"), { titel: p.titel || "Algorithmus", skala: 1 }); bild.innerHTML = g.svg; bild.style.width = bild.firstChild.getAttribute("width") + "px"; }
      catch (e) { bild.append(h("p", { class: "fehler" }, "Nicht lesbar: " + e.message)); }
      const f = (p.falsch || [])[0];
      const schluessel = z.nr + "|" + p.name;
      const knopf = h("button", { onclick: () => { if (planAuswahl.has(schluessel)) planAuswahl.delete(schluessel); else planAuswahl.set(schluessel, [z.nr, p.name]); knopf.textContent = planAuswahl.has(schluessel) ? "✓ für die Besprechung" : "für die Besprechung"; } },
        planAuswahl.has(schluessel) ? "✓ für die Besprechung" : "für die Besprechung");
      const text = h("div", {}, h("b", {}, "Aufgabe " + anr + " · Plan von " + z.name), h("br"),
        "Fälle: " + p.ok + " von " + p.von + (p.lesbar === false ? " – der Plan ist nicht lesbar" : ""), h("br"),
        f ? h("span", { class: "pd-falsch" }, f.zeigen.map(x => x[1]).join(" · ") + " → " + (f.fehler ? "bricht ab: " + f.fehler : "„" + (f.aus.join(" / ") || "—") + "“" + (f.grund ? " (" + f.grund + ")" : "")) + (f.soll ? " statt „" + f.soll.join(" / ") + "“" : "")) : h("span", { class: "leer" }, "alle Fälle stimmen"),
        h("br"), h("span", { class: "leer" }, "aus der Abgabe nachgerechnet" + (p.zeit ? " · zuletzt geändert " + p.zeit.replace("T", " ") : "")),
        h("p", {}, knopf, " ", h("button", { class: "ruhig", onclick: () => detail.remove() }, "zuklappen")));
      const detail = h("tr", { class: "plan-detail" }, h("td", { colspan: String(tr.children.length) }, h("div", { class: "pd-reihe" }, bild, text)));
      detail.dataset.aufgabe = anr;
      tr.after(detail);
    }
    // Diagramm (13.11.2026): das Bild aus dem abgegebenen Modell (rote Zeilen rot), die ersten Meldungen des
    // Selbstchecks, nachgerechnet, und „für die Besprechung“ -- wie beim Plan
    const diagrammAuswahl = new Map();
    function diagrammDetail(tr, z, anr, p) {
      const offen = tr.nextElementSibling && tr.nextElementSibling.classList.contains("plan-detail") ? tr.nextElementSibling : null;
      if (offen) { offen.remove(); if (offen.dataset.aufgabe === anr) return; }
      const bild = h("div", { class: "pd-bild uml-pd", html: Werkstaetten.klassendiagramm.kern.svg(p.modell, { titel: "Klassendiagramm von " + z.name }) });
      const schluessel = z.nr + "|" + p.name;
      const knopf = h("button", { onclick: () => { if (diagrammAuswahl.has(schluessel)) diagrammAuswahl.delete(schluessel); else diagrammAuswahl.set(schluessel, [z.nr, p.name]); knopf.textContent = diagrammAuswahl.has(schluessel) ? "✓ für die Besprechung" : "für die Besprechung"; } },
        diagrammAuswahl.has(schluessel) ? "✓ für die Besprechung" : "für die Besprechung");
      const text = h("div", {}, h("b", {}, "Aufgabe " + anr + " · Klassendiagramm von " + z.name), h("br"),
        p.ok ? h("span", { class: "gruen" }, "passt zur Aufgabe") : h("span", { class: "pd-falsch" }, (p.meldungen || []).join(" · ")),
        h("br"), h("span", { class: "leer" }, "aus der Abgabe nachgerechnet" + (p.versuche ? " · " + p.versuche + "× Selbstcheck" : " · ohne Selbstcheck") + (p.zeit ? " · zuletzt geändert " + p.zeit.replace("T", " ") : "")),
        h("p", {}, knopf, " ", h("button", { class: "ruhig", onclick: () => detail.remove() }, "zuklappen")));
      const detail = h("tr", { class: "plan-detail" }, h("td", { colspan: String(tr.children.length) }, h("div", { class: "pd-reihe" }, bild, text)));
      detail.dataset.aufgabe = anr;
      tr.after(detail);
    }
    // Wie in der Klausur (09.11.2026): ein Klick auf die Zelle klappt die Pruefung auf -- je Text der Text, das Raster
    // mit der Selbsteinschaetzung und Claudes Vorschlag (mit Grund); die Lehrkraft kippt, was sie anders sieht, und
    // bestaetigt. Erst Bestaetigtes gibt Sterne (★ ab der Haelfte, ★★ bei voll; kursserver/bewertung.py).
    function klausurDetail(tr, z, anr, k) {
      const offen = tr.nextElementSibling && tr.nextElementSibling.classList.contains("plan-detail") ? tr.nextElementSibling : null;
      if (offen) { offen.remove(); if (offen.dataset.aufgabe === anr) return; }
      const box = h("div", {}, h("b", {}, "Aufgabe " + anr + " · wie in der Klausur · " + z.name));
      for (const t of k.teile) {
        const wahl = (t.bestaetigt || t.vorschlag || { raster: t.selbst }).raster.slice();
        const liste = h("ol", { class: "kl-pruefung" });
        t.raster.forEach((zeile, i) => {
          const k2 = h("input", { type: "checkbox" }); k2.checked = !!wahl[i];
          k2.addEventListener("change", () => { wahl[i] = k2.checked; });
          const grund = t.vorschlag && t.vorschlag.gruende[i];
          liste.append(h("li", {}, h("label", {}, k2, h("span", { html: zeile })),
            h("span", { class: "kl-selbst" + (t.selbst[i] ? " ja" : "") }, t.selbst[i] ? "selbst: ja" : "selbst: nein"),
            grund ? h("span", { class: "kl-grund" }, "Claude: " + grund) : null));
        });
        const status = t.bestaetigt ? "bestätigt " + t.bestaetigt.zeit.replace("T", " ") : t.vorschlag ? "Vorschlag von Claude – noch nicht bestätigt" : t.verglichen ? "noch nicht geprüft" : "Entwurf, nicht verglichen";
        box.append(h("p", { class: "kl-abgabe" }, t.text || "(leer)"), liste,
          h("p", {}, h("span", { class: "leer" }, status + " "), t.verglichen ? h("button", { class: "primaer", onclick: async ev => {
            try { const a = await api("uebersicht/klausur_bestaetigen", { name: z.name, kennung: t.kennung, raster: wahl }); ev.target.textContent = "✓ bestätigt"; tabelle(a.bericht); }
            catch (e) { meldung(e.message, "fehler"); } } }, t.bestaetigt ? "neu bestätigen" : "bestätigen") : null));
      }
      box.append(h("p", {}, h("button", { class: "ruhig", onclick: () => detail.remove() }, "zuklappen")));
      const detail = h("tr", { class: "plan-detail" }, h("td", { colspan: String(tr.children.length) }, box));
      detail.dataset.aufgabe = anr;
      tr.after(detail);
    }
    function klausurZelle(k) {
      const zahl = f => k.teile.reduce((s, t) => s + (f(t) || []).filter(Boolean).length, 0), von = k.teile.reduce((s, t) => s + t.be, 0);
      if (k.teile.every(t => t.bestaetigt)) return ["geprüft " + zahl(t => t.bestaetigt.raster) + "/" + von, "zelle-passt"];
      if (k.teile.every(t => t.vorschlag)) return ["Vorschlag " + zahl(t => t.vorschlag.raster) + "/" + von + " · selbst " + zahl(t => t.selbst) + "/" + von, "zelle-teil"];
      if (k.teile.every(t => t.verglichen)) return ["selbst " + zahl(t => t.selbst) + "/" + von + " · ungeprüft", ""];
      return ["Entwurf", ""];
    }
    const aufgaben = r.aufgaben;
    const tab = h("table", {}, h("thead", {}, h("tr", {}, h("th", {}, ""), h("th", {}, "Name"), h("th", {}, "Thema"), aufgaben.map(a => h("th", {}, "A" + a)), h("th", { title: "aus der Abgabe nachgerechnet: Selbstcheck neu, Antworten gegen den Prüfstoff" }, "Sterne"), h("th", { title: "War die Lösung vor dieser Abgabe offen? ★ = Sterne des Themas in dem Moment, als sie geöffnet wurde · Fehlversuche am Kennwort" }, "Lösung"), h("th", {}, "Hilfen"), h("th", {}, "Selbstcheck"), h("th", {}, "Mini-Exit"))));
    const tb = h("tbody", {});
    for (const z of r.zeilen) {
      const tr = h("tr", { class: z.fehlt ? "fehlt" : "" });
      tr.append(h("td", {}, z.nr != null ? h("input", { type: "checkbox", onchange: ev => { if (ev.target.checked) auswahl.add(z.nr); else auswahl.delete(z.nr); } }) : ""));
      tr.append(h("td", {}, z.name + (z.hinweis ? " ⚠" : ""), z.partner ? h("span", { class: "mit", title: "in der Abgabe als Partner(in) genannt" }, "mit " + z.partner) : null),
        h("td", {}, z.thema || (z.fehlt ? "— keine Abgabe —" + (z.partner_von ? " (arbeitete mit " + z.partner_von + ")" : "") : "")));
      for (const a of aufgaben) { const c = (z.aufgaben || {})[a]; let cls = "", txt = "";
        // Plan (19.10.): „Plan 3/4“ aus der Abgabe nachgerechnet; ein Klick klappt das Bild darunter auf
        if (c && c.plan) { const td = h("td", { class: "x plan-zelle " + (c.plan.ok === c.plan.von ? "zelle-passt" : c.plan.ok ? "zelle-teil" : "zelle-null"), title: "Plan ansehen", onclick: () => planDetail(tr, z, a, c.plan, td) },
          "Plan " + c.plan.ok + "/" + c.plan.von + (c.sterne ? " · ★" + c.sterne[0] + "/" + c.sterne[1] : "") + (c.hilfen ? " h" + c.hilfen : "")); tr.append(td); continue; }
        if (c && c.diagramm) { const td = h("td", { class: "x plan-zelle " + (c.diagramm.ok ? "zelle-passt" : "zelle-null"), title: "Klassendiagramm ansehen", onclick: () => diagrammDetail(tr, z, a, c.diagramm) },
          "Diagramm " + (c.diagramm.ok ? "✓" : "✗") + (c.sterne ? " · ★" + c.sterne[0] + "/" + c.sterne[1] : "") + (c.hilfen ? " h" + c.hilfen : "")); tr.append(td); continue; }
        if (c && c.klausur) { const [txt, cls] = klausurZelle(c.klausur), td = h("td", { class: "x plan-zelle " + cls, title: "Text lesen und prüfen", onclick: () => klausurDetail(tr, z, a, c.klausur) },
          txt + (c.sterne ? " · ★" + c.sterne[0] + "/" + c.sterne[1] : "") + (c.hilfen ? " h" + c.hilfen : "")); tr.append(td); continue; }
        if (c) { if (c.sterne) { txt = "★" + c.sterne[0] + "/" + c.sterne[1] + (c.sterne[2] > c.sterne[0] ? " · ★" + c.sterne[2] + " versucht" : ""); cls = c.sterne[0] === c.sterne[1] ? "zelle-passt" : c.sterne[0] ? "zelle-teil" : "zelle-null"; } else if (c.sc) { txt = c.sc.passt + "/" + c.sc.von; cls = c.sc.passt === c.sc.von ? "zelle-passt" : c.sc.passt ? "zelle-teil" : "zelle-null"; } if (c.haken) txt += " " + c.haken; if (c.hilfen) txt += " h" + c.hilfen; } tr.append(h("td", { class: "x " + cls }, txt)); }
      // Sterne des Themas (16.10.): Summe / Höchstzahl, Ziel, welche Pflichtaufgabe noch keinen Stern hat
      const sz = z.sterne;
      tr.append(h("td", { class: "x " + (sz ? (sz.geschafft ? "zelle-passt" : "zelle-teil") : ""), title: sz && !sz.nachgerechnet ? "Selbstauskunft des Stands -- Selbstcheck nicht nachgelaufen" : "" },
        sz ? "★ " + sz.summe + "/" + sz.max + (sz.mindest ? " · Ziel " + sz.mindest : "") + (sz.ohne_stern.length ? " · ohne ★: A" + sz.ohne_stern.join(", A") : "") + (sz.nachgerechnet ? "" : " (?)") : ""));
      // Lösung (16.11.2026): offen vor der Abgabe? Wie weit war das Thema da, wie oft wurde am Kennwort geraten?
      const ls = z.loesung, lst = ls && ls.sterne, fv = ls && ls.fehlversuche ? ls.fehlversuche + (ls.fehlversuche === 1 ? " Fehlversuch" : " Fehlversuche") : "";
      const frueh = !!(ls && ls.geoeffnet && lst && lst.mindest && lst.summe < lst.mindest);
      tr.append(h("td", { class: "x " + (frueh || (ls && ls.fehlversuche >= 10) ? "zelle-null" : ""), title: ls && ls.geoeffnet ? "geöffnet " + String(ls.geoeffnet).replace("T", " ").slice(0, 16) : "" },
        !ls ? "" : ls.geoeffnet ? (frueh ? "⚑ " : "") + "offen" + (lst ? " bei ★ " + lst.summe + "/" + lst.max : "") + (fv ? " · " + fv : "") : "zu" + (fv ? " · " + fv : "")));
      tr.append(h("td", { class: "x" }, z.hilfen != null ? String(z.hilfen) : ""), h("td", { class: "x" }, z.selbstcheck ? z.selbstcheck.passt + " von " + z.selbstcheck.von + (z.selbstcheck.fehler ? " ⚠" : "") : ""), h("td", {}, z.miniexit || ""));
      tb.append(tr);
    }
    tab.append(tb); ergebnis.append(tab);
    // Wie in der Klausur (09.11.2026): die Texte ohne Namen fuer Claude bereitstellen (_bewertung/zu_pruefen.json)
    if (r.zeilen.some(z => Object.values(z.aufgaben || {}).some(c => c.klausur))) {
      const info = h("span", { class: "leer" });
      ergebnis.append(h("p", { class: "kl-bereit" }, h("button", { onclick: async () => {
        try { const a = await api("uebersicht/klausur_bereitstellen", {}); info.textContent = " " + a.anzahl + " Text(e) ohne Namen bereitgestellt: " + a.datei + " – jetzt Claude sagen: „Klausurtexte prüfen“."; }
        catch (e) { meldung(e.message, "fehler"); } } }, "Klausurtexte für Claude bereitstellen"), info));
    }
    if (r.summen) { const su = h("ul", {}); for (const [k, v] of Object.entries(r.summen)) su.append(h("li", {}, k + ": " + v)); ergebnis.append(h("h3", {}, "Für die Klasse"), su); }
    // „Ich kann …“ der Klasse (Rang 12, Lehrer 16.10.: nur anonym) -- je Satz und Runde gezählt
    if ((r.einschaetzung || []).length) ergebnis.append(einschaetzungKlasse(r.einschaetzung));
    // Lernkarten der Klasse (Rang 15, 16.10.): welche Karten bei den meisten in Fach 1 hängen -- ohne Namen
    if (r.lernkarten && r.lernkarten.karten.length) ergebnis.append(lernkartenKlasse(r.lernkarten));
    // Anmerkungen der Klasse -- nach Ansicht geordnet, ohne Namen (Lehrerwunsch 14.10.)
    if ((r.anmerkungen || []).length) {
      const box = h("div", { class: "anmerkungen-klasse" }, h("h3", {}, "Anmerkungen der Klasse (" + r.anmerkungen.length + ", ohne Namen)"),
        h("p", { class: "leer" }, "Auf der Seite selbst: „Hängestellen“ oben rechts – dann zeigt jede Ansicht, wo wie viele Nadeln sitzen."),
        // Werkbuch (14.10.): die Uebersicht speichert nichts -- dieser Knopf schreibt die Anmerkungen OHNE Namen ins Werkbuch
        h("p", {}, h("button", { class: "ins-werkbuch", onclick: async ev => { try { const a = await api("werkbuch/klasse", {}); W.daten = null;
          ev.target.textContent = "✓ im Werkbuch"; meldung(a.neu + " Anmerkung(en) neu ins Werkbuch, " + a.schon + " waren schon drin – ohne Namen. Zu sehen im Reiter „Werkbuch“ des Themas."); }
          catch (e) { meldung(e.message, "fehler"); } } }, "Anmerkungen ins Werkbuch"), h("span", { class: "leer" }, " – ohne Namen; die Übersicht selbst speichert weiter nichts.")));
      let titel = null, ul = null;
      for (const a of r.anmerkungen) {
        if (a.titel !== titel) { titel = a.titel; ul = h("ul", {}); box.append(h("div", { class: "at" }, titel || a.route), ul); }
        const art = ARTEN.find(z => z[0] === a.art) || ARTEN[0];
        ul.append(h("li", {}, h("span", { class: "art-chip " + a.art }, art[2] + " " + art[1]), " ", a.text || h("span", { class: "leer" }, "(ohne Text)"), a.ausschnitt ? h("span", { class: "leer" }, " – bei „" + a.ausschnitt.slice(0, 50) + "“") : null));
      }
      ergebnis.append(box);
    }
    // Fehlerbuch der Klasse (B2, Rang 9): je Thema und Fehlerart, wie viele sie getroffen haben -- ohne Namen, ohne Notizen
    if ((r.fehlerbuch || []).length) {
      const box = h("div", { class: "fehlerbuch-klasse" }, h("h3", {}, "Fehlerbuch der Klasse (ohne Namen)"),
        h("p", { class: "leer" }, "Rote Meldungen aus der Shell, gezählt aus den Abgaben – wer sie getroffen hat, steht hier nicht."));
      const tab = h("table", {}, h("thead", {}, h("tr", {}, h("th", {}, "Thema"), h("th", {}, "Fehlerart"), h("th", {}, "Personen"), h("th", {}, "Meldungen"), h("th", {}, "Satz der Seite"))));
      const tb = h("tbody", {});
      for (const z of r.fehlerbuch) tb.append(h("tr", {}, h("td", {}, z.thema), h("td", {}, h("b", {}, z.art)), h("td", { class: "x" }, String(z.personen)), h("td", { class: "x" }, String(z.meldungen)), h("td", { class: "leer" }, z.satz)));
      tab.append(tb); box.append(tab); ergebnis.append(box);
    }
    ergebnis.append(h("p", {}, h("button", { onclick: async () => { const a = await api("besprechung/waehlen", { nummern: [...auswahl], plaene: [...planAuswahl.values()], diagramme: [...diagrammAuswahl.values()] }); meldung(a.anzahl + " Stück(e) für die Besprechung gewählt – ohne Namen. Jetzt „Beamer EIN“ und „Besprechung“."); } }, "Gewählte für die Besprechung (anonym)")));
  }
}

// ─── Besprechung (Lehrer, auch mit Beamer) ─────────────────────────────────────────────────
function besprechungSeite(haupt) {
  kopfZeichnen([["Besprechung", null]]);
  if (!Z.lehrer) { haupt.append(h("p", { class: "seite" }, "Nur in der Lehrerfassung.")); return; }
  const wrap = h("div", { class: "besprechung" });
  const links = h("div", { class: "spalte" }, h("h2", {}, "Abgaben – ohne Namen"));
  const rechts = h("div", { class: "spalte" }, h("h2", {}, "Lösung"));
  wrap.append(links, rechts); haupt.append(wrap);
  api("besprechung/lesen").then(r => {
    // Plaene (19.10.): nebeneinander ueber den Abgaben, je in der Werkstatt -- derselbe Fall laeuft vorne durch beide
    const plaene = r.stuecke.filter(st => st.art === "plan");
    if (plaene.length) {
      const raster = h("div", { class: "plaene-besprechung" }); wrap.before(raster);
      for (const st of plaene) {
        const el = h("div", {});
        raster.append(h("div", { class: "pb-karte" }, h("h3", {}, st.name + " · ohne Namen · Fälle " + st.ok + " von " + st.von), el));
        Werkstaetten.struktogramm(el, { quelle: st.quelle, algorithmus: st.titel, name: st.name, proben: st.proben });
      }
    }
    // Diagramme (13.11.): ebenso nebeneinander, als Bild mit dem Urteil des Selbstchecks
    const diagramme = r.stuecke.filter(st => st.art === "diagramm");
    if (diagramme.length) {
      const raster = h("div", { class: "plaene-besprechung" }); wrap.before(raster);
      for (const st of diagramme) raster.append(h("div", { class: "pb-karte" }, h("h3", {}, st.name + " · ohne Namen · " + (st.ok ? "passt zur Aufgabe" : "noch nicht")),
        h("div", { class: "uml-pd", html: Werkstaetten.klassendiagramm.kern.svg(st.modell, { titel: st.name }) }), st.ok ? null : h("p", { class: "leer" }, (st.meldungen || []).join(" · "))));
    }
    if (!r.stuecke.filter(st => st.art !== "plan" && st.art !== "diagramm").length) { if (r.stuecke.length) { links.append(h("p", { class: "leer" }, "Nur Pläne und Diagramme gewählt – sie stehen oben.")); return; } links.append(h("p", { class: "leer" }, "Noch nichts gewählt. In der Übersicht (bei Beamer aus) Zeilen ankreuzen und „für die Besprechung“ wählen.")); return; }
    for (const st of r.stuecke) {
      if (st.art === "plan" || st.art === "diagramm") continue;
      const box = h("div", { class: "stueck" }, h("div", { class: "st" }, st.name + " · " + (st.thema || "")));
      const ebox = h("div", { class: "editorbox" }); box.append(ebox); links.append(box);
      editor(ebox, st.code || "(keine Arbeitsdatei in der Abgabe)", "python", null, true);
      if (st.selbstcheck) box.append(h("div", { class: "leer" }, "Selbstcheck nachgelaufen: " + st.selbstcheck.passt + " von " + st.selbstcheck.von));
    }
    const t = r.stuecke[0].thema; if (t) api("loesung/lesen", { thema: t }).then(L => { for (const [name, text] of Object.entries(L.loesung.dateien || {})) { rechts.append(h("h3", {}, name)); const b = h("div", { class: "editorbox" }); rechts.append(b); editor(b, text, "python", null, true); } }).catch(() => {});
  });
}
