# alle.py -- alle Figuren einer Art.
# Das Brett zeichnet brett.py.

# erlaubt die eigene Klasse als Typ:
from __future__ import annotations
from brett import FELDGROESSE, zeichne_felder, hebe_hervor, zeige
from zeichenflaeche import zeichne_bild
from figur import Figur

ARTEN = ["Turm", "Springer", "Läufer", "Dame",
         "König", "Läufer", "Springer", "Turm"]


class Spieler:

    def __init__(self, farbe: str):
        self.__farbe = farbe
        self.__figuren: list[Figur] = []

    def aufnehmen(self, figur: Figur) -> None:
        self.__figuren.append(figur)

    def zeichne_alle(self, groesse: int) -> None:
        for figur in self.__figuren:
            zeichne_bild(figur.bildname(), figur.get_spalte() * groesse,
                         figur.get_zeile() * groesse, groesse)

    def finde_art(self, art: str) -> Figur:
        for figur in self.__figuren:
            if figur.get_art() == art:
                return figur
        return None


schwarz = Spieler("schwarz")
for spalte in range(8):
    schwarz.aufnehmen(Figur(ARTEN[spalte], "schwarz", 0, spalte))
    schwarz.aufnehmen(Figur("Bauer", "schwarz", 1, spalte))

zeichne_felder()
schwarz.zeichne_alle(FELDGROESSE)
zeige()
