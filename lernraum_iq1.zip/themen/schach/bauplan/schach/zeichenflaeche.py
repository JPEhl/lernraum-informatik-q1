# zeichenflaeche.py -- gegeben: das Fenster
# mit der Zeichenfläche, die Bilder der
# Figuren und der Klick mit der Maus.
# Lesen dürft ihr, ändern nicht.

import tkinter as tk

fenster = None
flaeche = None
geladen = {}


def neue_flaeche(breite: int, hoehe: int) -> tk.Canvas:
    """Öffnet ein Fenster mit einer weißen Zeichenfläche."""
    global fenster, flaeche
    fenster = tk.Tk()
    fenster.title("Schach")
    fenster.resizable(False, False)
    flaeche = tk.Canvas(fenster, width=breite, height=hoehe,
                        bg="white", highlightthickness=0)
    flaeche.pack()
    geladen.clear()
    return flaeche


def zeichne_bild(name: str, x: int, y: int, groesse: int) -> None:
    """Setzt das Bild der Figur name mitten in ein Feld:
    Ecke oben links bei (x, y), groesse Pixel breit."""
    stufe = max(30, min(70, groesse // 10 * 10))
    datei = "bilder/%d/%s.png" % (stufe, name)
    if datei not in geladen:
        geladen[datei] = tk.PhotoImage(master=fenster, file=datei)
    flaeche.create_image(x + groesse // 2, y + groesse // 2,
                         image=geladen[datei])


def bei_klick(funktion) -> None:
    """Ruft ab jetzt bei jedem Klick auf die Zeichenfläche
    funktion(x, y) auf: x und y sind die Pixel der Stelle,
    gezählt von der Ecke oben links."""
    def weitergeben(ereignis) -> None:
        funktion(ereignis.x, ereignis.y)
    flaeche.bind("<Button-1>", weitergeben)


def zeige() -> None:
    """Zeigt das Fenster, bis es jemand schließt.
    Pfeile liegen dabei über den Figuren."""
    for ding in flaeche.find_all():
        if flaeche.type(ding) == "line":
            flaeche.tag_raise(ding)
    fenster.mainloop()
