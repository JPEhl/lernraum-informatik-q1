# figur.py -- die Klasse Figur, gekapselt.
# Neu dazugelegt: In passt steht der Bauer
# (er zieht geradeaus), unten bildname.

# erlaubt die eigene Klasse als Typ:
from __future__ import annotations


class Figur:

    def __init__(self, art: str, farbe: str, zeile: int, spalte: int):
        self.__art = art
        self.__farbe = farbe
        self.__zeile = 0
        self.__spalte = 0
        self.set_zeile(zeile)
        self.set_spalte(spalte)

    def get_art(self) -> str:
        return self.__art

    def get_farbe(self) -> str:
        return self.__farbe

    def get_zeile(self) -> int:
        return self.__zeile

    def get_spalte(self) -> int:
        return self.__spalte

    def set_zeile(self, zeile: int) -> None:
        if zeile >= 0 and zeile <= 7:
            self.__zeile = zeile

    def set_spalte(self, spalte: int) -> None:
        if spalte >= 0 and spalte <= 7:
            self.__spalte = spalte

    def get_wert(self) -> int:
        if self.__art == "Bauer":
            return 1
        elif self.__art == "Springer" or self.__art == "Läufer":
            return 3
        elif self.__art == "Turm":
            return 5
        elif self.__art == "Dame":
            return 9
        else:
            return 0

    def ist_gegner(self, andere: Figur) -> bool:
        return self.__farbe != andere.get_farbe()

    def passt(self, zeile: int, spalte: int) -> bool:
        hoch = abs(zeile - self.__zeile)
        quer = abs(spalte - self.__spalte)
        if hoch == 0 and quer == 0:
            return False
        if self.__art == "Turm":
            return hoch == 0 or quer == 0
        elif self.__art == "Läufer":
            return hoch == quer
        elif self.__art == "Dame":
            return hoch == 0 or quer == 0 or hoch == quer
        elif self.__art == "König":
            return hoch <= 1 and quer <= 1
        elif self.__art == "Springer":
            return hoch * quer == 2
        # neu dazugelegt: Der Bauer zieht
        # geradeaus, vom Start auch zwei Felder.
        elif self.__art == "Bauer":
            if self.__farbe == "weiß":
                vor = self.__zeile - zeile
                am_start = self.__zeile == 6
            else:
                vor = zeile - self.__zeile
                am_start = self.__zeile == 1
            return quer == 0 and (vor == 1 or (vor == 2 and am_start))
        else:
            return False

    def ziehen(self, zeile: int, spalte: int) -> bool:
        if not self.passt(zeile, spalte):
            return False
        self.set_zeile(zeile)
        self.set_spalte(spalte)
        return True

    # neu dazugelegt: der Name des Bildes
    def bildname(self) -> str:
        name = self.__art.lower()
        name = name.replace("ä", "ae").replace("ö", "oe")
        return name + "-" + self.__farbe[0]
