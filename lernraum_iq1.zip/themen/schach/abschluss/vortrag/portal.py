# portal.py -- das Schachportal: Die
# Kopfzeile sortiert die Liste, ein Klick
# auf eine Zeile sucht ihre Wertung durch
# Halbieren.

from anzeige import neue_anzeige, zeichne_rangliste
from anzeige import bei_klick, zeige
from mitglieder import alle_mitglieder
from rangliste import Rangliste

rangliste = Rangliste()
for mitglied in alle_mitglieder():
    rangliste.aufnehmen(mitglied)

durchgaenge = 0


def klick(zeile: int) -> None:
    global durchgaenge
    markiert = -1
    if zeile == -1:
        rangliste.sortiere()
        durchgaenge = rangliste.anzahl() - 1
        print("Durchgänge:", durchgaenge,
              "Vergleiche:", rangliste.get_vergleiche())
    else:
        wertung = rangliste.get_mitglied(zeile).get_wertung()
        markiert = rangliste.finde_position_binaer(wertung)
        print("Wertung", wertung, "-> Index", markiert,
              "nach", rangliste.get_fragen(), "Fragen")
    zeichne_rangliste(rangliste, durchgaenge, markiert)


def messreihe() -> None:
    for anzahl in [5, 10, 20]:
        probe = Rangliste()
        mitglieder = alle_mitglieder()
        for platz in range(anzahl):
            probe.aufnehmen(mitglieder[platz])
        probe.sortiere()
        print(anzahl, "Mitglieder:", probe.get_vergleiche(), "Vergleiche")


messreihe()
neue_anzeige(rangliste.anzahl())
zeichne_rangliste(rangliste, durchgaenge)
bei_klick(klick)
zeige()
