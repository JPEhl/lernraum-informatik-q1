# bedrohung.py -- eine Figur bedroht eine
# andere (Aufgabe 3). Hier wohnt die
# Klasse.

# erlaubt die eigene Klasse als Typ:
from __future__ import annotations
from figur import Figur
