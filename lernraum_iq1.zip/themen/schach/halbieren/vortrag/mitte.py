# mitte.py -- sieben Wertungen, sortiert:
# eine Frage der binären Suche.


class Wertungen:

    def __init__(self, zahlen: list[int]):
        self.__zahlen = zahlen

    def erste_frage(self, gesucht: int) -> None:
        zahlen = self.__zahlen
        print(zahlen)


wertungen = Wertungen(
    [1048, 1105, 1163, 1215,
     1290, 1342, 1418]
)
wertungen.erste_frage(1342)
