# portal.py -- das Schachportal.
# Vorbereitet für dieses Thema: Die Liste
# ist sortiert. Ein Klick sucht die
# Wertung der Zeile -- mit der Methode
# finde_position_binaer, die ihr in
# rangliste.py schreibt.

from anzeige import neue_anzeige, zeichne_rangliste
from anzeige import bei_klick, zeige
from mitglieder import alle_mitglieder
from rangliste import Rangliste

rangliste = Rangliste()
for mitglied in alle_mitglieder():
    rangliste.aufnehmen(mitglied)

markiert = -1


def klick(zeile: int) -> None:
    global markiert
    if zeile == -1:
        wertung = 1400
    else:
        wertung = rangliste.get_mitglied(zeile).get_wertung()
    markiert = rangliste.finde_position_binaer(wertung)
    zeichne_rangliste(rangliste, rangliste.anzahl(), markiert)


def messreihe() -> None:
    for anzahl in [5, 10, 20]:
        probe = Rangliste()
        mitglieder = alle_mitglieder()
        for platz in range(anzahl):
            probe.aufnehmen(mitglieder[platz])
        probe.sortiere()
        print(anzahl, "Mitglieder:", probe.get_vergleiche(), "Vergleiche")


messreihe()
rangliste.sortiere()
neue_anzeige(rangliste.anzahl())
zeichne_rangliste(rangliste, rangliste.anzahl(), markiert)
bei_klick(klick)
zeige()
