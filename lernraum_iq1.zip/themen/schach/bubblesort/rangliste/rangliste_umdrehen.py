# rangliste_umdrehen.py -- Experten-
# aufgabe: die Liste umdrehen, mit
# wenigen Täuschen. Kopiert eure Klasse
# Rangliste hierher.

# erlaubt die eigene Klasse als Typ:
from __future__ import annotations
from mitglied import Mitglied
