# figur_feld.py -- Aufgabe 6: eure Figur,
# innen anders. Das Feld steht als Text
# wie "d5". Kopiert eure Klasse hierher.

# erlaubt die eigene Klasse als Typ:
from __future__ import annotations
