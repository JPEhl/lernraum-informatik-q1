# riss.py -- die Dame zieht wie bisher:
# Der Zug führt sich selbst aus. kleines_spiel.py
# ist das Spiel aus spielfeld.py.

from brett import zeichne_felder, hebe_hervor, zeichne_pfeil, FELDGROESSE
from zeichenflaeche import zeige
from kleines_spiel import Spiel
from zug import Zug

spiel = Spiel()
dame = spiel.figur_auf(7, 3)
zug = Zug(dame, 3, 3)

zeichne_felder()
zeichne_pfeil(zug)
zug.ausfuehren()
spiel.zeichne(FELDGROESSE)
hebe_hervor(dame.get_zeile(), dame.get_spalte())
print(spiel.figur_auf(3, 3))
zeige()
