# portal.py -- das Schachportal: Ein Klick
# auf die Liste ist ein Durchgang, ein
# Klick auf die Kopfzeile sortiert alles.

from anzeige import neue_anzeige, zeichne_rangliste
from anzeige import bei_klick, zeige
from mitglieder import alle_mitglieder
from rangliste import Rangliste

rangliste = Rangliste()
for mitglied in alle_mitglieder():
    rangliste.aufnehmen(mitglied)

durchgaenge = 0


def klick(zeile: int) -> None:
    global durchgaenge
    if zeile == -1:
        rangliste.sortiere()
        durchgaenge = rangliste.anzahl() - 1
    elif durchgaenge < rangliste.anzahl() - 1:
        durchgaenge = durchgaenge + 1
        rangliste.durchgang(durchgaenge)
    print("Durchgänge:", durchgaenge,
          "Vergleiche:", rangliste.get_vergleiche())
    zeichne_rangliste(rangliste, durchgaenge)


def messreihe() -> None:
    for anzahl in [5, 10, 20]:
        probe = Rangliste()
        mitglieder = alle_mitglieder()
        for platz in range(anzahl):
            probe.aufnehmen(mitglieder[platz])
        probe.sortiere()
        print(anzahl, "Mitglieder:", probe.get_vergleiche(), "Vergleiche")


messreihe()
neue_anzeige(rangliste.anzahl())
zeichne_rangliste(rangliste, durchgaenge)
bei_klick(klick)
zeige()
