# zahlen.py -- vier Wertungen, klein:
# Bubblesort als Methode einer Klasse.


class Wertungen:

    def __init__(self, zahlen: list[int]):
        self.__zahlen = zahlen

    def get_zahlen(self) -> list[int]:
        return self.__zahlen

    def sortiere(self) -> None:
        zahlen = self.__zahlen
        for nummer in range(1, len(zahlen)):
            for platz in range(len(zahlen) - nummer):
                if zahlen[platz] > zahlen[platz + 1]:
                    merke = zahlen[platz]
                    zahlen[platz] = zahlen[platz + 1]
                    zahlen[platz + 1] = merke


wertungen = Wertungen([1480, 1215, 1630, 1342])
wertungen.sortiere()
print(wertungen.get_zahlen())
