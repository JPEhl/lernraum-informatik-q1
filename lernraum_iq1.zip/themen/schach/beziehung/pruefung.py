"""Selbstcheck „Assoziation und Aggregation“ -- prueft das Programm im Ordner schach/ (es laeuft partie.py).

Der Zug kennt seine Figur. Der Check prueft die Klassen ueber OBJEKTE, die er selbst baut (LC8): erzeuge, rufe --
und ob ein Zug DIESELBE Figur haelt (`is`), nicht eine gleiche.

Seit dem Umbau nach Schnitt A (15.11.2026) ist partie.py ein Programm mit Klick: Ein Klick auf ein Ziel legt einen
Zug an. Das Brett liest der Check an einem FRISCHEN Lauf, auf dem er klickt wie die Maus (klick_auf, LC6): die Pfeile
als Linien von Feldmitte zu Feldmitte, das Bild auf einem Feld, Rahmen und Punkte.

Vorsicht (LC5, Falle „das Wort steht schon im Programm“): Die Startfassung von zug.py haelt jedes Objekt, das man ihr
gibt -- Python prueft den Typ nicht. Was sich in Aufgabe 2 ★ aendert, ist partie.py (Zug(gewaehlt, …) statt des
Wortes) und der Typ im Kopf von zug.py. Deshalb prueft ★ das Brett und den Typ, nicht nur get_figur.

Wer faerbt was (LC3): Solange der Zug kein ausfuehren hat, liest Aufgabe 2 ★ das Brett (ein Klick zeigt den Pfeil
von der gewaehlten Figur zum Ziel, gezogen wird nicht). Sobald er es hat, gehoert das Brett Aufgabe 2 ★★ (die Figur
zieht, der Pfeil des letzten Zugs bleibt). Die Bedrohung holt der Check aus bedrohung.py, auch wenn partie.py sie
noch nicht laedt.

Startzustand (Arbeitsordner, vorbereitet): Im Zug steht ein Wort, ein Klick auf ein Ziel bricht im Pfeil ab. Die
Grundlage passt -- der Abbruch ist Aufgabe 2 (LC1). Offen ist genau Aufgabe 2 ★, alles andere wartet.
"""
import ast
import importlib
import sys

import pruefen
from pruefen import erwarte, braucht, arbeit, flaeche, quelltext, anspielen, erzeuge, rufe, klasse, angaben, \
    klick_auf

TITEL = "Assoziation und Aggregation · Selbstcheck"
EINGABEN = []
HINTS = {"get_figur": {"Figur"}, "get_zeile": {"int"}, "get_spalte": {"int"}, "get_start_zeile": {"int"},
         "get_start_spalte": {"int"}, "ausfuehren": {"bool"}, "beschreibung": {"str"}, "get_angreifer": {"Figur"},
         "get_ziel": {"Figur"}, "ist_echt": {"bool"}}
DIAGRAMMTYPEN = {"String", "integer", "boolean", "Integer", "Boolean"}
BLAU = "#1565c0"
DAME, TURM, LAEUFER, SPRINGER, KOENIG, BAUER = (7, 3), (7, 0), (7, 2), (7, 6), (7, 4), (1, 1)


def _soll(art, von, zeile, spalte):
    """Die Gangart nach diesem Thema: Turm, Laeufer, Dame wie bisher, dazu Springer und Koenig."""
    hoch, quer = abs(zeile - von[0]), abs(spalte - von[1])
    if hoch == 0 and quer == 0:
        return False
    if art == "Turm":
        return hoch == 0 or quer == 0
    if art == "Läufer":
        return hoch == quer
    if art == "Dame":
        return hoch == 0 or quer == 0 or hoch == quer
    if art == "König":
        return hoch <= 1 and quer <= 1
    if art == "Springer":
        return hoch * quer == 2
    return False


def _ziele(art, von):
    return {(z, s) for z in range(8) for s in range(8) if _soll(art, von, z, s)}


def _wo(feld):
    return "Zeile %d, Spalte %d" % tuple(feld)


def _spiel():
    """partie.py noch einmal, frisch. Gibt (Flaeche, Feldgroesse, letzte Fehlerzeile) -- die Flaeche ist None, wenn
    das Programm nicht bis zum Ende lief."""
    alt_q = pruefen._QUELLE
    pruefen._QUELLE = alt_q + "\nprint('--ENDE--')\n"
    try:
        aus, ns = anspielen([])
    finally:
        pruefen._QUELLE = alt_q
    zeilen = [z for z in aus.strip().splitlines() if z.strip() and "--ENDE--" not in z]
    fehler = zeilen[-1] if zeilen and "Error" in zeilen[-1] else ""
    return (ns.get("flaeche") if "--ENDE--" in aus else None), ns.get("FELDGROESSE"), fehler


def _klick(c, feld, g):
    """Klickt wie die Maus mitten auf das Feld -- auf der Flaeche c eines frischen Laufs. Gibt, was in der Shell
    erschien."""
    alt = pruefen._FENSTER
    pruefen._FENSTER = c.winfo_toplevel()
    try:
        return klick_auf(feld[1] * g + g // 2, feld[0] * g + g // 2, wo=_wo(feld))
    finally:
        pruefen._FENSTER = alt


def _bild(c, feld, g):
    x, y = feld[1] * g + g // 2, feld[0] * g + g // 2
    for i in reversed(c.find_all()):
        if c.type(i) == "image":
            b = c.bbox(i)
            if b and b[0] <= x < b[2] and b[1] <= y < b[3]:
                return pruefen._bilddatei(c, c.itemcget(i, "image"))
    return None


def _markiert(c, g):
    """Die markierten Felder auf c als Menge von (zeile, spalte): das rot gerahmte Feld der gewaehlten Figur und die
    Felder mit einem Punkt -- ihre Ziele (seit 16.11.2026; ein Rahmen als Ziel zaehlt weiter)."""
    felder = set()
    for i in c.find_all():
        if c.type(i) == "rectangle" and not c.itemcget(i, "fill") and c.itemcget(i, "outline"):
            x1, y1, x2, y2 = (round(v) for v in c.coords(i))
            if x1 % g == 0 and y1 % g == 0 and x2 - x1 == g and y2 - y1 == g:
                felder.add((y1 // g, x1 // g))
        elif c.type(i) == "oval":
            # ein Punkt mitten im Feld: ein Ziel (seit 16.11.2026 zeichnet zeige_ziele Punkte statt Rahmen)
            x1, y1, x2, y2 = (round(v) for v in c.coords(i))
            if (x1 + x2) // 2 % g == g // 2 and (y1 + y2) // 2 % g == g // 2:
                felder.add(((y1 + y2) // 2 // g, (x1 + x2) // 2 // g))
    return felder


def _pfeile(c, g, blau):
    """Die Linien auf c als Liste (von Feld, nach Feld) -- blau=True nur die blauen (Zuege), blau=False alle anderen
    (Bedrohungen)."""
    aus = []
    for i in c.find_all():
        if c.type(i) == "line":
            k = c.coords(i)
            ist_blau = str(c.itemcget(i, "fill")).lower() == BLAU
            if ist_blau == blau:
                aus.append(((int(k[1]) // g, int(k[0]) // g), (int(k[-1]) // g, int(k[-2]) // g)))
    return aus


def _ok(pruefung):
    """Passt eine Pruefung? (nur fuer braucht -- faengt den Befund, LC8)"""
    try:
        pruefung()
    except AssertionError:
        return False
    return True


def _modul(name):
    """Ein Modul aus dem Ordner des Programms -- das geladene, sonst frisch importiert; None, wenn es nicht geht."""
    m = sys.modules.get(name)
    if m is not None:
        return m
    try:
        return importlib.import_module(name)
    except Exception:  # noqa: BLE001 -- dann gibt es das Modul fuer den Check nicht
        return None


def _aus(datei, name):
    m = _modul(datei)
    k = getattr(m, name, None) if m is not None else None
    return k if isinstance(k, type) else None


def _feld_von(figur):
    return (rufe(figur, "get_zeile"), rufe(figur, "get_spalte"))


def pruefe_00_grundlage():
    """Grundlage · figur.py und zug.py laden, und partie.py hat eine Zeichenfläche"""
    erwarte(klasse("Figur") is not None, "figur.py lädt nicht mehr -- partie.py bricht beim Laden ab. Seht in der "
            "Shell nach.")
    erwarte(klasse("Zug") is not None, "zug.py lädt nicht mehr -- partie.py bricht beim Laden ab. Seht in der Shell "
            "nach.")
    erwarte(flaeche() is not None, "Das Programm bricht ab, bevor es eine Zeichenfläche hat -- seht in der Shell nach.")


def _haelt_die_figur():
    """Der Teil von Aufgabe 2 ★, der die KLASSE prueft."""
    turm = erzeuge("Figur", "Turm", "schwarz", 2, 5)
    zug = erzeuge("Zug", turm, 2, 0)
    erwarte(rufe(zug, "get_figur") is turm, "Zug(turm, 2, 0).get_figur() gibt nicht den Turm zurück, den der Zug "
            "bekommen hat.")
    a = angaben("Zug", "__init__")
    typ = dict(a.parameter).get("figur") if a is not None else None
    erwarte(typ == "Figur", "Im Konstruktor von Zug steht beim Parameter figur noch der Typ %s -- im Fach steht jetzt "
            "eine Figur." % typ)
    r = angaben("Zug", "get_figur")
    erwarte(r is not None and r.rueckgabe == "Figur", "get_figur gibt eine Figur zurück -- hinter der Klammer steht "
            "noch %s." % (r.rueckgabe if r is not None else "nichts"))


def pruefe_20_figur_im_zug():
    """Aufgabe 2 · Der Zug hält die Figur selbst -- ein Klick zeigt seinen Pfeil"""
    braucht(klasse("Zug") is not None and klasse("Figur") is not None, "Erst laden figur.py und zug.py wieder.")
    if not hasattr(klasse("Zug"), "ausfuehren"):
        # bis zur Stufe ★★ liest DIESE Pruefung das Brett: Ein Klick auf ein Ziel zeigt den Pfeil, niemand zieht
        c, g, fehler = _spiel()
        erwarte(c is not None, "partie.py bricht schon beim Start ab%s." % (" (%s)" % fehler if fehler else ""))
        try:
            _klick(c, (3, 3), g)
        except pruefen.Offen:
            erwarte(False, "Die Dame ist gewählt, und ein Klick auf Zeile 3, Spalte 3 bricht ab -- die Shell sagt, in "
                    "welcher Zeile. Was steht im Fach figur des Zugs, und kann das nach seinem Feld gefragt werden?")
        erwarte((DAME, (3, 3)) in _pfeile(c, g, True), "Nach einem Klick auf Zeile 3, Spalte 3 fehlt der blaue Pfeil "
                "von der Dame auf Zeile 7, Spalte 3 dorthin.")
    _haelt_die_figur()


def _zug_zieht():
    """Der Teil von Aufgabe 2 ★★, der die KLASSE prueft: ausfuehren zieht die Figur und gibt ihre Antwort weiter, das
    Startfeld merkt sich der Zug beim Anlegen."""
    k = klasse("Zug")
    erwarte(hasattr(k, "ausfuehren"), "Der Zug hält seine Figur, ausführen kann er sich noch nicht -- die Methode "
            "steht im Diagramm.")
    turm = erzeuge("Figur", "Turm", "schwarz", 2, 5)
    zug = erzeuge("Zug", turm, 2, 0)
    antwort = rufe(zug, "ausfuehren")
    erwarte(_feld_von(turm) == (2, 0), "Zug(turm, 2, 0).ausfuehren() lässt den Turm nicht nach Zeile 2, Spalte 0 "
            "ziehen -- er steht auf %s." % _wo(_feld_von(turm)))
    erwarte(antwort is True, "Der Zug gilt, ausfuehren gibt aber %r zurück -- im Diagramm steht dahinter boolean. Wer "
            "weiß, ob der Zug galt?" % (antwort,))
    ohne = [m for m in ("get_start_zeile", "get_start_spalte") if not hasattr(k, m)]
    erwarte(not ohne, "Der Zug zieht seine Figur. Wo sie vorher stand, weiß er aber nicht mehr -- im Diagramm stehen "
            "dafür start_zeile und start_spalte mit ihren Gettern.")
    start = (rufe(zug, "get_start_zeile"), rufe(zug, "get_start_spalte"))
    erwarte(start == (2, 5), "Ein Turm stand auf Zeile 2, Spalte 5, als sein Zug angelegt wurde. Nach dem Ausführen "
            "nennt der Zug als Start %s -- wann fragt er seine Figur, wo sie steht?" % _wo(start))
    turm = erzeuge("Figur", "Turm", "schwarz", 2, 5)
    antwort = rufe(erzeuge("Zug", turm, 4, 6), "ausfuehren")
    erwarte(antwort is False and _feld_von(turm) == (2, 5), "Ein Turm auf Zeile 2, Spalte 5 kann nicht nach Zeile 4, "
            "Spalte 6. Sein Zug gibt beim Ausführen %r zurück, und der Turm steht auf %s."
            % (antwort, _wo(_feld_von(turm))))


def pruefe_25_zug_zieht():
    """Aufgabe 2 ★★ · Der Zug zieht seine Figur, und der letzte Zug bleibt als Pfeil"""
    braucht(_ok(pruefe_20_figur_im_zug), "Erst hält der Zug die Figur selbst.")
    _zug_zieht()
    if _aus("bedrohung", "Bedrohung") is not None and not _ok(_bedrohung_stimmt):
        return      # eine Bedrohung, die nicht stimmt, kann das Brett anhalten -- das sagt Aufgabe 3 (LC3)
    c, g, fehler = _spiel()
    erwarte(c is not None, "partie.py bricht ab, bevor das Brett fertig ist%s." % (" (%s)" % fehler if fehler else ""))
    _klick(c, (3, 3), g)
    erwarte(_bild(c, (3, 3), g) == "dame-w.png", "Die Dame ist gewählt, ein Klick auf Zeile 3, Spalte 3 lässt sie "
            "aber nicht dorthin ziehen -- führt klick den Zug aus?")
    blau = _pfeile(c, g, True)
    erwarte(((3, 3), (3, 3)) not in blau, "Die Dame ist gezogen, ihr Pfeil ist aber nur ein Punkt auf ihrem neuen "
            "Feld: zeichne_pfeil fragt noch die Figur, und die steht schon am Ziel. Wer weiß, wo der Zug begann?")
    erwarte(blau == [(DAME, (3, 3))], "Nach dem Zug der Dame von Zeile 7, Spalte 3 nach Zeile 3, Spalte 3 liegt nicht "
            "genau ein blauer Pfeil von dort nach dort auf dem Brett.")
    _klick(c, (4, 5), g)
    erwarte(_bild(c, (3, 3), g) == "dame-w.png" and _pfeile(c, g, True) == [(DAME, (3, 3))], "Ein Klick auf Zeile 4, "
            "Spalte 5 passt nicht zur Dame auf Zeile 3, Spalte 3. Danach soll alles stehen wie vorher -- nur ein "
            "Zug, der galt, wird der letzte Zug.")
    _klick(c, TURM, g)
    _klick(c, (4, 0), g)
    erwarte(_bild(c, (4, 0), g) == "turm-w.png" and _pfeile(c, g, True) == [(TURM, (4, 0))], "Nach dem Zug des Turms "
            "von Zeile 7, Spalte 0 nach Zeile 4, Spalte 0 soll genau sein Pfeil stehen -- der Pfeil der Dame davor "
            "ist weg.")


def _bedrohung_stimmt():
    k = _aus("bedrohung", "Bedrohung")
    erwarte(k is not None, "In bedrohung.py steht noch keine Klasse Bedrohung.")
    dame = erzeuge("Figur", "Dame", "weiß", 3, 3)
    bauer = erzeuge("Figur", "Bauer", "schwarz", 1, 1)
    b = erzeuge(k, dame, bauer)
    ohne = [m for m in ("get_angreifer", "get_ziel") if not hasattr(k, m)]
    erwarte(not ohne, "Der Bedrohung fehlt noch: %s." % ", ".join(ohne))
    erwarte(rufe(b, "get_angreifer") is dame and rufe(b, "get_ziel") is bauer, "Bedrohung(dame, bauer): get_angreifer() "
            "und get_ziel() geben nicht genau die zwei Figuren zurück, die die Bedrohung bekommen hat.")
    erwarte(hasattr(k, "ist_echt"), "Die Bedrohung kennt ihre zwei Figuren. Ob sie echt ist, kann sie noch nicht sagen "
            "-- ist_echt steht im Diagramm.")
    for a_art, a_farbe, a_feld, z_farbe, z_feld, soll, warum in (
            ("Dame", "weiß", (3, 3), "schwarz", (1, 1), True, "sie sind Gegner, und das Feld liegt schräg von ihr"),
            ("Dame", "weiß", (3, 3), "weiß", (1, 1), False, "beide sind weiß"),
            ("Dame", "weiß", (7, 3), "schwarz", (1, 1), False, "sie sind Gegner, aber die Dame kann dort nicht "
                                                                "hinziehen"),
            ("Turm", "schwarz", (1, 6), "weiß", (1, 1), True, "sie sind Gegner, und das Feld liegt in seiner Zeile")):
        an = erzeuge("Figur", a_art, a_farbe, *a_feld)
        ziel = erzeuge("Figur", "Bauer", z_farbe, *z_feld)
        antwort = rufe(erzeuge(k, an, ziel), "ist_echt")
        erwarte(antwort is soll, "%s (%s) auf %s gegen einen Bauern (%s) auf %s: ist_echt() gibt %r statt %r -- %s."
                % (a_art, a_farbe, _wo(a_feld), z_farbe, _wo(z_feld), antwort, soll, warum))


def pruefe_30_bedrohung():
    """Aufgabe 3 · Die Bedrohung kennt Angreifer und Ziel -- echt ist sie für Gegner in Reichweite"""
    braucht(_ok(pruefe_20_figur_im_zug), "Erst hält der Zug die Figur selbst (Aufgabe 2).")
    _bedrohung_stimmt()


def pruefe_35_fuenf_figuren():
    """Aufgabe 3 ★★ · Springer und König ziehen mit, und die Bedrohung des Bauern ist ein roter Pfeil"""
    braucht(_ok(pruefe_30_bedrohung), "Erst die Klasse Bedrohung.")
    braucht(_ok(pruefe_25_zug_zieht), "Erst zieht der Zug seine Figur (Aufgabe 2 ★★) -- dann lässt sich die "
            "Bedrohung am Brett zeigen.")
    von = (4, 2)
    for art, ein, regel in (("Springer", "Ein", "zwei Felder in eine Richtung und eines quer dazu"),
                            ("König", "Ein", "ein Feld weit, in jede Richtung"), ("Turm", "Ein", "gerade"),
                            ("Läufer", "Ein", "schräg"), ("Dame", "Eine", "gerade und schräg")):
        figur = erzeuge("Figur", art, "weiß", *von)
        ja = {(z, s) for z in range(8) for s in range(8) if rufe(figur, "passt", z, s) is True}
        soll = _ziele(art, von)
        zuviel, fehlt = sorted(ja - soll), sorted(soll - ja)
        erwarte(not fehlt, "%s %s auf %s sagt Nein zu %s -- %s %s zieht %s."
                % (ein, art, _wo(von), _wo(fehlt[0]) if fehlt else "", ein.lower(), art, regel))
        erwarte(not zuviel, "%s %s auf %s sagt Ja zu %s -- %s %s zieht %s."
                % (ein, art, _wo(von), _wo(zuviel[0]) if zuviel else "", ein.lower(), art, regel))
    c, g, fehler = _spiel()
    erwarte(c is not None, "partie.py bricht ab, bevor das Brett fertig ist%s." % (" (%s)" % fehler if fehler else ""))
    _klick(c, SPRINGER, g)
    erwarte(_markiert(c, g) == {SPRINGER} | _ziele("Springer", SPRINGER), "Ein Klick auf den weißen Springer auf "
            "Zeile 7, Spalte 6 wählt ihn nicht: Markiert sind nicht sein Feld und seine Ziele.")
    _klick(c, (5, 5), g)
    erwarte(_bild(c, (5, 5), g) == "springer-w.png" and _bild(c, SPRINGER, g) != "springer-w.png", "Der gewählte "
            "Springer zieht nicht von Zeile 7, Spalte 6 nach Zeile 5, Spalte 5 -- oder sein Bild steht noch an festen "
            "Zahlen.")
    _klick(c, KOENIG, g)
    erwarte(_markiert(c, g) == {KOENIG} | _ziele("König", KOENIG), "Ein Klick auf den weißen König auf Zeile 7, "
            "Spalte 4 wählt ihn nicht: Markiert sind nicht sein Feld und seine Ziele.")
    rot = [p for p in _pfeile(c, g, False) if p[1] == BAUER]
    erwarte(not rot, "Der König ist gewählt und bedroht den schwarzen Bauern auf Zeile 1, Spalte 1 nicht -- trotzdem "
            "zeigt ein Pfeil auf ihn.")
    _klick(c, DAME, g)
    _klick(c, (3, 3), g)
    rot = _pfeile(c, g, False)
    erwarte(((3, 3), BAUER) in rot, "Die Dame steht auf Zeile 3, Spalte 3 und ist gewählt: Sie bedroht den schwarzen "
            "Bauern auf Zeile 1, Spalte 1 -- der rote Pfeil von ihr zu ihm fehlt.")
    _klick(c, TURM, g)
    rot = [p for p in _pfeile(c, g, False) if p[1] == BAUER]
    erwarte(not rot, "Jetzt ist der Turm gewählt, und er bedroht den Bauern nicht. Der rote Pfeil steht trotzdem -- "
            "hängt die Bedrohung an der Dame statt an der gewählten Figur?")


def pruefe_60_beschreibung():
    """Aufgabe 6 ★★ · Der Zug stellt sich vor, und die Shell nennt jeden Zug, der galt"""
    braucht(_ok(pruefe_25_zug_zieht), "Erst zieht der Zug seine Figur (Aufgabe 2 ★★).")
    braucht(hasattr(klasse("Zug"), "beschreibung"), "Erst die Methode beschreibung in zug.py.")
    braucht(_aus("bedrohung", "Bedrohung") is None or _ok(_bedrohung_stimmt), "Erst stimmt die Bedrohung (Aufgabe 3) "
            "-- sonst läuft das Brett nicht.")
    # vier verschiedene Ziffern: so zeigt die Reihenfolge, was Start und was Ziel ist (bis 16.11.2026 genügten die
    # Wörter „Turm“, „5“ und „0“ irgendwo im Text -- auch mit vertauschtem Start und Ziel; Reihensichtung, Leser C Nr. 20)
    dame = erzeuge("Figur", "Dame", "weiß", 7, 3)
    zug = erzeuge("Zug", dame, 4, 0)
    text = rufe(zug, "beschreibung")
    erwarte(isinstance(text, str), "beschreibung gibt %r zurück -- erwartet ist ein Text." % (text,))
    ziffern = [z for z in text if z.isdigit()]
    erwarte("Dame" in text and sorted(ziffern) == ["0", "3", "4", "7"], "Eine Dame von Zeile 7, Spalte 3 nach Zeile 4, "
            "Spalte 0: beschreibung gibt „%s“ zurück -- genannt sein sollen die Art, das Startfeld und das Ziel." % text)
    erwarte(sorted(ziffern[:2]) == ["3", "7"], "Eine Dame von Zeile 7, Spalte 3 nach Zeile 4, Spalte 0: beschreibung "
            "gibt „%s“ zurück -- erst das Startfeld, dann das Ziel." % text)
    rufe(zug, "ausfuehren")
    danach = rufe(zug, "beschreibung")
    erwarte(danach == text, "Vor dem Ausführen sagt der Zug „%s“, danach „%s“ -- das Startfeld ist das Feld, auf dem "
            "die Figur stand, als der Zug angelegt wurde." % (text, danach))
    c, g, fehler = _spiel()
    erwarte(c is not None, "partie.py bricht ab, bevor das Brett fertig ist%s." % (" (%s)" % fehler if fehler else ""))
    shell = _klick(c, (3, 3), g)
    erwarte("Dame" in shell, "Die Dame zieht nach Zeile 3, Spalte 3. In der Shell steht: %s -- dort soll der Zug sich "
            "vorstellen." % (shell.strip()[:60] or "nichts"))
    shell = _klick(c, (4, 5), g)
    erwarte(not shell.strip(), "Ein Klick auf Zeile 4, Spalte 5 passt nicht zur Dame -- trotzdem steht in der Shell: "
            "%s" % shell.strip()[:60])


class _Einbahn:
    """Eine Figur, die nur nach oben zieht (die Zeile wird kleiner) -- zurueck fuehrt fuer sie kein Zug."""

    def __init__(self, zeile, spalte):
        self._zeile, self._spalte = zeile, spalte

    def get_art(self):
        return "Bauer"

    def get_farbe(self):
        return "weiß"

    def get_zeile(self):
        return self._zeile

    def get_spalte(self):
        return self._spalte

    def set_zeile(self, zeile):
        if 0 <= zeile <= 7:
            self._zeile = zeile

    def set_spalte(self, spalte):
        if 0 <= spalte <= 7:
            self._spalte = spalte

    def passt(self, zeile, spalte):
        return spalte == self._spalte and zeile < self._zeile

    def ziehen(self, zeile, spalte):
        if not self.passt(zeile, spalte):
            return False
        self._zeile, self._spalte = zeile, spalte
        return True


def pruefe_70_zurueck():
    """Aufgabe 7 ★★★ · zug_zurueck.py: Der Zug nimmt sich zurück -- einmal, und ohne zu ziehen"""
    k = _aus("zug_zurueck", "Zug")
    braucht(k is not None and hasattr(k, "zuruecknehmen"), "Erst die Klasse Zug mit zuruecknehmen in zug_zurueck.py.")
    turm = erzeuge("Figur", "Turm", "schwarz", 2, 5)
    zug = erzeuge(k, turm, 2, 0)
    erwarte(rufe(zug, "zuruecknehmen") is False and _feld_von(turm) == (2, 5), "Ein Zug, der noch nicht ausgeführt "
            "ist, lässt sich nicht zurücknehmen: zuruecknehmen gibt dann False und ändert nichts.")
    erwarte(rufe(zug, "ausfuehren") is True and _feld_von(turm) == (2, 0), "In zug_zurueck.py führt sich der Zug nicht "
            "mehr aus wie in zug.py -- kopiert eure Klasse erst ganz herüber.")
    erwarte(rufe(zug, "ausfuehren") is False and _feld_von(turm) == (2, 0), "Ein Zug lässt sich nur einmal ausführen "
            "-- beim zweiten Mal gibt ausfuehren False zurück und ändert nichts.")
    erwarte(rufe(zug, "zuruecknehmen") is True and _feld_von(turm) == (2, 5), "Nach dem Ausführen stellt "
            "zuruecknehmen die Figur auf ihr Startfeld zurück und gibt True -- der Turm steht auf %s."
            % _wo(_feld_von(turm)))
    erwarte(rufe(zug, "zuruecknehmen") is False, "Zweimal zurücknehmen geht nicht -- beim zweiten Mal gibt "
            "zuruecknehmen False zurück.")
    erwarte(rufe(zug, "ausfuehren") is True and _feld_von(turm) == (2, 0), "Ein zurückgenommener Zug lässt sich wieder "
            "ausführen.")
    turm = erzeuge("Figur", "Turm", "schwarz", 2, 5)
    zug = erzeuge(k, turm, 4, 6)
    rufe(zug, "ausfuehren")
    erwarte(rufe(zug, "zuruecknehmen") is False and _feld_von(turm) == (2, 5), "Ein Zug, der nicht galt, lässt sich "
            "nicht zurücknehmen.")
    einbahn = _Einbahn(5, 2)
    zug = erzeuge(k, einbahn, 3, 2)
    rufe(zug, "ausfuehren")
    rufe(zug, "zuruecknehmen")
    erwarte((einbahn.get_zeile(), einbahn.get_spalte()) == (5, 2), "Die Auflage: Zurück führt kein Zug. Eine Figur, die "
            "nur nach vorn zieht, kommt mit eurem zuruecknehmen nicht auf ihr Startfeld -- ruft es noch ziehen?")
    ohne = [m for m in ("merke_geschlagene", "get_geschlagene") if not hasattr(k, m)]
    erwarte(not ohne, "Zurücknehmen stimmt. Es fehlt noch: %s." % ", ".join(ohne))
    zug = erzeuge(k, erzeuge("Figur", "Turm", "weiß", 2, 5), 2, 0)
    erwarte(rufe(zug, "get_geschlagene") is None, "Ein Zug, der niemanden geschlagen hat, gibt bei get_geschlagene() "
            "None zurück -- kein Objekt.")
    bauer = erzeuge("Figur", "Bauer", "schwarz", 2, 0)
    rufe(zug, "merke_geschlagene", bauer)
    erwarte(rufe(zug, "get_geschlagene") is bauer, "Nach merke_geschlagene(bauer) gibt get_geschlagene() nicht genau "
            "diesen Bauern zurück.")


def pruefe_90_hints():
    """Hinweis · Jede Methode in zug.py und bedrohung.py mit Type Hints (kein Stern)"""
    braucht(_ok(pruefe_20_figur_im_zug), "Erst hält der Zug die Figur selbst.")
    ohne, falsch, diagramm = [], [], []
    for datei in ("zug.py", "bedrohung.py"):
        try:
            baum = ast.parse(quelltext(datei))
        except (SyntaxError, OSError, TypeError):
            continue
        for k in ast.walk(baum):
            if not isinstance(k, ast.FunctionDef):
                continue
            for a in k.args.args + [k]:
                typ = a.annotation if isinstance(a, ast.arg) else a.returns
                if typ is not None and any(isinstance(x, ast.Name) and x.id in DIAGRAMMTYPEN for x in ast.walk(typ)):
                    diagramm.append("%s (%s)" % (k.name, ast.unparse(typ)))
            parameter = [a for a in k.args.args if a.arg != "self"]
            if any(a.annotation is None for a in parameter) or (k.returns is None and k.name != "__init__"):
                ohne.append(k.name)
            elif k.name in HINTS and ast.unparse(k.returns).replace(" ", "") not in HINTS[k.name]:
                falsch.append("%s -> %s" % (k.name, " oder ".join(sorted(HINTS[k.name]))))
    erwarte(not diagramm, "Hier steht ein Typ in der Schreibweise des Diagramms: %s. In Python heißt er str, int, "
            "float oder bool." % ", ".join(diagramm))
    erwarte(not ohne, "Ohne Type Hint (hinter der Klammer oder an einem Parameter): %s. Es läuft auch ohne; "
            "vereinbart ist es trotzdem." % ", ".join(ohne))
    erwarte(not falsch, "Dieser Type Hint passt nicht zu dem, was zurückkommt -- erwartet: %s." % ", ".join(falsch))

