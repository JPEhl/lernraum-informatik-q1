# partie.py -- das Schachbrett.
# Jeder Klick-Zug ist ein Objekt, der
# letzte bleibt als Pfeil. Bedroht die
# gewählte Figur den Bauern, ist das rot.

from zeichenflaeche import neue_flaeche, zeichne_bild, bei_klick, zeige
from figur import Figur
from zug import Zug
from bedrohung import Bedrohung

FELDGROESSE = 60
HELL = "#eeeed2"
DUNKEL = "#769656"

flaeche = neue_flaeche(8 * FELDGROESSE, 8 * FELDGROESSE)


# ------------------------ das Brett

def zeichne_felder() -> None:
    for zeile in range(8):
        for spalte in range(8):
            x = spalte * FELDGROESSE
            y = zeile * FELDGROESSE
            if (zeile + spalte) % 2 == 0:
                farbe = HELL
            else:
                farbe = DUNKEL
            flaeche.create_rectangle(x, y, x + FELDGROESSE, y + FELDGROESSE,
                                     fill=farbe, outline=farbe)


def zeichne_figur(name: str, zeile: int, spalte: int) -> None:
    zeichne_bild(name, spalte * FELDGROESSE, zeile * FELDGROESSE, FELDGROESSE)


def hebe_hervor(zeile: int, spalte: int) -> None:
    x = spalte * FELDGROESSE
    y = zeile * FELDGROESSE
    flaeche.create_rectangle(x, y, x + FELDGROESSE, y + FELDGROESSE,
                             outline="red", width=4)


def zeichne_punkt(zeile: int, spalte: int) -> None:
    x = spalte * FELDGROESSE + FELDGROESSE // 2
    y = zeile * FELDGROESSE + FELDGROESSE // 2
    r = FELDGROESSE // 6
    if (zeile + spalte) % 2 == 0:
        farbe = "#babaa4"
    else:
        farbe = "#5c7543"
    flaeche.create_oval(x - r, y - r, x + r, y + r,
                        fill=farbe, outline=farbe)


def mitte(zeile: int, spalte: int) -> tuple:
    return (spalte * FELDGROESSE + FELDGROESSE // 2,
            zeile * FELDGROESSE + FELDGROESSE // 2)


def zeichne_pfeil(zug: Zug) -> None:
    x1, y1 = mitte(zug.get_start_zeile(), zug.get_start_spalte())
    x2, y2 = mitte(zug.get_zeile(), zug.get_spalte())
    flaeche.create_line(x1, y1, x2, y2, fill="#1565c0", width=6,
                        arrow="last", arrowshape=(18, 22, 7))


def zeichne_bedrohung(bedrohung: Bedrohung) -> None:
    if bedrohung.ist_echt():
        von = mitte(bedrohung.get_angreifer().get_zeile(),
                    bedrohung.get_angreifer().get_spalte())
        nach = mitte(bedrohung.get_ziel().get_zeile(),
                     bedrohung.get_ziel().get_spalte())
        flaeche.create_line(von[0], von[1],
                            nach[0], nach[1],
                            fill="red", width=4,
                            arrow="last",
                            arrowshape=(14, 17, 6))


# ------------------------ die Aufstellung

dame = Figur("Dame", "weiß", 7, 3)
turm = Figur("Turm", "weiß", 7, 0)
laeufer = Figur("Läufer", "weiß", 7, 2)
springer = Figur("Springer", "weiß", 7, 6)
koenig = Figur("König", "weiß", 7, 4)
bauer = Figur("Bauer", "schwarz", 1, 1)
gewaehlt = dame
letzter_zug = None


def zeige_ziele() -> None:
    for zeile in range(8):
        for spalte in range(8):
            if gewaehlt.passt(zeile, spalte):
                zeichne_punkt(zeile, spalte)


def zeichne_alles() -> None:
    flaeche.delete("all")
    zeichne_felder()
    zeichne_figur("turm-s", 0, 0)
    zeichne_figur("springer-s", 0, 1)
    zeichne_figur("laeufer-s", 0, 2)
    zeichne_figur("dame-s", 0, 3)
    zeichne_figur("koenig-s", 0, 4)
    zeichne_figur("laeufer-s", 0, 5)
    zeichne_figur("springer-s", 0, 6)
    zeichne_figur("turm-s", 0, 7)
    for spalte in range(8):
        if spalte != 1:
            zeichne_figur("bauer-s", 1, spalte)
    zeichne_figur("bauer-s", bauer.get_zeile(), bauer.get_spalte())
    for spalte in range(8):
        zeichne_figur("bauer-w", 6, spalte)
    zeichne_figur("turm-w", turm.get_zeile(), turm.get_spalte())
    zeichne_figur("springer-w", 7, 1)
    zeichne_figur("laeufer-w", laeufer.get_zeile(), laeufer.get_spalte())
    zeichne_figur("dame-w", dame.get_zeile(), dame.get_spalte())
    zeichne_figur("koenig-w", koenig.get_zeile(), koenig.get_spalte())
    zeichne_figur("laeufer-w", 7, 5)
    zeichne_figur("springer-w", springer.get_zeile(), springer.get_spalte())
    zeichne_figur("turm-w", 7, 7)
    hebe_hervor(gewaehlt.get_zeile(), gewaehlt.get_spalte())
    zeige_ziele()
    if letzter_zug != None:
        zeichne_pfeil(letzter_zug)
    zeichne_bedrohung(Bedrohung(gewaehlt, bauer))


# ------------------------ der Klick

def klick(x: int, y: int) -> None:
    global gewaehlt, letzter_zug
    spalte = x // FELDGROESSE
    zeile = y // FELDGROESSE
    if dame.get_zeile() == zeile and dame.get_spalte() == spalte:
        gewaehlt = dame
    elif turm.get_zeile() == zeile and turm.get_spalte() == spalte:
        gewaehlt = turm
    elif laeufer.get_zeile() == zeile and laeufer.get_spalte() == spalte:
        gewaehlt = laeufer
    elif springer.get_zeile() == zeile and springer.get_spalte() == spalte:
        gewaehlt = springer
    elif koenig.get_zeile() == zeile and koenig.get_spalte() == spalte:
        gewaehlt = koenig
    else:
        zug = Zug(gewaehlt, zeile, spalte)
        if zug.ausfuehren():
            letzter_zug = zug
    zeichne_alles()


zeichne_alles()
bei_klick(klick)
zeige()
