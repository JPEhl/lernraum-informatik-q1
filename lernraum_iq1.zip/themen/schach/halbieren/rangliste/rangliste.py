# rangliste.py -- die Rangliste des
# Schachportals. Hier arbeitet ihr
# (Aufgabe 2 und 6).

# erlaubt die eigene Klasse als Typ:
from __future__ import annotations
from mitglied import Mitglied


class Rangliste:

    def __init__(self):
        self.__mitglieder: list[Mitglied] = []
        self.__vergleiche = 0

    def aufnehmen(self, mitglied: Mitglied) -> None:
        self.__mitglieder.append(mitglied)

    def anzahl(self) -> int:
        return len(self.__mitglieder)

    def get_mitglied(self, platz: int) -> Mitglied:
        return self.__mitglieder[platz]

    def finde_position(self, name: str) -> int:
        for platz in range(len(self.__mitglieder)):
            if self.__mitglieder[platz].get_name() == name:
                return platz
        return -1

    def durchgang(self, nummer: int) -> None:
        mitglieder = self.__mitglieder
        for platz in range(len(mitglieder) - nummer):
            self.__vergleiche = self.__vergleiche + 1
            if (mitglieder[platz].get_wertung()
                    > mitglieder[platz + 1].get_wertung()):
                merke = mitglieder[platz]
                mitglieder[platz] = mitglieder[platz + 1]
                mitglieder[platz + 1] = merke

    def sortiere(self) -> None:
        for nummer in range(1, len(self.__mitglieder)):
            self.durchgang(nummer)

    def get_vergleiche(self) -> int:
        return self.__vergleiche
