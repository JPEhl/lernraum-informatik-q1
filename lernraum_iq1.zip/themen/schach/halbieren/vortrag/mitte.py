# mitte.py -- sieben Wertungen, sortiert:
# eine Frage der binären Suche.

wertungen = [1048, 1105, 1163, 1215, 1290, 1342, 1418]
gesucht = 1342

print(wertungen)
