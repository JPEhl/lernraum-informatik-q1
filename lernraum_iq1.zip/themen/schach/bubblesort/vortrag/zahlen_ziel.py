# zahlen.py -- vier Wertungen, klein:
# Bubblesort ohne das Portal.

wertungen = [1480, 1215, 1630, 1342]

for durchgang in range(1, len(wertungen)):
    for platz in range(len(wertungen) - durchgang):
        if wertungen[platz] > wertungen[platz + 1]:
            merke = wertungen[platz]
            wertungen[platz] = wertungen[platz + 1]
            wertungen[platz + 1] = merke

print(wertungen)
