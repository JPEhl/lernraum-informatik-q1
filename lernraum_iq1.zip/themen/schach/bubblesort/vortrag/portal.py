# portal.py -- das Schachportal: die
# Mitglieder, wie sie sich angemeldet
# haben. Gegeben sind anzeige.py (das
# Fenster), mitglied.py, mitglieder.py.

from anzeige import neue_anzeige, zeichne_rangliste
from anzeige import bei_klick, zeige
from mitglieder import alle_mitglieder
from rangliste import Rangliste

rangliste = Rangliste()
for mitglied in alle_mitglieder():
    rangliste.aufnehmen(mitglied)

markiert = -1


def klick(zeile: int) -> None:
    global markiert
    markiert = zeile
    if zeile >= 0:
        mitglied = rangliste.get_mitglied(zeile)
        print(mitglied.get_name() + ":", mitglied.get_wertung())
    zeichne_rangliste(rangliste, 0, markiert)


neue_anzeige(rangliste.anzahl())
zeichne_rangliste(rangliste, 0, markiert)
bei_klick(klick)
zeige()
