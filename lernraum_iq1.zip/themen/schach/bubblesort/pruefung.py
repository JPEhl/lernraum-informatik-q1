"""Selbstcheck „Bubblesort“ -- prueft das Programm im Ordner rangliste/ (es laeuft portal.py).

Die Klasse schreibt in rangliste.py durchgang(nummer) und sortiere() (Aufgabe 2), get_vergleiche() (Aufgabe 3 ★) und in
portal.py die Zeile fuer die Shell und messreihe() (Aufgabe 3). Der Check prueft die Klasse ueber OBJEKTE, die er
selbst baut (LC8): eigene Ranglisten mit eigenen Mitgliedern -- nie die zwanzig aus mitglieder.py --, und er liest,
welche OBJEKTE danach auf welchem Platz stehen (nicht nur die Wertungen: Das Mitglied wandert, nicht die Zahl).
Das Portal liest er an einem FRISCHEN Lauf, auf dem er klickt wie die Maus (klick_auf, LC6): eine Zeile der Liste
(ein Durchgang) und die Kopfzeile (alles sortiert).

Wer Aufgabe 6 gemacht hat (frueher Abbruch), braucht weniger Vergleiche: Die Pflichtpruefungen rechnen deshalb mit
beiden Zahlen (LC5) -- der eigenen Rechnung ohne und der mit Abbruch.

Startzustand (= start_rangliste mit vorbereitetem portal.py): die Grundlage passt, offen ist genau Aufgabe 2 ★ (die
Methode durchgang fehlt), alles andere wartet. Steht durchgang, sind Aufgabe 2 ★★ und Aufgabe 3 ★ offen; die
Messreihe (3 ★★) ist dran, sobald beide passen. Mehr 6 wartet, bis durchgang etwas zurückgibt; die Expertenaufgabe,
bis in rangliste_umdrehen.py die Klasse mit umdrehen() steht.
"""
import ast
import importlib
import re
import sys

import pruefen
from pruefen import erwarte, braucht, quelltext, anspielen, erzeuge, rufe, klasse, klick_auf

TITEL = "Bubblesort · Selbstcheck"
EINGABEN = []
HINTS = {"aufnehmen": {"None"}, "anzahl": {"int"}, "get_mitglied": {"Mitglied"}, "finde_position": {"int"},
         "durchgang": {"None", "bool"}, "sortiere": {"None"}, "get_vergleiche": {"int"}, "umdrehen": {"None"}}
DIAGRAMMTYPEN = {"String", "integer", "boolean", "Integer", "Boolean"}
PROBE = [("Ada", 30), ("Bo", 10), ("Cem", 50), ("Dua", 20), ("Eli", 40)]
ANMELDUNG = [("Aylin", 1480), ("Bence", 1215), ("Chiara", 1630), ("Dawit", 1342), ("Emre", 1105), ("Finja", 1577),
             ("Goran", 1290), ("Hanh", 1418), ("Ilias", 1048), ("Jule", 1466), ("Kofi", 1712), ("Liv", 1322),
             ("Milan", 1189), ("Nuria", 1540), ("Oskar", 1401), ("Pari", 1273), ("Quinn", 1433), ("Rosa", 1163),
             ("Samir", 1502), ("Tuana", 1251)]


def _bubble(paare, durchgaenge=None, abbruch=False):
    """Eigene Rechnung des Checks: (Liste, Vergleiche) nach so vielen Durchgaengen (None: alle)."""
    a, v = list(paare), 0
    for d in range(1, len(a) if durchgaenge is None else durchgaenge + 1):
        getauscht = False
        for i in range(len(a) - d):
            v += 1
            if a[i][1] > a[i + 1][1]:
                a[i], a[i + 1] = a[i + 1], a[i]
                getauscht = True
        if abbruch and not getauscht:
            break
    return a, v


def _zahlen(text):
    return [int(z) for z in re.findall(r"\d+", text)]


def _liste(paare, k="Rangliste"):
    """Eine Rangliste der Klasse mit eigenen Mitgliedern -- gibt (Rangliste, [Mitglied-Objekte])."""
    r = erzeuge(k)
    objekte = []
    for name, wertung in paare:
        m = erzeuge("Mitglied", name, wertung)
        objekte.append(m)
        rufe(r, "aufnehmen", m)
    return r, objekte


def _objekte(r):
    return [rufe(r, "get_mitglied", i) for i in range(rufe(r, "anzahl"))]


def _reihe(r):
    """Was auf den Plaetzen steht, wie man es liest: [(Name, Wertung)]."""
    return [(rufe(m, "get_name"), rufe(m, "get_wertung")) for m in _objekte(r)]


def _wertungen(reihe):
    return ", ".join(str(w) for n, w in reihe)


def _spiel():
    """portal.py noch einmal, frisch. Gibt (Shell am Start, Namensraum, letzte Fehlerzeile) -- der Namensraum ist
    None, wenn das Programm nicht bis zum Ende lief."""
    alt = pruefen._QUELLE
    pruefen._QUELLE = alt + "\nprint('--ENDE--')\n"
    try:
        aus, ns = anspielen([])
    finally:
        pruefen._QUELLE = alt
    zeilen = [z for z in aus.strip().splitlines() if z.strip() and "--ENDE--" not in z]
    fehler = zeilen[-1] if zeilen and "Error" in zeilen[-1] else ""
    return "\n".join(zeilen), (ns if "--ENDE--" in aus else None), fehler


def _klick(zeile):
    """Klickt wie die Maus auf eine Zeile der Liste (-1: die Kopfzeile) -- im Fenster des letzten frischen Laufs.
    Gibt, was dabei in der Shell erschien."""
    a = sys.modules.get("anzeige")
    c = a.flaeche
    y = a.KOPF // 2 if zeile < 0 else a.KOPF + zeile * a.ZEILE + a.ZEILE // 2
    alt = pruefen._FENSTER
    pruefen._FENSTER = c.winfo_toplevel()
    try:
        return klick_auf(120, y, wo="die Kopfzeile" if zeile < 0 else "Zeile %d der Liste" % (zeile + 1))
    finally:
        pruefen._FENSTER = alt


def _modul(name):
    m = sys.modules.get(name)
    if m is not None:
        return m
    try:
        return importlib.import_module(name)
    except Exception:  # noqa: BLE001 -- dann gibt es das Modul fuer den Check nicht
        return None


def _ok(pruefung):
    """Passt eine Pruefung? (nur fuer braucht -- faengt den Befund, LC8; auch die Endlosschleife: Die meldet dann
    nur die Pruefung, zu der sie gehoert)"""
    try:
        pruefung()
    except (AssertionError, pruefen._ZuLang):
        return False
    return True


def _methode(datei, name):
    """Der Knoten der Methode im Quelltext -- None, wenn es sie nicht gibt oder die Datei nicht lesbar ist."""
    try:
        baum = ast.parse(quelltext(datei))
    except SyntaxError:
        return None
    for k in ast.walk(baum):
        if isinstance(k, ast.FunctionDef) and k.name == name:
            return k
    return None


def pruefe_00_grundlage():
    """Grundlage · portal.py läuft, und im Fenster steht die Liste der Mitglieder"""
    shell, ns, fehler = _spiel()
    erwarte(ns is not None, "portal.py bricht ab, bevor die Liste im Fenster steht%s -- seht in der Shell nach, in "
            "welcher Zeile." % (" (%s)" % fehler if fehler else ""))
    r = ns.get("rangliste")
    erwarte(r is not None and rufe(r, "anzahl") == 20, "In portal.py gibt es die Rangliste mit den zwanzig Mitgliedern nicht "
            "mehr -- die Zeilen oben in portal.py bleiben, wie sie waren.")


def pruefe_20_durchgang():
    """Aufgabe 2 ★ · durchgang(nummer): ein Durchgang -- die Mitglieder tauschen den Platz"""
    k = klasse("Rangliste")
    erwarte(hasattr(k, "durchgang"), "In rangliste.py fehlt noch die Methode durchgang(nummer) -- ein Klick auf die "
            "Liste ruft sie.")
    r, objekte = _liste(PROBE)
    rufe(r, "durchgang", 1)
    ist = _reihe(r)
    soll, _ = _bubble(PROBE, 1)
    erwarte(sorted(n for n, w in ist) == sorted(n for n, w in PROBE) and all(any(m is o for o in objekte) for m in _objekte(r)),
            "Fünf Mitglieder mit den Wertungen 30, 10, 50, 20, 40: Nach durchgang(1) stehen in der Rangliste nicht "
            "mehr dieselben fünf Mitglieder -- beim Tauschen geht eines verloren oder steht doppelt da.")
    erwarte(ist == soll, "Fünf Mitglieder mit den Wertungen 30, 10, 50, 20, 40: Nach durchgang(1) stehen dort %s -- "
            "erwartet 10, 30, 20, 40, 50 (die höchste Wertung ganz hinten)." % _wertungen(ist))
    rufe(r, "durchgang", 2)
    ist = _reihe(r)
    soll, _ = _bubble(PROBE, 2)
    erwarte(ist == soll, "Nach durchgang(1) und durchgang(2) stehen dort %s -- erwartet 10, 20, 30, 40, 50."
            % _wertungen(ist))
    fest = [("Ada", 20), ("Bo", 10), ("Cem", 5), ("Dua", 4), ("Eli", 3)]
    r, objekte = _liste(fest)
    rufe(r, "durchgang", 4)
    ist = _reihe(r)
    erwarte(ist == [("Bo", 10), ("Ada", 20), ("Cem", 5), ("Dua", 4), ("Eli", 3)], "Fünf Mitglieder mit 20, 10, 5, 4, 3: "
            "durchgang(4) vergleicht nur noch das erste Paar -- hinten liegen schon drei Plätze fest. Bei euch steht "
            "danach %s. Wofür steht nummer?" % _wertungen(ist))
    shell, ns, fehler = _spiel()
    erwarte(ns is not None, "portal.py bricht ab, bevor die Liste im Fenster steht%s." % (" (%s)" % fehler if fehler else ""))
    _klick(3)
    unten = _reihe(ns["rangliste"])[-1]
    erwarte(unten == ("Kofi", 1712), "Ein Klick auf die Liste ist ein Durchgang: Danach soll Kofi (1712) ganz unten "
            "stehen -- dort steht %s (%d)." % unten)


def pruefe_25_sortiere():
    """Aufgabe 2 ★★ · sortiere(): alle Durchgänge, ohne sort() -- die Kopfzeile sortiert alles"""
    braucht(_ok(pruefe_20_durchgang), "Erst ein Durchgang (Aufgabe 2 ★).")
    k = klasse("Rangliste")
    erwarte(hasattr(k, "sortiere"), "In rangliste.py fehlt noch die Methode sortiere() -- ein Klick auf die "
            "Kopfzeile ruft sie.")
    for paare in (PROBE, PROBE[::-1], sorted(PROBE, key=lambda p: p[1]), [("Ada", 7)], [],
                  [("Ada", 20), ("Bo", 20), ("Cem", 10)], [("Ada", 3), ("Bo", 2), ("Cem", 1), ("Dua", 4)],
                  ANMELDUNG[:9], ANMELDUNG[:11]):
        r, objekte = _liste(paare)
        rufe(r, "sortiere")
        ist = _reihe(r)
        erwarte(len(ist) == len(paare) and all(any(m is o for o in objekte) for m in _objekte(r)),
                "Nach sortiere() stehen in einer Rangliste mit %d Mitgliedern nicht mehr dieselben Mitglieder." % len(paare))
        erwarte([w for n, w in ist] == sorted(w for n, w in paare), "Mitglieder mit den Wertungen %s: Nach sortiere() "
                "stehen dort %s -- nicht aufsteigend sortiert." % (_wertungen(paare) or "(keine)", _wertungen(ist) or "(keine)"))
    fremd = [k2.attr if isinstance(k2, ast.Attribute) else k2.id for k2 in ast.walk(ast.parse(quelltext("rangliste.py")))
             if (isinstance(k2, ast.Attribute) and k2.attr == "sort") or (isinstance(k2, ast.Name) and k2.id == "sorted")]
    erwarte(not fremd, "In rangliste.py steht %s -- hier sortiert ihr selbst, mit durchgang."
            % " und ".join(n + "()" for n in sorted(set(fremd))))
    shell, ns, fehler = _spiel()
    erwarte(ns is not None, "portal.py bricht ab, bevor die Liste im Fenster steht%s." % (" (%s)" % fehler if fehler else ""))
    _klick(-1)
    ist = _reihe(ns["rangliste"])
    erwarte(ist == sorted(ANMELDUNG, key=lambda p: p[1]), "Ein Klick auf die Kopfzeile soll alle zwanzig Mitglieder "
            "sortieren -- oben steht danach %s (%d), unten %s (%d)." % (ist[0] + ist[-1]))


def pruefe_30_vergleiche():
    """Aufgabe 3 ★ · Die Rangliste zählt ihre Vergleiche, und der Klick nennt sie in der Shell"""
    braucht(_ok(pruefe_20_durchgang), "Erst ein Durchgang (Aufgabe 2 ★).")
    k = klasse("Rangliste")
    erwarte(hasattr(k, "get_vergleiche"), "In rangliste.py fehlt noch die Methode get_vergleiche().")
    r, _ = _liste(PROBE)
    v = rufe(r, "get_vergleiche")
    erwarte(v == 0, "Eine neue Rangliste hat noch nichts verglichen -- get_vergleiche() gibt %r." % (v,))
    rufe(r, "durchgang", 1)
    v = rufe(r, "get_vergleiche")
    erwarte(v == 4, "Fünf Mitglieder (30, 10, 50, 20, 40), ein Durchgang: Das sind 4 Vergleiche -- get_vergleiche() "
            "gibt %r. Gezählt wird jeder Vergleich, nicht jeder Tausch." % (v,))
    rufe(r, "durchgang", 2)
    v = rufe(r, "get_vergleiche")
    erwarte(v == 7, "Nach durchgang(1) und durchgang(2) sind es 4 + 3 = 7 Vergleiche -- get_vergleiche() gibt %r." % (v,))
    zweite, _ = _liste(PROBE)
    v = rufe(zweite, "get_vergleiche")
    erwarte(v == 0, "Eine zweite, neue Rangliste beginnt wieder bei 0 -- ihre get_vergleiche() gibt %r. Wo entsteht "
            "der Zähler?" % (v,))
    shell, ns, fehler = _spiel()
    erwarte(ns is not None, "portal.py bricht ab, bevor die Liste im Fenster steht%s." % (" (%s)" % fehler if fehler else ""))
    eins = _klick(3)
    erwarte(19 in _zahlen(eins) and 1 in _zahlen(eins), "Nach dem ersten Klick auf die Liste sollen in der Shell die "
            "Durchgänge (1) und die Vergleiche (19) stehen -- dort steht: %s" % (eins.strip()[:70] or "nichts"))
    zwei = _klick(3)
    erwarte(37 in _zahlen(zwei) and 2 in _zahlen(zwei), "Nach dem zweiten Klick sollen dort 2 Durchgänge und 37 "
            "Vergleiche stehen -- dort steht: %s" % (zwei.strip()[:70] or "nichts"))


def pruefe_35_messreihe():
    """Aufgabe 3 ★★ · messreihe() nennt die Vergleiche für 5, 10 und 20 Mitglieder"""
    braucht(_ok(pruefe_30_vergleiche), "Erst zählt die Rangliste ihre Vergleiche (Aufgabe 3 ★).")
    braucht(_ok(pruefe_25_sortiere), "Erst sortiere() (Aufgabe 2 ★★).")
    shell, ns, fehler = _spiel()
    erwarte(ns is not None, "portal.py bricht ab, bevor die Liste im Fenster steht%s." % (" (%s)" % fehler if fehler else ""))
    erwarte(callable(ns.get("messreihe")), "In portal.py fehlt noch die Funktion messreihe().")
    zeilen = [_zahlen(z) for z in shell.splitlines()]
    erwarte(any(z for z in zeilen), "messreihe() steht in portal.py, aber am Start steht nichts in der Shell -- wird "
            "sie aufgerufen, bevor das Fenster entsteht?")
    fehlt = []
    for n in (5, 10, 20):
        gut = {_bubble(ANMELDUNG[:n])[1], _bubble(ANMELDUNG[:n], abbruch=True)[1]}
        if not any(n in z and gut & set(z) for z in zeilen):
            fehlt.append("%d Mitglieder: %d Vergleiche" % (n, _bubble(ANMELDUNG[:n])[1]))
    erwarte(not fehlt, "In der Shell fehlt am Start: %s. Jede Größe braucht eine neue Rangliste mit den ersten "
            "Mitgliedern aus alle_mitglieder()." % " · ".join(fehlt))
    oben = _reihe(ns["rangliste"])[0]
    erwarte(oben == ("Aylin", 1480), "Nach der Messreihe ist die Rangliste des Portals schon sortiert (oben steht "
            "%s) -- messen soll sie an neuen Ranglisten, nicht an der des Portals." % oben[0])


def pruefe_60_abbruch():
    """Aufgabe 6 ★★ · sortiere() hört auf, sobald ein Durchgang nichts getauscht hat"""
    braucht(_ok(pruefe_30_vergleiche) and _ok(pruefe_25_sortiere), "Erst sortiert und zählt die Rangliste (Aufgabe 2 und 3).")
    d = _methode("rangliste.py", "durchgang")
    braucht(d is not None and any(isinstance(x, ast.Return) and x.value is not None for x in ast.walk(d)),
            "Erst gibt durchgang zurück, ob es getauscht hat.")
    for was, paare, soll in (("sechs Mitglieder, schon sortiert", [("A", 1), ("B", 2), ("C", 3), ("D", 4), ("E", 5), ("F", 6)], 5),
                             ("sechs Mitglieder, nur zwei Nachbarn vertauscht (1, 2, 3, 5, 4, 6)",
                              [("A", 1), ("B", 2), ("C", 3), ("D", 5), ("E", 4), ("F", 6)], 9),
                             ("sechs Mitglieder, genau falsch herum", [("A", 6), ("B", 5), ("C", 4), ("D", 3), ("E", 2), ("F", 1)], 15)):
        r, _ = _liste(paare)
        rufe(r, "sortiere")
        ist = _reihe(r)
        erwarte([w for n, w in ist] == sorted(w for n, w in paare), "Mit dem frühen Abbruch sortiert sortiere() nicht "
                "mehr richtig: %s -- danach steht dort %s." % (was, _wertungen(ist)))
        v = rufe(r, "get_vergleiche")
        erwarte(v == soll, "%s: sortiere() braucht %r Vergleiche -- mit dem frühen Abbruch sind es %d." % (was[0].upper() + was[1:], v, soll))


class _Zaehlliste(list):
    """Eine Liste, die mitschreibt, wie oft jemand einen Platz neu belegt -- und ob jemand sie umdrehen laesst."""
    geschrieben = 0
    fremd = ""

    def __setitem__(self, platz, wert):
        self.geschrieben += 1
        list.__setitem__(self, platz, wert)

    def reverse(self):
        self.fremd = "reverse()"
        list.reverse(self)

    def sort(self, *a, **kw):
        self.fremd = "sort()"
        list.sort(self, *a, **kw)


def pruefe_70_umdrehen():
    """Aufgabe 7 ★★★ · rangliste_umdrehen.py: umdrehen() mit höchstens anzahl // 2 Täuschen, ohne zweite Liste"""
    m = _modul("rangliste_umdrehen")
    k = getattr(m, "Rangliste", None) if m is not None else None
    braucht(isinstance(k, type) and hasattr(k, "umdrehen"), "Erst die Klasse Rangliste mit umdrehen() in "
            "rangliste_umdrehen.py.")
    sieben = PROBE + [("Fin", 60), ("Gül", 70)]
    for n in (5, 6, 7, 1, 0):
        r, objekte = _liste(sieben[:n], k)
        innen = getattr(r, "_Rangliste__mitglieder", None)
        erwarte(isinstance(innen, list), "In rangliste_umdrehen.py stehen die Mitglieder nicht mehr in "
                "self.__mitglieder -- kopiert eure Klasse erst ganz herüber.")
        z = _Zaehlliste(innen)
        setattr(r, "_Rangliste__mitglieder", z)
        rufe(r, "umdrehen")
        erwarte(getattr(r, "_Rangliste__mitglieder", None) is z, "Die Auflage: ohne zweite Liste -- umdrehen() hat "
                "eine neue Liste angelegt und die alte ersetzt.")
        erwarte(not z.fremd, "Die Auflage: ohne %s -- umdrehen() tauscht selbst." % z.fremd)
        ist = list(z)
        erwarte(len(ist) == n and all(a is b for a, b in zip(ist, objekte[::-1])), "%d Mitglieder mit den Wertungen "
                "%s: Nach umdrehen() stehen dort %s -- erwartet die umgekehrte Reihenfolge."
                % (n, _wertungen(sieben[:n]) or "(keine)", ", ".join(str(rufe(x, "get_wertung")) for x in ist) or "(keine)"))
        erwarte(z.geschrieben <= 2 * (n // 2), "%d Mitglieder: umdrehen() belegt %d-mal einen Platz neu -- mit %d "
                "Täuschen wären es höchstens %d." % (n, z.geschrieben, n // 2, 2 * (n // 2)))


def pruefe_90_hints():
    """Hinweis · Jede Methode in rangliste.py mit Type Hints (kein Stern)"""
    try:
        baum = ast.parse(quelltext("rangliste.py"))
    except SyntaxError:
        return
    ohne, falsch, diagramm = [], [], []
    for k in ast.walk(baum):
        if not isinstance(k, ast.FunctionDef):
            continue
        for a in k.args.args + [k]:
            typ = a.annotation if isinstance(a, ast.arg) else a.returns
            if typ is not None and any(isinstance(x, ast.Name) and x.id in DIAGRAMMTYPEN for x in ast.walk(typ)):
                diagramm.append("%s (%s)" % (k.name, ast.unparse(typ)))
        parameter = [a for a in k.args.args if a.arg != "self"]
        if any(a.annotation is None for a in parameter) or (k.returns is None and k.name != "__init__"):
            ohne.append(k.name)
        elif k.name in HINTS and ast.unparse(k.returns).replace(" ", "") not in HINTS[k.name]:
            falsch.append("%s -> %s" % (k.name, " oder ".join(sorted(HINTS[k.name]))))
    erwarte(not diagramm, "Hier steht ein Typ in der Schreibweise des Diagramms: %s. In Python heißt er str, int, "
            "float oder bool." % ", ".join(diagramm))
    erwarte(not ohne, "Ohne Type Hint (hinter der Klammer oder an einem Parameter): %s. Es läuft auch ohne; "
            "vereinbart ist es trotzdem -- der Konstruktor braucht hinter der Klammer keinen." % ", ".join(ohne))
    erwarte(not falsch, "Dieser Type Hint passt nicht zu dem, was zurückkommt -- erwartet: %s." % ", ".join(falsch))
