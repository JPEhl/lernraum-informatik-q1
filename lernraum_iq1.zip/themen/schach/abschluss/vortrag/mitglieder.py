# mitglieder.py -- gegeben: die zwanzig
# Mitglieder des Schachportals, in der
# Reihenfolge ihrer Anmeldung.
# Lesen dürft ihr, ändern nicht.

from mitglied import Mitglied

ANMELDUNGEN = [
    ["Aylin", 1480], ["Bence", 1215], ["Chiara", 1630], ["Dawit", 1342],
    ["Emre", 1105], ["Finja", 1577], ["Goran", 1290], ["Hanh", 1418],
    ["Ilias", 1048], ["Jule", 1466], ["Kofi", 1712], ["Liv", 1322],
    ["Milan", 1189], ["Nuria", 1540], ["Oskar", 1401], ["Pari", 1273],
    ["Quinn", 1433], ["Rosa", 1163], ["Samir", 1502], ["Tuana", 1251],
]


def alle_mitglieder() -> list[Mitglied]:
    """Gibt für jede Anmeldung ein neues Mitglied zurück --
    in der Reihenfolge der Anmeldung."""
    mitglieder = []
    for anmeldung in ANMELDUNGEN:
        mitglieder.append(Mitglied(anmeldung[0], anmeldung[1]))
    return mitglieder
